#! /bin/sh

# conviency for a posix shell

cd ../../src/propgrid
make clean
cd ../../samples/propgrid
make clean
