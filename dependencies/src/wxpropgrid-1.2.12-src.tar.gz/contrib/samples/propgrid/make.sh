#! /bin/sh

# conviency for a posix shell

cd ../../src/propgrid
make
cd ../../samples/propgrid
make
