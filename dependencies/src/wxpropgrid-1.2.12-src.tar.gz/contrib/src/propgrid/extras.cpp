/////////////////////////////////////////////////////////////////////////////
// Name:        extras.cpp
// Purpose:     wxPropertyGrid Extras
// Author:      Jaakko Salli
// Modified by:
// Created:     Mar-05-2006
// RCS-ID:      $Id:
// Copyright:   (c) Jaakko Salli
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

//
// In wxPython version this file will have additional property and
// editor control source code.
//

// For compilers that support precompilation, includes "wx/wx.h".
#include "wx/wxprec.h"

#ifdef __BORLANDC__
    #pragma hdrstop
#endif

