/////////////////////////////////////////////////////////////////////////////
// Name:        extras.h
// Purpose:     wxPropertyGrid Extras Header
// Author:      Jaakko Salli
// Modified by:
// Created:     Mar-05-2006
// RCS-ID:      $Id:
// Copyright:   (c) Jaakko Salli
// Licence:     wxWindows license
/////////////////////////////////////////////////////////////////////////////

#ifndef WX_PROPGRID_EXTRAS_H
#define WX_PROPGRID_EXTRAS_H

//
// In wxPython version this file will have additional property and
// editor control headers.
//

#endif // WX_PROPGRID_EXTRAS_H
