import ado_consts
from adodbapi import *

