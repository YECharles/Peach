#! /bin/sh
cd contrib
python wxPython/propgrid/install-propgrid.py POSIX=1 $*
