#
# wxWidgets Component Distribution helper library
#
# libwxcdist.py
#

import sys, os, os.path, re, imp, fnmatch


wx_req_bakefile_dict = {
    '2.6.0' : '0.1.7',
    '2.6.1' : '0.1.7',
    '2.6.2' : '0.1.7',
    '2.6.3' : '0.1.7',
    '2.6.4' : '0.2.3',
    '2.7.0' : '0.2.0',
    '2.7.1' : '0.2.0',
    '2.7.2' : '0.2.1',
    '2.8.0' : '0.2.3',
    '2.8.1' : '0.2.3',
    '2.8.2' : '0.2.3',
    '2.8.3' : '0.2.3',
    '2.8.4' : '0.2.3',
    '2.8.5' : '0.2.3',
    '2.8.6' : '0.2.3',
    '2.8.7' : '0.2.3',
    '2.8.8' : '0.2.3',
    '2.9.0' : '0.2.3',
    'default' : '0.2.3',
}


class empty_object:
    def __init__(self):
        pass


# all supported makefile and projectfile extensions
makefile_exts = ['gcc','bcc','vc','wat','in']
projfile_exts = ['dsp','dsw','vcproj','sln']

# Includes temporary files that can be in any dirs
common_tempfile_exts = ['pyc',]

# Includes temporary files in src, build and sample dirs
build_tempfile_exts = ['o','a','obj','lib','exe','dll','plg','opt','ncb','pdb','ilk']

# Includes temporary dirs in src, build and sample dirs
tempdirs_msw = ('msvcprj','msvc','msvc6prj','msvc6','vc_mswud','vc_mswu','vc_msw','vc_mswd')
tempdirs_unx = ('.pch','.deps')


specfile_filename = 'Specfile'


wxcode_default_wx_branch = '2.8'
wxcode_min_bakefile1 = '0.1.9'  # For old build system
wxcode_min_bakefile2 = '0.2.2'  # For new build system
wxcode_pref_bakefile = wx_req_bakefile_dict['default']
wxcode_min_wxversion = '2.6.2'


def vercmp(v1,v2):
    """\
    Compares two "x.y.z" version strings.
    """
    return (int(v1.replace('.',''))-int(v2.replace('.','')))



#
# All distribution creator/helper apps should create instance of this class.
#
class distrib_app:
    """\
    ask_wxdir_msg: If None, wx_dir is not asked if missing. If string,
                   then wx_dir is asked with this message displayed first.
    """
    def __init__(self,projname=None,debug=False,ask_wxdir_msg=None):

        opj = os.path.join
        opn = os.path.normpath

        self.wx_req_bakefile_dict = wx_req_bakefile_dict

        cwd = os.getcwd()
        self.orig_cwd = cwd

        if cwd[-1] == '\\' or cwd[-1] == '/':
            cwd = cwd[:-1]

        self.cwd = cwd

        cur_dir = cwd
        prev_dir = None

        wx_id_file = "wx-config.in"

        self.config = None

        # List of accumulated warnings
        self.warnings = []

        # Default mode (alternative is "contrib")
        self.mode = "undecided"

        #debug = True
        self.debug = debug

        config_module_name = "wxcdist_config"
        config_filename = "%s.py"%config_module_name
        config_filename2 = "%s"%config_module_name

        found_config_path = None
        found_wx_dir = None
        found_wx_dir_up = None
        found_svn_root = None
        found_comp_path = None

        # Temporary solution to work with wxPropertyGrid's distribution
        cur_dir = opj(cur_dir,"wxPython")
        if cur_dir[-1] == '\\' or cur_dir[-1] == '/':
            cur_dir = cur_dir[:-1]

        #
        # Go down the dir hierarchy to find wxcdist_config.py. Highest file found is used.
        # Also look for wxWidgets root dir (in case of contrib-builds)
        while 1:

            config_path = opj(cur_dir,config_filename)
            if os.path.isfile(config_path):
                if not found_config_path:
                    found_config_path = config_path

                if found_wx_dir and found_svn_root and found_comp_path:
                    break

            config_path2 = opj(cur_dir,config_filename2)
            if os.path.isfile(config_path2):
                if not found_config_path:
                    found_config_path = config_path2

                if found_wx_dir and found_svn_root and found_comp_path:
                    break

            if os.path.isfile(opj(cur_dir,wx_id_file)):
                found_wx_dir = cur_dir
                found_wx_dir_up = prev_dir

                if found_config_path and found_svn_root and found_comp_path:
                    break

            if os.path.isdir(opj(cur_dir,'trunk')) and os.path.isdir(opj(cur_dir,'branches')) and \
                os.path.isdir(opj(cur_dir,'tags')) and os.path.isdir(opj(cur_dir,'.svn')):
                found_svn_root = cur_dir

                if found_wx_dir and found_config_path and found_comp_path:
                    break

            if not found_comp_path:
                if os.path.isdir(opj(cur_dir,'src')) and os.path.isdir(opj(cur_dir,'include')) and \
                   os.path.isdir(opj(cur_dir,'samples')) and os.path.isdir(opj(cur_dir,'build')):
                    found_comp_path = cur_dir

                if found_wx_dir and found_config_path and found_svn_root:
                    break

            prev_dir = cur_dir

            cur_dir,cur_name = os.path.split(prev_dir)
            if not cur_dir or len(cur_dir) < 3:
                break

            if cur_dir[-1] == '\\' or cur_dir[-1] == '/':
                cur_dir = cur_dir[:-1]

        if debug:
            if found_wx_dir:
                print('Found wxWidgets source root: %s'%found_wx_dir)
            if found_svn_root:
                print('Found SVN root: %s'%found_svn_root)
            if found_comp_path:
                print('Found component path: %s'%found_comp_path)

        if found_config_path:
            try:
                config = imp.load_source(config_module_name,found_config_path)
            except (ImportError, IOError):
                import traceback
                traceback.print_exc()
                print 'ERROR: %s had a syntax error.'%config_filename
                sys.exit(1)

            try:
                os.remove(found_config_path+'c')
            except:
                pass

            self.config = config
            self.component_dir = getattr(config,'component_dir',None)
            self.default_wx_dir = getattr(config,'default_wx_dir','')
            self.redist_dir = getattr(config,'redist_dir',None)
            self.mode = getattr(config,'mode','undecided')

            wx_req_bakefile_dict2 = getattr(config,'wx_req_bakefile_dict',None)

            if wx_req_bakefile_dict2:
                self.wx_req_bakefile_dict.update(wx_req_bakefile_dict2)

            if not self.redist_dir:
                self.warning("config.py was missing 'redist_dir' (defaulted to redist)")
                self.redist_dir = 'redist'

            if not os.path.isabs(self.redist_dir):
                self.redist_dir = opj(cwd,self.redist_dir)

            if self.default_wx_dir:
                if self.default_wx_dir == '..':
                    self.default_wx_dir = os.path.split(cwd)[0]

        else:
            #self.warning('%s not found in the directory hierarchy (using defaults)'%config_filename)

            self.component_dir = None
            self.default_wx_dir = None
            self.redist_dir = 'redist'


        if not self.default_wx_dir:
            self.default_wx_dir = found_wx_dir

        if not self.default_wx_dir:
            self.default_wx_dir = os.getenv('WXWIN')


        argv = sys.argv
        opts = {}

        # Very simple argument parsing
        for s in argv[1:]:
            if s.find('=') >= 0:
                k,v = s.split('=',1)
                k = k.lower().strip()
                v = v.strip()
                opts[k] = v
            else:
                if not projname:
                    projname = s
                else:
                    opts[s] = '1'

        self.opts = opts

        # Validate found_svn_root
        if found_svn_root:
            if not found_svn_root.endswith(projname):
                if debug:
                    print('Potential SVN Root %s not valid - must end with project name (%s).'%(found_svn_root, projname))
                found_svn_root = None

        if not self.default_wx_dir:
            if 'wxdir' in opts:
                self.default_wx_dir = opts['wxdir']

        if not self.default_wx_dir:
            if ask_wxdir_msg:
                print ask_wxdir_msg
                self.default_wx_dir = raw_input()
            if not self.default_wx_dir:
                print 'ERROR: Default wxWidgets dir not found'

        branch = None

        # Determine mode, component dir, and try to detect the branch
        # If running in 'contrib dir', it is pretty clear
        if self.mode == 'undecided':
            if found_svn_root:
                self.mode = "component"
                self.component_dir = found_svn_root

                post_cwd = cwd[len(found_svn_root):]
                if len(post_cwd):
                    if (post_cwd[0] == '\\') or (post_cwd[0] == '/'):
                        post_cwd = post_cwd[1:]

                    if len(post_cwd):
                        post_cwd = post_cwd.replace('\\','/')
                        ss = post_cwd.split('/')

                        if ss[0] == 'trunk':
                            branch = 'trunk'

                        elif (ss[0] == 'branches' or ss[1] == 'tags') and len(ss) > 1:
                            branch = opj(ss[0],ss[1])


                if not branch:
                    print('Assuming we want to use trunk...')
                    branch = 'trunk'

                if debug:
                    print('Detected branch: %s'%branch)

            elif found_comp_path:
                if os.path.isdir(opj(found_comp_path,'src',projname)):
                    self.mode = "contrib"
                    self.component_dir = found_comp_path
                elif os.path.isdir(opj(found_comp_path,'src')):
                    self.mode = "component"
                    self.component_dir = found_comp_path
                    branch = None

            elif os.path.split(cwd)[1].find('contrib') >= 0:
                self.mode = "contrib"
                self.component_dir = cwd

        if self.mode == 'undecided':
            print('ERROR: Could not determine mode (either must run in \'contrib\' dir or SVN working copy root must be detectable)')
            sys.exit(1)

        self.wx_build_dir = None
        configure_was_run = False
        config_status_file = 'config.status'
        config_log_file = 'config.log'
        self.wx_use_unicode = None

        # Is it build dir?
        if not os.path.isfile(opj(self.default_wx_dir, wx_id_file)):
            # Is it build dir?
            cfgstatpth = opj(self.default_wx_dir, config_status_file)
            if os.path.isfile(cfgstatpth):
                configure_was_run = True
                self.wx_build_dir = self.default_wx_dir

                f = file(cfgstatpth,'rt')
                s = f.read()
                f.close()
                m = re.compile('\nsrcdir\s*=\s*["\']*(.+?)["\'\n]').search(s)
                if m:
                    self.default_wx_dir = os.path.abspath(opj(self.wx_build_dir,m.group(1)))

                if not m or not os.path.isdir(self.default_wx_dir):
                    print 'ERROR: Could no determine wxWidgets dir from config.status (candidate: %s)'%(self.default_wx_dir)

                f = file(opj(self.wx_build_dir, config_log_file),'rt')
                s = f.read()
                f.close()

                m = re.compile('\nprefix\s*=\s*["\']*(.+?)["\'\n]').search(s)
                if m:
                    self.wx_install_prefix = m.group(1)
                else:
                    print 'ERROR: Could not determine install prefix from config.log'

                m = re.compile('ac_cv_use_unicode\s*=\s*wxUSE_UNICODE\s*=\s*([a-zA-Z]+)').search(s)
                if m:
                    if m.group(1).lower() == 'yes':
                        self.wx_use_unicode = 1
                    else:
                        self.wx_use_unicode = 0

        self.configure_was_run = configure_was_run

        if not os.path.isfile(opj(self.default_wx_dir, wx_id_file)):
            print "ERROR: '%s' is not a valid wxWidgets directory"%(self.default_wx_dir)
            sys.exit(1)

        if not self.wx_build_dir:
            self.wx_build_dir = self.default_wx_dir

        if not projname:
            print 'ERROR: Project name not specified (give as first command-line argument).'
            sys.exit(2)

        self.projname = projname

        self.libs_dir = os.path.split(self.default_wx_dir)[0]

        #
        # Find spec.py (project specific config file)

        def load_spec(path,shared_dir=False):

            if shared_dir:
                spec_module = '%s_spec'%projname
            else:
                spec_module = 'spec'

            spec_path = opj(path,'%s.py'%spec_module)

            spec = None

            if self.debug:
            #if 1:
                print 'Searching for Specfile in %s'%path

            try:
                spec = imp.load_source(spec_module,spec_path)
            except (ImportError, IOError):
                spec_path = opj(path,specfile_filename)
                try:
                    spec = imp.load_source(spec_module,spec_path)
                except IOError:
                    return None
                except ImportError:
                    import traceback
                    traceback.print_exc()
                    print 'Errors when loading %s'%spec_path
                    sys.exit(1)

            try:
                os.remove(spec_path+'c')
            except:
                pass

            return spec


        spec = load_spec(self.component_dir,True)

        if not spec:
            sub_component_dir = opj(self.component_dir, projname)

            if branch:
                sub_component_dir_try = opj(self.component_dir, branch)

                if os.path.isdir(sub_component_dir_try):
                    sub_component_dir = sub_component_dir_try

            spec = load_spec(opj(sub_component_dir),False)
            if not spec:
                spec = load_spec(opj(sub_component_dir,'build'),False)

        # Two next ones are for contrib distributions that want to keep .py files
        # in wxPython dir (atleast in the distributable).
        if self.mode == 'contrib':
            if not spec:
                spec = load_spec(opj(self.component_dir,'wxPython'),True)
            if not spec:
                spec = load_spec(opj(self.component_dir,'wxPython',projname),False)
        else:
            if not spec:
                spec = load_spec(opj(sub_component_dir,'wxpython'),False)

        # Try current dir
        if not spec:
            spec = load_spec(cwd, False)

        if not spec:
            print "ERROR: spec file for project '%s' cannot be found"%projname
            sys.exit(1)

        self.spec = spec
        self.spec.most_recent_wx_version = spec.wx_version_list[-1]

        if projname != getattr(spec,'projname',''):
            print 'ERROR: Project name given mismatched projname in spec-file.'
            sys.exit(1)

        spec.projnameU = spec.projname.upper()

        # Determine basic sub-dirs
        if self.mode == 'component':
            self.component_dir_name = 'wxCode'
            self.iidn = ''  # iidu = intermediate install dir noslash (useful with opj)
            self.iidu = ''  # iidu = intermediate install dir unix
            self.iidd = ''  # iidu = intermediate install dir dos

            # NOTE: component_dir must be SVN root if branch is present
            #   Otherwise it must be the build base dir (ie. the one with src, include, samples, etc.)

            if branch:
                projname_and_branch = branch
                projname_and_branch_and_slash = projname_and_branch + '/'
            else:
                projname_and_branch = ''
                projname_and_branch_and_slash = ''

            spec.src_dir = '%ssrc'%projname_and_branch_and_slash
            spec.include_dir = '%sinclude/wx'%projname_and_branch_and_slash
            spec.include_dir_nowx = '%sinclude'%projname_and_branch_and_slash
            spec.build_dir = '%sbuild'%projname_and_branch_and_slash
            spec.docs_html_dir = '%sdocs/html'%projname_and_branch_and_slash
            spec.docs_dir = '%sdocs'%projname_and_branch_and_slash
            spec.samples_dir = '%ssamples'%projname_and_branch_and_slash

            if not os.path.isdir(opj(self.component_dir, spec.src_dir)):
                print 'ERROR: No src dir detected (base=%s, projname_and_branch=%s)'%(self.component_dir,projname_and_branch)
                sys.exit(1)

            spec.projname_and_branch = projname_and_branch
            self.projname_and_branch = projname_and_branch

            spec.full_samples_dir = opj(self.component_dir,spec.samples_dir)

            self.branch = branch

        else:
            self.component_dir_name = 'contrib'
            self.iidn = 'contrib'  # iidu = intermediate install dir noslash (useful with opj)
            self.iidu = 'contrib/'  # iidu = intermediate install dir unix
            self.iidd = 'contrib\\'  # iidu = intermediate install dir dos

            # Don't use os.path.join so that these will match any user-defined paths
            spec.src_dir = 'src/%s'%projname
            spec.include_dir = 'include/wx/%s'%projname
            spec.include_dir_nowx = 'include/wx/%s'%projname  # Same as normal
            spec.build_dir = 'build/%s'%projname
            spec.docs_html_dir = 'docs/html/%s'%projname
            spec.docs_dir = 'docs/%s'%projname
            spec.samples_dir = 'samples/%s'%projname

            spec.full_samples_dir = opn(opj(self.component_dir, spec.samples_dir))

        self.text_injectors = []

        if self.debug:
            print 'self.redist_dir = %s'%(self.redist_dir)
            print 'self.default_wx_dir = %s'%(self.default_wx_dir)
            print 'self.component_dir = %s'%(self.component_dir)


    def finalize(self,exit_code=0):

        for ti in self.text_injectors:
            ti.revert()

        os.chdir(self.orig_cwd)

        if self.warnings:
            print '** List of Accumulated Warnings **'
            for s in self.warnings:
                print s

        sys.exit(exit_code)


    def warning(self, s):
        ws = 'WARNINGS: %s'%s
        print(ws)
        self.warnings.append(ws)


    def parse_spec_path(self,path):

        spec = self.spec
        path = path % (spec.__dict__)

        # Does it have $(dirname) abstraction?
        dollar_pos = path.find('$(')
        if dollar_pos >= 0:
            end_pos = path.find(')',dollar_pos)
            if end_pos >= 0 and dollar_pos == 0 and \
                (end_pos == (len(path)-1) or path[end_pos+1] == '/') :
                in_path = path[dollar_pos+2:end_pos]

                post_path = path[end_pos+1:]

                if in_path:
                    if self.mode == 'component':
                        path = '%s/%s'%(spec.projname_and_branch,in_path)
                    else:
                        path = '%s/%s'%(in_path,spec.projname)

                    # Special considerations?
                    if not os.path.isdir(path):
                        # Distscript relocation
                        if in_path == 'distscript':
                            path = self.config.distscript_path
                else:
                    if self.mode == 'component':
                        path = '%s'%(spec.projname_and_branch)
                    else:
                        path = ''

                path += post_path

            else:
                print "ERROR: In spec.py, there was invalid directory path '%s'"%path
                self.finalize(1)

        return path


    def parse_spec(self):
        """\
        Parses some data structures loaded from the spec-file.
        """

        spec = self.spec
        spec_dict = spec.__dict__

        #
        # prepare spec.dir_infos
        dir_infos = []

        for dir_info in spec.dir_infos:

            if len(dir_info) > 2:
                d = dir_info[2]
            else:
                d = {}

            path = self.parse_spec_path(dir_info[0])

            d['path'] = path

            # Go through file specs
            d['filespecs'] = dir_info[1]

            d['dos_path'] = d['path'].replace('/','\\')
            d['native_path'] = os.path.normpath(d['path'])

            d['moves_to'] = {}
            d['moves_from'] = {}

            dir_infos.append(d)


        # Sort so that longer paths are last
        def dicmp(a,b):
            return len(a['path']) - len(b['path'])

        dir_infos.sort(dicmp)

        spec.dir_infos = dir_infos


    def get_comp_dir(self, subdir):
        if self.mode == 'contrib':
            return os.path.join(subdir, self.projname)
        else:
            return os.path.join(self.component_dir, self.projname_and_branch, subdir)


    def is_compile_dir(self,path):
        """\
        Returns true if path may contain temporary files or dirs as
        a result of build process.
        """

        if path.find('build/') >= 0 or path.find('/build') >= 0 or \
           path.find('src/') >= 0 or path.find('/src') >= 0 or \
           path.find('lib/') >= 0 or path.find('/lib') >= 0 or \
           path.find('samples/') >= 0 or path.find('/samples') >= 0:
            return True

        return False


    def replace_branch(self, path, s):
        """\
        Replaces branch (eg. 'trunk') in path with s.

        NOTES:
        * Finds from the end.
        """
        if self.mode == 'contrib':
            return path

        bp = path.rfind(self.branch)
        if bp < 0:
            return path

        l = len(self.branch)

        return '%s%s%s'%(path[:bp],s,path[bp+l:])


    def comp_branch_to_projname(self, path):
        """\
        Replaces branch (eg. 'trunk') from path, with project name. Only if in component mode.

        Useful when generating redistributable.
        """
        if self.mode == 'contrib':
            return path

        return self.replace_branch(path, self.projname)


    def find_files(self):
        """\
        Finds files in component subdirectories given in spec,
        and adds them to dir_info's 'content_files' dictionary item.
        Can be called multiple times (ie. files are only added once).

        NB: parse_spec must've been called before this.
        """

        app = self
        spec = self.spec
        spec_dict = spec.__dict__

        # List of invalid dir_infos
        del_dir_infos = []

        #
        # Generate list of content files and makefiles
        #

        for di_ind,dir_info in enumerate(spec.dir_infos):

            try:
                dir_str = dir_info['path']
            except (KeyError, ValueError, IndexError):
                print "ERROR: No 'path' in dir info. Was app.parse_spec() really called before find_files?"
                self.finalize(1)

            print '-> %s ->'%dir_str

            filespecs = dir_info['filespecs']

            full_dir_str = os.path.normpath(os.path.join(app.component_dir,dir_str))

            content_files = dir_info.get('content_files',list())
            makefiles = dir_info.get('makefiles',list())

            try:
                filelist = os.listdir(full_dir_str)
            except:
                self.warning("Cannot find or read path '%s'"%full_dir_str)
                del_dir_infos.append(di_ind)
                continue
                #app.finalize(1)

            do_fnmatch = fnmatch.fnmatchcase

            moves_to = dir_info['moves_to']
            moves_from = dir_info['moves_from']

            for filespec in filespecs:

                filespec = filespec % spec_dict

                if filespec == '$makefiles':
                    # Makefiles

                    for filename in filelist:
                        fnc = os.path.splitext(filename)
                        ext = fnc[1][1:]

                        if not (filename in makefiles):
                            if ext in makefile_exts:
                                makefiles.append(filename)
                                print 'added makefile: %s'%filename
                            elif ext in projfile_exts:
                                # additional requirement - last char of filename must be number
                                if (fnc[0].endswith('_generated') or fnc[0][-1].isdigit()) or self.mode == 'component':
                                    makefiles.append(filename)
                                    print 'added projfile: %s'%filename

                else:

                    ss = filespec.split('>>')
                    if len(ss) > 1:
                        filespec = ss[0]
                        move_to = ss[1]%spec_dict

                        move_to_dirinfo = None

                        for di2 in spec.dir_infos:
                            if di2['path'] == move_to:
                                move_to_dirinfo = di2

                    else:
                        move_to = None

                    if filespec.find('*') >= 0 or filespec.find('?') >= 0:
                        # Wildcard

                        for filename in filelist:
                            if not filename.startswith('.'):
                                if do_fnmatch(filename,filespec) and not os.path.isdir(os.path.join(full_dir_str,filename)):
                                    if not (filename in content_files):
                                        content_files.append(filename)
                                        if not (move_to is None):
                                            print 'added file by wildcard: %s (to "%s/%s")'%(filename,self.component_dir_name,move_to)
                                            moves_to[filename] = move_to
                                            if move_to_dirinfo:
                                                move_to_dirinfo['moves_from'][filename] = dir_str
                                        else:
                                            print 'added file by wildcard: %s'%filename

                    else:
                        # Single file

                        filename = filespec
                        if not (filename in content_files):
                            content_files.append(filename)

                            full_file_path = os.path.join(full_dir_str,filename)
                            if os.path.isfile(full_file_path):
                                extra_str = ''
                            else:
                                extra_str = ' (WARNING: did not exist)'

                            if not (move_to is None):
                                print 'added specific file: %s (to "%s/%s")%s'%(filename,self.component_dir_name,move_to,extra_str)
                                moves_to[filename] = move_to
                                if move_to_dirinfo:
                                    move_to_dirinfo['moves_from'][filename] = dir_str
                            else:
                                print 'added specific file: %s%s'%(filename,extra_str)


            for s in content_files:
                if s.find(' ') >= 0:
                    print 'ERROR: Filenames may not contain spaces ("%s/%s")'%(dir_info['path'],s)
                    self.finalize(1)

            dir_info['content_files'] = content_files
            dir_info['makefiles'] = makefiles

        del_dir_infos.sort( reverse=True )
        for i in del_dir_infos:
            del spec.dir_infos[i]


        # Check for empty dirs
        for dir_info in spec.dir_infos:

            content_files = dir_info['content_files']
            makefiles = dir_info['makefiles']
            moves_to = dir_info['moves_to']
            moves_from = dir_info['moves_from']

            ls = [fn for fn in content_files if not (fn in moves_to)] + makefiles

            if len(ls) < 1 and len(moves_from) < 1:
                dir_info['is_empty'] = True
            else:
                dir_info['is_empty'] = False


    def for_each_file(self, func, filespec):
        """\
        Runs a function for every file found using find_files.

        func must have signature (app,filepath,info).

        info is tuple (filename,dirpath)
        """
        spec = self.spec
        fnm = fnmatch.fnmatch
        opj = os.path.join

        for dir_info in spec.dir_infos:
            ds = dir_info['path']

            for filename in dir_info['content_files']:
                if not filespec or fnm(filename, filespec):
                    func(self, opj(ds,filename), (filename,ds))


    def get_req_bakefile_ver(self, version):
        """\
        Returns bakefile version (as string) required by given wxWidgets version.
        """
        return wx_req_bakefile_dict.get(version,wx_req_bakefile_dict['default'])

    def get_bakefile_gen_path(self, version, is_wxcode=False, is_wxcode_new=False):
        """\
        Returns path, complete with filename, to the bakefile_gen.
        """
        use_bakefile_ver = self.get_req_bakefile_ver(version)

        if is_wxcode:
            if is_wxcode_new:
                # Use latest bakefile found
                use_bakefile_ver = wxcode_pref_bakefile
                #if vercmp(use_bakefile_ver,wxcode_min_bakefile2) < 0:
                #    use_bakefile_ver = wxcode_min_bakefile2
            elif vercmp(use_bakefile_ver,wxcode_min_bakefile1) < 0:
                use_bakefile_ver = wxcode_min_bakefile1

        bakefile_path = getattr(self.config,'bakefile_path',None)
        if bakefile_path:
            bakefile_path = bakefile_path%{'ver_str':use_bakefile_ver}

            if not os.path.isdir(bakefile_path):
                if hasattr(self.config, 'bakefile_version_substitutes'):
                    use_bakefile_ver = self.config.bakefile_version_substitutes[use_bakefile_ver]
                    bakefile_path = getattr(self.config,'bakefile_path',None)%{'ver_str':use_bakefile_ver}
                else:
                    bakefile_path = None

        if bakefile_path:
            path_bakefile_gen = os.path.join(bakefile_path,'bakefile_gen')
            if not os.path.isfile(path_bakefile_gen) and \
               not os.path.isfile(path_bakefile_gen+'.exe') and \
               not os.path.isfile(path_bakefile_gen+'.py'):
                path_bakefile_gen = os.path.join(bakefile_path,'src','bakefile_gen')
        else:
            path_bakefile_gen = 'bakefile_gen'

        return path_bakefile_gen


    def version_to_branch_id(self, ver):
        """\
        Transforms version such as 2.8.3 or 2.8 to branch id like 28.
        """
        if ver.count('.') == 2:
            ver = ver[:ver.rfind('.')]

        return '%s%s'%(ver[0],ver[2:])


    def run_script(self,script_func,messages=False):
        """\
        Main function for generate-scripts.
        """

        self.parse_spec()

        if messages:
            print 'Scanning for files - first pass'

        self.find_files()

        script_func(self)

        self.finalize()


    def text_injection(self,filepath,insert_at_txt,insert_what,pre=True,revert=True):
        """\
        Auto-managed text injection into file.

        insert_what will be inserted where insert_at_txt is found.
        pre = True if injection point is before insert_at_txt.
        """
        ti = text_injector(filepath,insert_at_txt,insert_what,pre,revert=revert)
        self.text_injectors.append(ti)


    def is_in_separate_archive(self, inst_path):
        """\
        Checks whether given installation path is for file in a
        separate archive (must be in format style 'build/propgrid/file.txt').
        """
        spec = self.spec

        inst_path = inst_path.lower()

        for subdir in spec.separate_dir_archives:
            subdir = subdir.lower()
            if inst_path.startswith(subdir):
                return True
            if inst_path.startswith(os.path.join(self.projname,subdir)):
                return True
            if inst_path.endswith('%s.txt'%subdir):
                return True

        return False



class text_injector:
    """\
    Can be used to temporarily inject text into a specific position in a text file.

    insert_what will be inserted where insert_at_txt is found.
    """
    def __init__(self,filepath=None,insert_at_txt=None,insert_what=None,pre=None,revert=True):

        self.do_revert = revert

        if filepath:
            self.inject(filepath,insert_at_txt,insert_what,pre)
        else:
            self.filepath = filepath
            self.insert_what = None


    def __del__(self):
        self.revert()


    def inject(self,filepath,insert_at_txt,insert_what,pre=True):

        try:
            f = file(filepath,'rt')
            s = f.read()
            f.close()
        except IOError:
            return False

        pos = s.find(insert_at_txt)
        if pos < 0:
            return False
        elif not pre:
            pos += len(insert_at_txt)

        self.filepath = filepath
        self.insert_what = insert_what

        s = s[:pos] + insert_what + s[pos:]

        f = file(filepath,'wt')
        f.write(s)
        f.close()

        return True


    def revert(self):

        if not self.do_revert:
            return

        if not self.insert_what:
            return

        f = file(self.filepath,'rt')
        s = f.read()
        f.close()

        pos = s.find(self.insert_what)
        if pos < 0:
            pos = 0

        s = s[:pos] + s[(pos+len(self.insert_what)):]

        f = file(self.filepath,'wt')
        f.write(s)
        f.close()

        self.filepath = None
        self.insert_what = None



# Simple os.spawnv wrapper.
def run(prog,*args):
    true_args = [prog]
    true_args.extend(args)
    try:
        os.spawnv(os.P_WAIT,prog,true_args)
    except:
        raise OSError('Cannot run: %s'%prog)


def tarfile_add_with_mode(tf, source, target, mode_bits):
    """\
    Same as TarFile.add, but also adds permission (mode) bits.
    """
    import tarfile
    info = tarfile.TarInfo()
    f = file(source,'rb')
    f.seek(0, os.SEEK_END)
    sz = f.tell()
    f.seek(0, os.SEEK_SET)
    info.name = target
    info.size = sz
    info.mode = mode_bits
    info.mtime = os.path.getmtime(source)
    tf.addfile(info, f)


def rmtree(path, ignore_errors=False):
    """\
    Version of shutil.rmtree that deletes even readonly material.
    """

    import stat

    try:
        os.chmod(path, stat.S_IWRITE|stat.S_IREAD)
    except:
        if not ignore_errors:
            raise
        return

    for fn in os.listdir(path):
        s = os.path.join(path, fn)
        # Make sure it is writable by us
        if os.path.isdir(s):
            rmtree(s, ignore_errors)
        else:
            try:
                os.chmod(s, stat.S_IWRITE|stat.S_IREAD)
                os.remove(s)
            except:
                if not ignore_errors:
                    raise

    os.rmdir(path)
