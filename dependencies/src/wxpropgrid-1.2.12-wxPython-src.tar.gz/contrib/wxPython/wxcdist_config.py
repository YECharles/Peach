#
# Configures wxWidgets component distribution build system
# (including wxPython bindings building)
#

# If component_dir is not specified, then cwd is used.
#component_dir = ''

# Where is the default wxWidgets distribution - commented
# mean autodetect in descending directory hierarchy.
#default_wx_dir = ".."

# path to bakefile
# %(ver_str)s is replaced by version string such as '0.2.0'
bakefile_path = 'd:\\bakefile-%(ver_str)s\\src'

# path to nullsoft install script processor
nsis_path = 'D:\\Program Files\\NSIS'

# path to doxygen executable
doxygen_path = 'D:\\Program Files\\doxygen\\bin'

# base dir for temporary redist files (can be relative to component_dir)
redist_dir = 'redist'

#
# Settings required by wxPython bindings building
#

# Locations of wxPython source and import library installations
# NOTE: Currently only one dir is supported, and the version
#       number is simply ignored.
wxpython_dirs = {
    '2.6.3' : "D:\\lib\\wxPython-2.6.3.3",
    '2.7.1' : "D:\\lib\\wxPython-2.7.1.3"
}

#swig_path = "E:\\swig"

# ver_str is, for instance '0.2.0' for Bakefile 0.2.0
bakefile_path = 'D:\\bakefile-%(ver_str)s'


# Match wxWidgets version with required bakefile version
# There is initial table in wxcd.py, but this can be used to complement/override it.
wx_req_bakefile_dict = {
    # Entries like:
    #'2.7.0' : '0.2.0',
}

snapshot_ftp_server = 'personal.inet.fi'
snapshot_ftp_account = 'sallhe-p'

# Location of wxPG distscript-dir
distscript_path = r"D:\lib\wxCode\propgrid\branches\distscript"
