%{

// THIS FILE HAS BEEN AUTO-GENERATED

#ifndef SWIG_IsOK
    #define SWIG_IsOK(r)               (r >= 0)
#endif

#ifndef Py_RETURN_NONE
    #define Py_RETURN_NONE return Py_INCREF(Py_None), Py_None
#endif

void _deleteOwningObject(PyObject* obj)
{
    // Crashes sometimes (on app exit, it seems), so we need to disable it
    /*if ( Py_IsInitialized() )
    {
        wxPyBlock_t blocked = wxPyBeginBlockThreads();
        Py_XDECREF(obj);
        wxPyEndBlockThreads(blocked);
    }*/
}
    

static bool gs_funcNamesInitialized = false;
static PyObject* gs___class___Name = NULL;
static PyObject* gs___dict___Name = NULL;
static PyObject* gs__super_call_Name = NULL;
static PyObject* gs_CanContainCustomImage_Name = NULL;
static PyObject* gs_ChildChanged_Name = NULL;
static PyObject* gs_CopyValueFromControl_Name = NULL;
static PyObject* gs_CreateControls_Name = NULL;
static PyObject* gs_CreateEditorDialog_Name = NULL;
static PyObject* gs_DeleteItem_Name = NULL;
static PyObject* gs_DoGetValidator_Name = NULL;
static PyObject* gs_DoGetValue_Name = NULL;
static PyObject* gs_DoSetValue_Name = NULL;
static PyObject* gs_DrawValue_Name = NULL;
static PyObject* gs_GenerateValueAsString_Name = NULL;
static PyObject* gs_GetChoiceInfo_Name = NULL;
static PyObject* gs_GetClassInfo_Name = NULL;
static PyObject* gs_GetClassName_Name = NULL;
static PyObject* gs_GetColour_Name = NULL;
static PyObject* gs_GetEditor_Name = NULL;
static PyObject* gs_GetEntry_Name = NULL;
static PyObject* gs_GetImageSize_Name = NULL;
static PyObject* gs_GetIndexForValue_Name = NULL;
static PyObject* gs_GetName_Name = NULL;
static PyObject* gs_GetType_Name = NULL;
static PyObject* gs_GetValueAsString_Name = NULL;
static PyObject* gs_GetValueType_Name = NULL;
static PyObject* gs_InsertItem_Name = NULL;
static PyObject* gs_OnButtonClick_Name = NULL;
static PyObject* gs_OnCustomPaint_Name = NULL;
static PyObject* gs_OnCustomStringEdit_Name = NULL;
static PyObject* gs_OnEvent_Name = NULL;
static PyObject* gs_OnFocus_Name = NULL;
static PyObject* gs_RefreshChildren_Name = NULL;
static PyObject* gs_SetAttribute_Name = NULL;
static PyObject* gs_SetControlIntValue_Name = NULL;
static PyObject* gs_SetControlStringValue_Name = NULL;
static PyObject* gs_SetValueFromInt_Name = NULL;
static PyObject* gs_SetValueFromString_Name = NULL;
static PyObject* gs_SetValueToUnspecified_Name = NULL;
static PyObject* gs_UpdateControl_Name = NULL;

static void _InitFuncNames()
{
    gs___dict___Name = PyString_FromString("__dict__");
    gs___class___Name = PyString_FromString("__class__");
    gs__super_call_Name = PyString_FromString("_super_call");
    gs_CanContainCustomImage_Name = PyString_FromString("CanContainCustomImage_t_");
    gs_ChildChanged_Name = PyString_FromString("ChildChanged_t_");
    gs_CopyValueFromControl_Name = PyString_FromString("CopyValueFromControl_t_");
    gs_CreateControls_Name = PyString_FromString("CreateControls_t_");
    gs_CreateEditorDialog_Name = PyString_FromString("CreateEditorDialog_t_");
    gs_DeleteItem_Name = PyString_FromString("DeleteItem_t_");
    gs_DoGetValidator_Name = PyString_FromString("DoGetValidator_t_");
    gs_DoGetValue_Name = PyString_FromString("DoGetValue_t_");
    gs_DoSetValue_Name = PyString_FromString("DoSetValue_t_");
    gs_DrawValue_Name = PyString_FromString("DrawValue_t_");
    gs_GenerateValueAsString_Name = PyString_FromString("GenerateValueAsString_t_");
    gs_GetChoiceInfo_Name = PyString_FromString("GetChoiceInfo_t_");
    gs_GetClassInfo_Name = PyString_FromString("GetClassInfo_t_");
    gs_GetClassName_Name = PyString_FromString("GetClassName_t_");
    gs_GetColour_Name = PyString_FromString("GetColour_t_");
    gs_GetEditor_Name = PyString_FromString("GetEditor_t_");
    gs_GetEntry_Name = PyString_FromString("GetEntry_t_");
    gs_GetImageSize_Name = PyString_FromString("GetImageSize_t_");
    gs_GetIndexForValue_Name = PyString_FromString("GetIndexForValue_t_");
    gs_GetName_Name = PyString_FromString("GetName_t_");
    gs_GetType_Name = PyString_FromString("GetType_t_");
    gs_GetValueAsString_Name = PyString_FromString("GetValueAsString_t_");
    gs_GetValueType_Name = PyString_FromString("GetValueType_t_");
    gs_InsertItem_Name = PyString_FromString("InsertItem_t_");
    gs_OnButtonClick_Name = PyString_FromString("OnButtonClick_t_");
    gs_OnCustomPaint_Name = PyString_FromString("OnCustomPaint_t_");
    gs_OnCustomStringEdit_Name = PyString_FromString("OnCustomStringEdit_t_");
    gs_OnEvent_Name = PyString_FromString("OnEvent_t_");
    gs_OnFocus_Name = PyString_FromString("OnFocus_t_");
    gs_RefreshChildren_Name = PyString_FromString("RefreshChildren_t_");
    gs_SetAttribute_Name = PyString_FromString("SetAttribute_t_");
    gs_SetControlIntValue_Name = PyString_FromString("SetControlIntValue_t_");
    gs_SetControlStringValue_Name = PyString_FromString("SetControlStringValue_t_");
    gs_SetValueFromInt_Name = PyString_FromString("SetValueFromInt_t_");
    gs_SetValueFromString_Name = PyString_FromString("SetValueFromString_t_");
    gs_SetValueToUnspecified_Name = PyString_FromString("SetValueToUnspecified_t_");
    gs_UpdateControl_Name = PyString_FromString("UpdateControl_t_");
    gs_funcNamesInitialized = true;
}


int _CommonCallback14(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxPGChoiceInfo* choiceinfo)
{
    PyObject* res;
    PyObject* py_choiceinfo;
    py_choiceinfo = SWIG_NewPointerObj((void*)choiceinfo, SWIGTYPE_p_wxPGChoiceInfo, 0);
    res = PyObject_CallFunctionObjArgs(funcobj, self, py_choiceinfo, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_choiceinfo);
    if (PyErr_Occurred()) SWIG_fail;
    {
    int retval;
    retval = (int)PyInt_AS_LONG(res);
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return 0;
}

void _CommonCallback16(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, int id, wxVariant& value)
{
    PyObject* res;
    PyObject* py_id;
    py_id = PyInt_FromLong((long)id);

    PyObject* py_value;
    py_value = SWIG_NewPointerObj((void*)&value, SWIGTYPE_p_wxVariant, 0);
    res = PyObject_CallFunctionObjArgs(funcobj, self, py_id, py_value, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_value);
    Py_DECREF(py_id);
    if (PyErr_Occurred()) SWIG_fail;
    {
    Py_DECREF(res);
    }
  fail:
    wxPyEndBlockThreads(blocked);
}

wxValidator* _CommonCallback13(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj)
{
    PyObject* res;
    res = PyObject_CallFunctionObjArgs(funcobj, self, NULL);
    Py_DECREF(funcobj);
    if (PyErr_Occurred()) SWIG_fail;
    {
    wxValidator* retval;
    if ( !SWIG_IsOK(SWIG_ConvertPtr(res, (void**)&(retval), SWIGTYPE_p_wxValidator, 0)) ) {
        PyErr_SetString(PyExc_TypeError,"expected wxValidator");
        SWIG_fail;
    }
    PyObject_SetAttrString(res, "thisown", Py_False);
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return NULL;
}

bool _CommonCallback17(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, const wxString& text, int flags)
{
    PyObject* res;
    PyObject* py_text;
    #if wxUSE_UNICODE
        py_text = PyUnicode_FromWideChar((&text)->c_str(), (&text)->Len());
    #else
        py_text = PyString_FromStringAndSize((&text)->c_str(), (&text)->Len());
    #endif

    PyObject* py_flags;
    py_flags = PyInt_FromLong((long)flags);

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_text, py_flags, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_flags);
    Py_DECREF(py_text);
    if (PyErr_Occurred()) SWIG_fail;
    {
    bool retval;
        if ( !SWIG_IsOK(SWIG_AsVal_bool(res, &retval)) ) {
        PyErr_SetString(PyExc_TypeError,"expected bool");
        SWIG_fail;
    }
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return false;
}

void _CommonCallback20(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxVariant value)
{
    PyObject* res;
    PyObject* py_value;
    py_value = wxVariant_to_PyObject(&value);
        if ( !py_value ) {
            PyErr_SetString(PyExc_TypeError, "this wxVariant type cannot be converted to Python object");
            SWIG_fail;
        }

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_value, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_value);
    if (PyErr_Occurred()) SWIG_fail;
    {
    Py_DECREF(res);
    }
  fail:
    wxPyEndBlockThreads(blocked);
}

const wxPGPropertyClassInfo* _CommonCallback19(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj)
{
    PyObject* res;
    res = PyObject_CallFunctionObjArgs(funcobj, self, NULL);
    Py_DECREF(funcobj);
    if (PyErr_Occurred()) SWIG_fail;
    {
    const wxPGPropertyClassInfo* retval;
    if ( !SWIG_IsOK(SWIG_ConvertPtr(res, (void**)&(retval), SWIGTYPE_p_wxPGPropertyClassInfo, 0)) ) {
        PyErr_SetString(PyExc_TypeError,"expected wxPGPropertyClassInfo");
        SWIG_fail;
    }
    PyObject_SetAttrString(res, "thisown", Py_False);
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return NULL;
}

wxSize _CommonCallback12(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj)
{
    PyObject* res;
    res = PyObject_CallFunctionObjArgs(funcobj, self, NULL);
    Py_DECREF(funcobj);
    if (PyErr_Occurred()) SWIG_fail;
    {
    wxSize retval;
    wxSize temp;    wxSize* _tptr_0 = &retval;
        if ( ! wxSize_helper(res, &_tptr_0)) SWIG_fail;
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return wxSize();
}

wxVariant _CommonCallback21(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj)
{
    PyObject* res;
    res = PyObject_CallFunctionObjArgs(funcobj, self, NULL);
    Py_DECREF(funcobj);
    if (PyErr_Occurred()) SWIG_fail;
    {
    wxVariant retval;
    if ( !PyObject_to_wxVariant(res, &retval) ) {
            PyErr_SetString(PyExc_TypeError, "this Python type cannot be converted to wxVariant");
            SWIG_fail;
        }
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return wxVariant();
}

bool _CommonCallback8(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxPGProperty* property, wxWindow* ctrl)
{
    PyObject* res;
    PyObject* py_property;
    py_property = SWIG_NewPointerObj((void*)property, SWIGTYPE_p_wxPGProperty, 0);
    PyObject* py_ctrl;
    py_ctrl = wxPyMake_wxObject(ctrl, (bool)0);

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_property, py_ctrl, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_ctrl);
    Py_DECREF(py_property);
    if (PyErr_Occurred()) SWIG_fail;
    {
    bool retval;
        if ( !SWIG_IsOK(SWIG_AsVal_bool(res, &retval)) ) {
        PyErr_SetString(PyExc_TypeError,"expected bool");
        SWIG_fail;
    }
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return false;
}

wxPGWindowPair _CommonCallback6(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz)
{
    PyObject* res;
    PyObject* py_propgrid;
    py_propgrid = SWIG_NewPointerObj((void*)propgrid, SWIGTYPE_p_wxPropertyGrid, 0);
    PyObject* py_property;
    py_property = SWIG_NewPointerObj((void*)property, SWIGTYPE_p_wxPGProperty, 0);
    PyObject* py_pos;
    py_pos = wxPoint_to_PyObject((&pos));

    PyObject* py_sz;
    py_sz = wxSize_to_PyObject((&sz));

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_propgrid, py_property, py_pos, py_sz, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_sz);
    Py_DECREF(py_pos);
    Py_DECREF(py_property);
    Py_DECREF(py_propgrid);
    if (PyErr_Occurred()) SWIG_fail;
    {
    wxPGWindowPair retval;
    if ( !PyObject_to_wxPGWindowPair(res, &retval) ) {
            PyErr_SetString(PyExc_TypeError, "expected wxWindow or tuple of two wxWindows");
            SWIG_fail;
        }
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return wxPGWindowPair();
}

void _CommonCallback0(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxWindow* ctrl, const wxString& txt)
{
    PyObject* res;
    PyObject* py_ctrl;
    py_ctrl = wxPyMake_wxObject(ctrl, (bool)0);

    PyObject* py_txt;
    #if wxUSE_UNICODE
        py_txt = PyUnicode_FromWideChar((&txt)->c_str(), (&txt)->Len());
    #else
        py_txt = PyString_FromStringAndSize((&txt)->c_str(), (&txt)->Len());
    #endif

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_ctrl, py_txt, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_txt);
    Py_DECREF(py_ctrl);
    if (PyErr_Occurred()) SWIG_fail;
    {
    Py_DECREF(res);
    }
  fail:
    wxPyEndBlockThreads(blocked);
}

bool _CommonCallback7(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* primary, wxEvent& event)
{
    PyObject* res;
    PyObject* py_propgrid;
    py_propgrid = SWIG_NewPointerObj((void*)propgrid, SWIGTYPE_p_wxPropertyGrid, 0);
    PyObject* py_property;
    py_property = SWIG_NewPointerObj((void*)property, SWIGTYPE_p_wxPGProperty, 0);
    PyObject* py_primary;
    py_primary = wxPyMake_wxObject(primary, (bool)0);

    PyObject* py_event;
    py_event = SWIG_NewPointerObj((void*)&event, SWIGTYPE_p_wxEvent, 0);
    res = PyObject_CallFunctionObjArgs(funcobj, self, py_propgrid, py_property, py_primary, py_event, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_event);
    Py_DECREF(py_primary);
    Py_DECREF(py_property);
    Py_DECREF(py_propgrid);
    if (PyErr_Occurred()) SWIG_fail;
    {
    bool retval;
        if ( !SWIG_IsOK(SWIG_AsVal_bool(res, &retval)) ) {
        PyErr_SetString(PyExc_TypeError,"expected bool");
        SWIG_fail;
    }
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return false;
}

bool _CommonCallback22(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxPropertyGrid* propgrid, wxWindow* primary, wxEvent& event)
{
    PyObject* res;
    PyObject* py_propgrid;
    py_propgrid = SWIG_NewPointerObj((void*)propgrid, SWIGTYPE_p_wxPropertyGrid, 0);
    PyObject* py_primary;
    py_primary = wxPyMake_wxObject(primary, (bool)0);

    PyObject* py_event;
    py_event = SWIG_NewPointerObj((void*)&event, SWIGTYPE_p_wxEvent, 0);
    res = PyObject_CallFunctionObjArgs(funcobj, self, py_propgrid, py_primary, py_event, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_event);
    Py_DECREF(py_primary);
    Py_DECREF(py_propgrid);
    if (PyErr_Occurred()) SWIG_fail;
    {
    bool retval;
        if ( !SWIG_IsOK(SWIG_AsVal_bool(res, &retval)) ) {
        PyErr_SetString(PyExc_TypeError,"expected bool");
        SWIG_fail;
    }
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return false;
}

bool _CommonCallback11(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, long value, int flags)
{
    PyObject* res;
    PyObject* py_value;
    py_value = PyInt_FromLong(value);

    PyObject* py_flags;
    py_flags = PyInt_FromLong((long)flags);

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_value, py_flags, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_flags);
    Py_DECREF(py_value);
    if (PyErr_Occurred()) SWIG_fail;
    {
    bool retval;
        if ( !SWIG_IsOK(SWIG_AsVal_bool(res, &retval)) ) {
        PyErr_SetString(PyExc_TypeError,"expected bool");
        SWIG_fail;
    }
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return false;
}

void _CommonCallback9(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxWindow* ctrl)
{
    PyObject* res;
    PyObject* py_ctrl;
    py_ctrl = wxPyMake_wxObject(ctrl, (bool)0);

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_ctrl, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_ctrl);
    if (PyErr_Occurred()) SWIG_fail;
    {
    Py_DECREF(res);
    }
  fail:
    wxPyEndBlockThreads(blocked);
}

bool _CommonCallback4(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj)
{
    PyObject* res;
    res = PyObject_CallFunctionObjArgs(funcobj, self, NULL);
    Py_DECREF(funcobj);
    if (PyErr_Occurred()) SWIG_fail;
    {
    bool retval;
        if ( !SWIG_IsOK(SWIG_AsVal_bool(res, &retval)) ) {
        PyErr_SetString(PyExc_TypeError,"expected bool");
        SWIG_fail;
    }
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return false;
}

void _CommonCallback3(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxPGProperty* property, wxWindow* wnd)
{
    PyObject* res;
    PyObject* py_property;
    py_property = SWIG_NewPointerObj((void*)property, SWIGTYPE_p_wxPGProperty, 0);
    PyObject* py_wnd;
    py_wnd = wxPyMake_wxObject(wnd, (bool)0);

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_property, py_wnd, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_wnd);
    Py_DECREF(py_property);
    if (PyErr_Occurred()) SWIG_fail;
    {
    Py_DECREF(res);
    }
  fail:
    wxPyEndBlockThreads(blocked);
}

wxString _CommonCallback5(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj)
{
    PyObject* res;
    res = PyObject_CallFunctionObjArgs(funcobj, self, NULL);
    Py_DECREF(funcobj);
    if (PyErr_Occurred()) SWIG_fail;
    {
    wxString retval;
    wxString* sptr = wxString_in_helper(res);
        if (sptr == NULL) SWIG_fail;
        retval = *sptr;
        delete sptr;
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return wxEmptyString;
}

void _CommonCallback10(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxDC& dc, wxPGProperty* property, const wxRect& rect)
{
    PyObject* res;
    PyObject* py_dc;
    py_dc = SWIG_NewPointerObj((void*)&dc, SWIGTYPE_p_wxDC, 0);
    PyObject* py_property;
    py_property = SWIG_NewPointerObj((void*)property, SWIGTYPE_p_wxPGProperty, 0);
    PyObject* py_rect;
    py_rect = SWIG_NewPointerObj((void*)&rect, SWIGTYPE_p_wxRect, 0);
    res = PyObject_CallFunctionObjArgs(funcobj, self, py_dc, py_property, py_rect, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_rect);
    Py_DECREF(py_property);
    Py_DECREF(py_dc);
    if (PyErr_Occurred()) SWIG_fail;
    {
    Py_DECREF(res);
    }
  fail:
    wxPyEndBlockThreads(blocked);
}

void _CommonCallback25(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj)
{
    PyObject* res;
    res = PyObject_CallFunctionObjArgs(funcobj, self, NULL);
    Py_DECREF(funcobj);
    if (PyErr_Occurred()) SWIG_fail;
    {
    Py_DECREF(res);
    }
  fail:
    wxPyEndBlockThreads(blocked);
}

const wxPGValueType* _CommonCallback18(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj)
{
    PyObject* res;
    res = PyObject_CallFunctionObjArgs(funcobj, self, NULL);
    Py_DECREF(funcobj);
    if (PyErr_Occurred()) SWIG_fail;
    {
    const wxPGValueType* retval;
    if ( !SWIG_IsOK(SWIG_ConvertPtr(res, (void**)&(retval), SWIGTYPE_p_wxPGValueType, 0)) ) {
        PyErr_SetString(PyExc_TypeError,"expected wxPGValueType");
        SWIG_fail;
    }
    PyObject_SetAttrString(res, "thisown", Py_False);
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return NULL;
}

void _CommonCallback24(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxPGProperty* p)
{
    PyObject* res;
    PyObject* py_p;
    py_p = SWIG_NewPointerObj((void*)p, SWIGTYPE_p_wxPGProperty, 0);
    res = PyObject_CallFunctionObjArgs(funcobj, self, py_p, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_p);
    if (PyErr_Occurred()) SWIG_fail;
    {
    Py_DECREF(res);
    }
  fail:
    wxPyEndBlockThreads(blocked);
}

const wxString* _CommonCallback27(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, size_t index, int* pvalue)
{
    PyObject* tpl;
    PyObject* py_index;
    py_index = PyInt_FromLong((size_t)index);

    tpl = PyObject_CallFunctionObjArgs(funcobj, self, py_index, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_index);
    if (PyErr_Occurred()) SWIG_fail;
    {
    const wxString* retval;
    long tpl_count = -1;
    if ( PySequence_Check(tpl) ) {
        PyObject* py_tpl_count = PyInt_FromLong((long)0);
        PySequence_Count(tpl, py_tpl_count);
        tpl_count = PyInt_AsLong(py_tpl_count);
        Py_DECREF(py_tpl_count);
    }
    if ( tpl_count != 2 ) {
        Py_DECREF(tpl);
        PyErr_SetString(PyExc_TypeError, "Expected tuple of 2 items as a return value.");
        SWIG_fail;
    }

    PyObject* res;
    res = PySequence_GetItem(tpl, 0);
    bool temp = false;    retval = wxString_in_helper(res);
        if (retval == NULL) SWIG_fail;
        temp = true;
    PyObject_SetAttrString(res, "thisown", Py_False);
    Py_DECREF(res);

    res = PySequence_GetItem(tpl, 1);
    *pvalue = (int)PyInt_AS_LONG(res);
    Py_DECREF(res);

    Py_DECREF(tpl);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return NULL;
}

int _CommonCallback26(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, int value)
{
    PyObject* res;
    PyObject* py_value;
    py_value = PyInt_FromLong((long)value);

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_value, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_value);
    if (PyErr_Occurred()) SWIG_fail;
    {
    int retval;
    retval = (int)PyInt_AS_LONG(res);
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return 0;
}

wxString _CommonCallback23(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, int argFlags)
{
    PyObject* res;
    PyObject* py_argFlags;
    py_argFlags = PyInt_FromLong((long)argFlags);

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_argFlags, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_argFlags);
    if (PyErr_Occurred()) SWIG_fail;
    {
    wxString retval;
    wxString* sptr = wxString_in_helper(res);
        if (sptr == NULL) SWIG_fail;
        retval = *sptr;
        delete sptr;
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return wxEmptyString;
}

void _CommonCallback2(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxWindow* ctrl, int index)
{
    PyObject* res;
    PyObject* py_ctrl;
    py_ctrl = wxPyMake_wxObject(ctrl, (bool)0);

    PyObject* py_index;
    py_index = PyInt_FromLong((long)index);

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_ctrl, py_index, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_index);
    Py_DECREF(py_ctrl);
    if (PyErr_Occurred()) SWIG_fail;
    {
    Py_DECREF(res);
    }
  fail:
    wxPyEndBlockThreads(blocked);
}

void _CommonCallback15(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    PyObject* res;
    PyObject* py_dc;
    py_dc = SWIG_NewPointerObj((void*)&dc, SWIGTYPE_p_wxDC, 0);
    PyObject* py_rect;
    py_rect = SWIG_NewPointerObj((void*)&rect, SWIGTYPE_p_wxRect, 0);
    PyObject* py_paintdata;
    py_paintdata = SWIG_NewPointerObj((void*)&paintdata, SWIGTYPE_p_wxPGPaintData, 0);
    res = PyObject_CallFunctionObjArgs(funcobj, self, py_dc, py_rect, py_paintdata, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_paintdata);
    Py_DECREF(py_rect);
    Py_DECREF(py_dc);
    if (PyErr_Occurred()) SWIG_fail;
    {
    Py_DECREF(res);
    }
  fail:
    wxPyEndBlockThreads(blocked);
}

int _CommonCallback1(wxPyBlock_t blocked, PyObject* self, PyObject* funcobj, wxWindow* ctrl, const wxString& label, int index)
{
    PyObject* res;
    PyObject* py_ctrl;
    py_ctrl = wxPyMake_wxObject(ctrl, (bool)0);

    PyObject* py_label;
    #if wxUSE_UNICODE
        py_label = PyUnicode_FromWideChar((&label)->c_str(), (&label)->Len());
    #else
        py_label = PyString_FromStringAndSize((&label)->c_str(), (&label)->Len());
    #endif

    PyObject* py_index;
    py_index = PyInt_FromLong((long)index);

    res = PyObject_CallFunctionObjArgs(funcobj, self, py_ctrl, py_label, py_index, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_index);
    Py_DECREF(py_label);
    Py_DECREF(py_ctrl);
    if (PyErr_Occurred()) SWIG_fail;
    {
    int retval;
    retval = (int)PyInt_AS_LONG(res);
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return 0;
}

class PyCheckBoxEditor : public wxPGCheckBoxEditor {
public:
        PyCheckBoxEditor();
    virtual ~PyCheckBoxEditor();
    void _SetSelf(PyObject *self);
    virtual void SetControlStringValue( wxWindow* ctrl, const wxString& txt ) const;
    virtual int InsertItem( wxWindow* ctrl, const wxString& label, int index ) const;
    virtual void DeleteItem( wxWindow* ctrl, int index ) const;
    virtual void OnFocus( wxPGProperty* property, wxWindow* wnd ) const;
    virtual bool CanContainCustomImage() const;
    virtual wxString GetName() const;
    virtual wxPGWindowPair CreateControls( wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz ) const;
    virtual void UpdateControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* primary, wxEvent& event ) const;
    virtual bool CopyValueFromControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual void SetValueToUnspecified( wxWindow* ctrl ) const;
    virtual void DrawValue( wxDC& dc, wxPGProperty* property, const wxRect& rect ) const;
    virtual void SetControlIntValue( wxWindow* ctrl, int value ) const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyCheckBoxEditor_pyClass = NULL;


PyCheckBoxEditor::PyCheckBoxEditor()
    : wxPGCheckBoxEditor()
{
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::PyCheckBoxEditor()"));

    Init();
}

PyCheckBoxEditor::~PyCheckBoxEditor()
{
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::~PyCheckBoxEditor()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyCheckBoxEditor::_SetSelf(PyObject *self)
{
    if ( !gs_PyCheckBoxEditor_pyClass )
    {
        gs_PyCheckBoxEditor_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyCheckBoxEditor_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


void PyCheckBoxEditor::SetControlStringValue(wxWindow* ctrl, const wxString& txt) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::SetControlStringValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlStringValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlStringValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::SetControlStringValue() exit (fall-back)"));
        wxPGCheckBoxEditor::SetControlStringValue(ctrl, txt);
        return;
    }
    _CommonCallback0(blocked, m_scriptObject, funcobj, ctrl, txt);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::SetControlStringValue() exit"));
}


int PyCheckBoxEditor::InsertItem(wxWindow* ctrl, const wxString& label, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::InsertItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_InsertItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_InsertItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::InsertItem() exit (fall-back)"));
        return wxPGCheckBoxEditor::InsertItem(ctrl, label, index);
    }
    return _CommonCallback1(blocked, m_scriptObject, funcobj, ctrl, label, index);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::InsertItem() exit"));
}


void PyCheckBoxEditor::DeleteItem(wxWindow* ctrl, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::DeleteItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DeleteItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DeleteItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::DeleteItem() exit (fall-back)"));
        wxPGCheckBoxEditor::DeleteItem(ctrl, index);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, index);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::DeleteItem() exit"));
}


void PyCheckBoxEditor::OnFocus(wxPGProperty* property, wxWindow* wnd) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::OnFocus() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnFocus_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnFocus_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::OnFocus() exit (fall-back)"));
        wxPGCheckBoxEditor::OnFocus(property, wnd);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, wnd);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::OnFocus() exit"));
}


bool PyCheckBoxEditor::CanContainCustomImage() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::CanContainCustomImage() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CanContainCustomImage_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CanContainCustomImage_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::CanContainCustomImage() exit (fall-back)"));
        return wxPGCheckBoxEditor::CanContainCustomImage();
    }
    return _CommonCallback4(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::CanContainCustomImage() exit"));
}


wxString PyCheckBoxEditor::GetName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::GetName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::GetName() exit (fall-back)"));
        return wxPGCheckBoxEditor::GetName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::GetName() exit"));
}


wxPGWindowPair PyCheckBoxEditor::CreateControls(wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::CreateControls() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CreateControls_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CreateControls_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::CreateControls() exit (fall-back)"));
        return wxPGCheckBoxEditor::CreateControls(propgrid, property, pos, sz);
    }
    return _CommonCallback6(blocked, m_scriptObject, funcobj, propgrid, property, pos, sz);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::CreateControls() exit"));
}


void PyCheckBoxEditor::UpdateControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::UpdateControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_UpdateControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_UpdateControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::UpdateControl() exit (fall-back)"));
        wxPGCheckBoxEditor::UpdateControl(property, ctrl);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::UpdateControl() exit"));
}


bool PyCheckBoxEditor::OnEvent(wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* primary, wxEvent& event) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::OnEvent() exit (fall-back)"));
        return wxPGCheckBoxEditor::OnEvent(propgrid, property, primary, event);
    }
    return _CommonCallback7(blocked, m_scriptObject, funcobj, propgrid, property, primary, event);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::OnEvent() exit"));
}


bool PyCheckBoxEditor::CopyValueFromControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::CopyValueFromControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CopyValueFromControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CopyValueFromControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::CopyValueFromControl() exit (fall-back)"));
        return wxPGCheckBoxEditor::CopyValueFromControl(property, ctrl);
    }
    return _CommonCallback8(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::CopyValueFromControl() exit"));
}


void PyCheckBoxEditor::SetValueToUnspecified(wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::SetValueToUnspecified() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueToUnspecified_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueToUnspecified_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::SetValueToUnspecified() exit (fall-back)"));
        wxPGCheckBoxEditor::SetValueToUnspecified(ctrl);
        return;
    }
    _CommonCallback9(blocked, m_scriptObject, funcobj, ctrl);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::SetValueToUnspecified() exit"));
}


void PyCheckBoxEditor::DrawValue(wxDC& dc, wxPGProperty* property, const wxRect& rect) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::DrawValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DrawValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DrawValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::DrawValue() exit (fall-back)"));
        wxPGCheckBoxEditor::DrawValue(dc, property, rect);
        return;
    }
    _CommonCallback10(blocked, m_scriptObject, funcobj, dc, property, rect);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::DrawValue() exit"));
}


void PyCheckBoxEditor::SetControlIntValue(wxWindow* ctrl, int value) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::SetControlIntValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlIntValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlIntValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCheckBoxEditor::SetControlIntValue() exit (fall-back)"));
        wxPGCheckBoxEditor::SetControlIntValue(ctrl, value);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, value);
    MySWIGOutputDebugString(wxT("PyCheckBoxEditor::SetControlIntValue() exit"));
}


class PyFontProperty : public wxFontPropertyClass {
public:
        PyFontProperty( const wxString& label, const wxString& name, const wxFont& value );
    virtual ~PyFontProperty();
    void _SetSelf(PyObject *self);
    virtual bool SetValueFromInt( long value, int flags = 0 );
    virtual wxSize GetImageSize() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual bool SetValueFromString( const wxString& text, int flags );
    virtual const wxPGValueType* GetValueType() const;
    virtual wxString GetClassName() const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual void DoSetValue ( wxVariant value );
    virtual wxVariant DoGetValue () const;
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* primary, wxEvent& event );
    virtual wxString GetValueAsString( int argFlags = 0 ) const;
    virtual void ChildChanged( wxPGProperty* p );
    virtual void RefreshChildren();
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyFontProperty_pyClass = NULL;


PyFontProperty::PyFontProperty(const wxString& label, const wxString& name, const wxFont& value)
    : wxFontPropertyClass(label, name, value)
{
    MySWIGOutputDebugString(wxT("PyFontProperty::PyFontProperty()"));

    Init();
}

PyFontProperty::~PyFontProperty()
{
    MySWIGOutputDebugString(wxT("PyFontProperty::~PyFontProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyFontProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyFontProperty_pyClass )
    {
        gs_PyFontProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyFontProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


bool PyFontProperty::SetValueFromInt(long value, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::SetValueFromInt() exit (fall-back)"));
        return wxFontPropertyClass::SetValueFromInt(value, flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, flags);
    MySWIGOutputDebugString(wxT("PyFontProperty::SetValueFromInt() exit"));
}


wxSize PyFontProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::GetImageSize() exit (fall-back)"));
        return wxFontPropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFontProperty::GetImageSize() exit"));
}


wxString PyFontProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::GetType() exit (fall-back)"));
        return wxFontPropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFontProperty::GetType() exit"));
}


wxString PyFontProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::GetEditor() exit (fall-back)"));
        return wxFontPropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFontProperty::GetEditor() exit"));
}


wxValidator* PyFontProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::DoGetValidator() exit (fall-back)"));
        return wxFontPropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFontProperty::DoGetValidator() exit"));
}


int PyFontProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::GetChoiceInfo() exit (fall-back)"));
        return wxFontPropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyFontProperty::GetChoiceInfo() exit"));
}


void PyFontProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::OnCustomPaint() exit (fall-back)"));
        wxFontPropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyFontProperty::OnCustomPaint() exit"));
}


void PyFontProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::SetAttribute() exit (fall-back)"));
        wxFontPropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyFontProperty::SetAttribute() exit"));
}


bool PyFontProperty::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::SetValueFromString() exit (fall-back)"));
        return wxFontPropertyClass::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyFontProperty::SetValueFromString() exit"));
}


const wxPGValueType* PyFontProperty::GetValueType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::GetValueType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::GetValueType() exit (fall-back)"));
        return wxFontPropertyClass::GetValueType();
    }
    return _CommonCallback18(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFontProperty::GetValueType() exit"));
}


wxString PyFontProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::GetClassName() exit (fall-back)"));
        return wxFontPropertyClass::GetClassName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFontProperty::GetClassName() exit"));
}


const wxPGPropertyClassInfo* PyFontProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::GetClassInfo() exit (fall-back)"));
        return wxFontPropertyClass::GetClassInfo();
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFontProperty::GetClassInfo() exit"));
}


void PyFontProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::DoSetValue() exit (fall-back)"));
        wxFontPropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyFontProperty::DoSetValue() exit"));
}


wxVariant PyFontProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::DoGetValue() exit (fall-back)"));
        return wxFontPropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFontProperty::DoGetValue() exit"));
}


bool PyFontProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::OnEvent() exit (fall-back)"));
        return wxFontPropertyClass::OnEvent(propgrid, primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, primary, event);
    MySWIGOutputDebugString(wxT("PyFontProperty::OnEvent() exit"));
}


wxString PyFontProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::GetValueAsString() exit (fall-back)"));
        return wxFontPropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyFontProperty::GetValueAsString() exit"));
}


void PyFontProperty::ChildChanged(wxPGProperty* p)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::ChildChanged() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_ChildChanged_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_ChildChanged_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::ChildChanged() exit (fall-back)"));
        wxFontPropertyClass::ChildChanged(p);
        return;
    }
    _CommonCallback24(blocked, m_scriptObject, funcobj, p);
    MySWIGOutputDebugString(wxT("PyFontProperty::ChildChanged() exit"));
}


void PyFontProperty::RefreshChildren()
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFontProperty::RefreshChildren() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_RefreshChildren_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_RefreshChildren_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFontProperty::RefreshChildren() exit (fall-back)"));
        wxFontPropertyClass::RefreshChildren();
        return;
    }
    _CommonCallback25(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFontProperty::RefreshChildren() exit"));
}


class PyFileProperty : public wxFilePropertyClass {
public:
        PyFileProperty( const wxString& label, const wxString& name = wxString_wxPG_LABEL,
        const wxString& value = wxEmptyString );
    virtual ~PyFileProperty();
    void _SetSelf(PyObject *self);
    virtual bool SetValueFromInt( long value, int flags = 0 );
    virtual wxSize GetImageSize() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual const wxPGValueType* GetValueType() const;
    virtual wxString GetClassName() const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual void DoSetValue( wxVariant value );
    virtual wxVariant DoGetValue() const;
    virtual wxString GetValueAsString( int argFlags ) const;
    virtual bool SetValueFromString( const wxString& text, int flags );
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual wxValidator* DoGetValidator() const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyFileProperty_pyClass = NULL;


PyFileProperty::PyFileProperty(const wxString& label, const wxString& name, const wxString& value)
    : wxFilePropertyClass(label, name, value)
{
    MySWIGOutputDebugString(wxT("PyFileProperty::PyFileProperty()"));

    Init();
}

PyFileProperty::~PyFileProperty()
{
    MySWIGOutputDebugString(wxT("PyFileProperty::~PyFileProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyFileProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyFileProperty_pyClass )
    {
        gs_PyFileProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyFileProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


bool PyFileProperty::SetValueFromInt(long value, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::SetValueFromInt() exit (fall-back)"));
        return wxFilePropertyClass::SetValueFromInt(value, flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, flags);
    MySWIGOutputDebugString(wxT("PyFileProperty::SetValueFromInt() exit"));
}


wxSize PyFileProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::GetImageSize() exit (fall-back)"));
        return wxFilePropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFileProperty::GetImageSize() exit"));
}


wxString PyFileProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::GetType() exit (fall-back)"));
        return wxFilePropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFileProperty::GetType() exit"));
}


wxString PyFileProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::GetEditor() exit (fall-back)"));
        return wxFilePropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFileProperty::GetEditor() exit"));
}


int PyFileProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::GetChoiceInfo() exit (fall-back)"));
        return wxFilePropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyFileProperty::GetChoiceInfo() exit"));
}


void PyFileProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::OnCustomPaint() exit (fall-back)"));
        wxFilePropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyFileProperty::OnCustomPaint() exit"));
}


const wxPGValueType* PyFileProperty::GetValueType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::GetValueType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::GetValueType() exit (fall-back)"));
        return wxFilePropertyClass::GetValueType();
    }
    return _CommonCallback18(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFileProperty::GetValueType() exit"));
}


wxString PyFileProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::GetClassName() exit (fall-back)"));
        return wxFilePropertyClass::GetClassName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFileProperty::GetClassName() exit"));
}


const wxPGPropertyClassInfo* PyFileProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::GetClassInfo() exit (fall-back)"));
        return wxFilePropertyClass::GetClassInfo();
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFileProperty::GetClassInfo() exit"));
}


void PyFileProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::DoSetValue() exit (fall-back)"));
        wxFilePropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyFileProperty::DoSetValue() exit"));
}


wxVariant PyFileProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::DoGetValue() exit (fall-back)"));
        return wxFilePropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFileProperty::DoGetValue() exit"));
}


wxString PyFileProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::GetValueAsString() exit (fall-back)"));
        return wxFilePropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyFileProperty::GetValueAsString() exit"));
}


bool PyFileProperty::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::SetValueFromString() exit (fall-back)"));
        return wxFilePropertyClass::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyFileProperty::SetValueFromString() exit"));
}


bool PyFileProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::OnEvent() exit (fall-back)"));
        return wxFilePropertyClass::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyFileProperty::OnEvent() exit"));
}


void PyFileProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::SetAttribute() exit (fall-back)"));
        wxFilePropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyFileProperty::SetAttribute() exit"));
}


wxValidator* PyFileProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFileProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFileProperty::DoGetValidator() exit (fall-back)"));
        return wxFilePropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFileProperty::DoGetValidator() exit"));
}


class PyComboBoxEditor : public wxPGComboBoxEditor {
public:
        PyComboBoxEditor();
    virtual ~PyComboBoxEditor();
    void _SetSelf(PyObject *self);
    virtual void DrawValue( wxDC& dc, wxPGProperty* property, const wxRect& rect ) const;
    virtual void SetValueToUnspecified( wxWindow* ctrl ) const;
    virtual void SetControlIntValue( wxWindow* ctrl, int value ) const;
    virtual void SetControlStringValue( wxWindow* ctrl, const wxString& txt ) const;
    virtual int InsertItem( wxWindow* ctrl, const wxString& label, int index ) const;
    virtual void DeleteItem( wxWindow* ctrl, int index ) const;
    virtual bool CanContainCustomImage() const;
    virtual wxString GetName() const;
    virtual wxPGWindowPair CreateControls( wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz ) const;
    virtual void UpdateControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxPGProperty* property,
        wxWindow* ctrl, wxEvent& event ) const;
    virtual bool CopyValueFromControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual void OnFocus( wxPGProperty* property, wxWindow* wnd ) const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyComboBoxEditor_pyClass = NULL;


PyComboBoxEditor::PyComboBoxEditor()
    : wxPGComboBoxEditor()
{
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::PyComboBoxEditor()"));

    Init();
}

PyComboBoxEditor::~PyComboBoxEditor()
{
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::~PyComboBoxEditor()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyComboBoxEditor::_SetSelf(PyObject *self)
{
    if ( !gs_PyComboBoxEditor_pyClass )
    {
        gs_PyComboBoxEditor_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyComboBoxEditor_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


void PyComboBoxEditor::DrawValue(wxDC& dc, wxPGProperty* property, const wxRect& rect) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::DrawValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DrawValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DrawValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::DrawValue() exit (fall-back)"));
        wxPGComboBoxEditor::DrawValue(dc, property, rect);
        return;
    }
    _CommonCallback10(blocked, m_scriptObject, funcobj, dc, property, rect);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::DrawValue() exit"));
}


void PyComboBoxEditor::SetValueToUnspecified(wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::SetValueToUnspecified() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueToUnspecified_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueToUnspecified_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::SetValueToUnspecified() exit (fall-back)"));
        wxPGComboBoxEditor::SetValueToUnspecified(ctrl);
        return;
    }
    _CommonCallback9(blocked, m_scriptObject, funcobj, ctrl);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::SetValueToUnspecified() exit"));
}


void PyComboBoxEditor::SetControlIntValue(wxWindow* ctrl, int value) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::SetControlIntValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlIntValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlIntValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::SetControlIntValue() exit (fall-back)"));
        wxPGComboBoxEditor::SetControlIntValue(ctrl, value);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, value);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::SetControlIntValue() exit"));
}


void PyComboBoxEditor::SetControlStringValue(wxWindow* ctrl, const wxString& txt) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::SetControlStringValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlStringValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlStringValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::SetControlStringValue() exit (fall-back)"));
        wxPGComboBoxEditor::SetControlStringValue(ctrl, txt);
        return;
    }
    _CommonCallback0(blocked, m_scriptObject, funcobj, ctrl, txt);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::SetControlStringValue() exit"));
}


int PyComboBoxEditor::InsertItem(wxWindow* ctrl, const wxString& label, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::InsertItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_InsertItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_InsertItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::InsertItem() exit (fall-back)"));
        return wxPGComboBoxEditor::InsertItem(ctrl, label, index);
    }
    return _CommonCallback1(blocked, m_scriptObject, funcobj, ctrl, label, index);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::InsertItem() exit"));
}


void PyComboBoxEditor::DeleteItem(wxWindow* ctrl, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::DeleteItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DeleteItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DeleteItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::DeleteItem() exit (fall-back)"));
        wxPGComboBoxEditor::DeleteItem(ctrl, index);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, index);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::DeleteItem() exit"));
}


bool PyComboBoxEditor::CanContainCustomImage() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::CanContainCustomImage() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CanContainCustomImage_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CanContainCustomImage_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::CanContainCustomImage() exit (fall-back)"));
        return wxPGComboBoxEditor::CanContainCustomImage();
    }
    return _CommonCallback4(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::CanContainCustomImage() exit"));
}


wxString PyComboBoxEditor::GetName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::GetName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::GetName() exit (fall-back)"));
        return wxPGComboBoxEditor::GetName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::GetName() exit"));
}


wxPGWindowPair PyComboBoxEditor::CreateControls(wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::CreateControls() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CreateControls_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CreateControls_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::CreateControls() exit (fall-back)"));
        return wxPGComboBoxEditor::CreateControls(propgrid, property, pos, sz);
    }
    return _CommonCallback6(blocked, m_scriptObject, funcobj, propgrid, property, pos, sz);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::CreateControls() exit"));
}


void PyComboBoxEditor::UpdateControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::UpdateControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_UpdateControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_UpdateControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::UpdateControl() exit (fall-back)"));
        wxPGComboBoxEditor::UpdateControl(property, ctrl);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::UpdateControl() exit"));
}


bool PyComboBoxEditor::OnEvent(wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* ctrl, wxEvent& event) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::OnEvent() exit (fall-back)"));
        return wxPGComboBoxEditor::OnEvent(propgrid, property, ctrl, event);
    }
    return _CommonCallback7(blocked, m_scriptObject, funcobj, propgrid, property, ctrl, event);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::OnEvent() exit"));
}


bool PyComboBoxEditor::CopyValueFromControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::CopyValueFromControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CopyValueFromControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CopyValueFromControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::CopyValueFromControl() exit (fall-back)"));
        return wxPGComboBoxEditor::CopyValueFromControl(property, ctrl);
    }
    return _CommonCallback8(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::CopyValueFromControl() exit"));
}


void PyComboBoxEditor::OnFocus(wxPGProperty* property, wxWindow* wnd) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::OnFocus() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnFocus_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnFocus_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyComboBoxEditor::OnFocus() exit (fall-back)"));
        wxPGComboBoxEditor::OnFocus(property, wnd);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, wnd);
    MySWIGOutputDebugString(wxT("PyComboBoxEditor::OnFocus() exit"));
}


class PyFlagsProperty : public wxFlagsPropertyClass {
public:
        PyFlagsProperty( const wxString& label, const wxString& name,
        const wxArrayString& labels, const wxArrayInt& values, int value = 0 );
    virtual ~PyFlagsProperty();
    void _SetSelf(PyObject *self);
    virtual bool SetValueFromInt( long value, int flags = 0 );
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual wxSize GetImageSize() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual const wxPGValueType* GetValueType() const;
    virtual wxString GetClassName() const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual void DoSetValue( wxVariant value );
    virtual wxVariant DoGetValue() const;
    virtual wxString GetValueAsString( int argFlags ) const;
    virtual bool SetValueFromString( const wxString& text, int flags );
    virtual void ChildChanged( wxPGProperty* p );
    virtual void RefreshChildren();
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyFlagsProperty_pyClass = NULL;


PyFlagsProperty::PyFlagsProperty(const wxString& label, const wxString& name, const wxArrayString& labels, const wxArrayInt& values, int value)
    : wxFlagsPropertyClass(label, name, labels, values, value)
{
    MySWIGOutputDebugString(wxT("PyFlagsProperty::PyFlagsProperty()"));

    Init();
}

PyFlagsProperty::~PyFlagsProperty()
{
    MySWIGOutputDebugString(wxT("PyFlagsProperty::~PyFlagsProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyFlagsProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyFlagsProperty_pyClass )
    {
        gs_PyFlagsProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyFlagsProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


bool PyFlagsProperty::SetValueFromInt(long value, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::SetValueFromInt() exit (fall-back)"));
        return wxFlagsPropertyClass::SetValueFromInt(value, flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, flags);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::SetValueFromInt() exit"));
}


bool PyFlagsProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::OnEvent() exit (fall-back)"));
        return wxFlagsPropertyClass::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::OnEvent() exit"));
}


wxSize PyFlagsProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::GetImageSize() exit (fall-back)"));
        return wxFlagsPropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetImageSize() exit"));
}


wxString PyFlagsProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::GetType() exit (fall-back)"));
        return wxFlagsPropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetType() exit"));
}


wxString PyFlagsProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::GetEditor() exit (fall-back)"));
        return wxFlagsPropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetEditor() exit"));
}


wxValidator* PyFlagsProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::DoGetValidator() exit (fall-back)"));
        return wxFlagsPropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::DoGetValidator() exit"));
}


void PyFlagsProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::OnCustomPaint() exit (fall-back)"));
        wxFlagsPropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::OnCustomPaint() exit"));
}


void PyFlagsProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::SetAttribute() exit (fall-back)"));
        wxFlagsPropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::SetAttribute() exit"));
}


const wxPGValueType* PyFlagsProperty::GetValueType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetValueType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::GetValueType() exit (fall-back)"));
        return wxFlagsPropertyClass::GetValueType();
    }
    return _CommonCallback18(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetValueType() exit"));
}


wxString PyFlagsProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::GetClassName() exit (fall-back)"));
        return wxFlagsPropertyClass::GetClassName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetClassName() exit"));
}


const wxPGPropertyClassInfo* PyFlagsProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::GetClassInfo() exit (fall-back)"));
        return wxFlagsPropertyClass::GetClassInfo();
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetClassInfo() exit"));
}


void PyFlagsProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::DoSetValue() exit (fall-back)"));
        wxFlagsPropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::DoSetValue() exit"));
}


wxVariant PyFlagsProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::DoGetValue() exit (fall-back)"));
        return wxFlagsPropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::DoGetValue() exit"));
}


wxString PyFlagsProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::GetValueAsString() exit (fall-back)"));
        return wxFlagsPropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetValueAsString() exit"));
}


bool PyFlagsProperty::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::SetValueFromString() exit (fall-back)"));
        return wxFlagsPropertyClass::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::SetValueFromString() exit"));
}


void PyFlagsProperty::ChildChanged(wxPGProperty* p)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::ChildChanged() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_ChildChanged_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_ChildChanged_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::ChildChanged() exit (fall-back)"));
        wxFlagsPropertyClass::ChildChanged(p);
        return;
    }
    _CommonCallback24(blocked, m_scriptObject, funcobj, p);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::ChildChanged() exit"));
}


void PyFlagsProperty::RefreshChildren()
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::RefreshChildren() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_RefreshChildren_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_RefreshChildren_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::RefreshChildren() exit (fall-back)"));
        wxFlagsPropertyClass::RefreshChildren();
        return;
    }
    _CommonCallback25(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::RefreshChildren() exit"));
}


int PyFlagsProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyFlagsProperty::GetChoiceInfo() exit (fall-back)"));
        return wxFlagsPropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyFlagsProperty::GetChoiceInfo() exit"));
}


class PyPropertyWithChildren : public wxPGPropertyWithChildren {
public:
        PyPropertyWithChildren();
    PyPropertyWithChildren( const wxString& label, const wxString& name );
    virtual ~PyPropertyWithChildren();
    void _SetSelf(PyObject *self);
    virtual void DoSetValue( wxVariant value );
    virtual wxVariant DoGetValue() const;
    virtual bool SetValueFromInt( long value, int flags = 0 );
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual wxSize GetImageSize() const;
    virtual wxString GetClassName() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual bool SetValueFromString( const wxString& text, int flags );
    virtual wxString GetValueAsString( int argFlags = 0 ) const;
    virtual void RefreshChildren();
    virtual void ChildChanged( wxPGProperty* p );
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyPropertyWithChildren_pyClass = NULL;


PyPropertyWithChildren::PyPropertyWithChildren()
    : wxPGPropertyWithChildren()
{
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::PyPropertyWithChildren()"));

    Init();
}

PyPropertyWithChildren::PyPropertyWithChildren(const wxString& label, const wxString& name)
    : wxPGPropertyWithChildren(label, name)
{
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::PyPropertyWithChildren()"));

    Init();
}

PyPropertyWithChildren::~PyPropertyWithChildren()
{
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::~PyPropertyWithChildren()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyPropertyWithChildren::_SetSelf(PyObject *self)
{
    if ( !gs_PyPropertyWithChildren_pyClass )
    {
        gs_PyPropertyWithChildren_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyPropertyWithChildren_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


void PyPropertyWithChildren::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::DoSetValue() exit (fall-back)"));
        wxPGPropertyWithChildren::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::DoSetValue() exit"));
}


wxVariant PyPropertyWithChildren::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::DoGetValue() exit (fall-back)"));
        return wxPGPropertyWithChildren::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::DoGetValue() exit"));
}


bool PyPropertyWithChildren::SetValueFromInt(long value, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::SetValueFromInt() exit (fall-back)"));
        return wxPGPropertyWithChildren::SetValueFromInt(value, flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, flags);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::SetValueFromInt() exit"));
}


bool PyPropertyWithChildren::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::OnEvent() exit (fall-back)"));
        return wxPGPropertyWithChildren::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::OnEvent() exit"));
}


wxSize PyPropertyWithChildren::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetImageSize() exit (fall-back)"));
        return wxPGPropertyWithChildren::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetImageSize() exit"));
}


wxString PyPropertyWithChildren::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetClassName() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return wxEmptyString;
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetClassName() exit"));
}


wxString PyPropertyWithChildren::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetType() exit (fall-back)"));
        return wxPGPropertyWithChildren::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetType() exit"));
}


wxString PyPropertyWithChildren::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetEditor() exit (fall-back)"));
        return wxPGPropertyWithChildren::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetEditor() exit"));
}


wxValidator* PyPropertyWithChildren::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::DoGetValidator() exit (fall-back)"));
        return wxPGPropertyWithChildren::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::DoGetValidator() exit"));
}


int PyPropertyWithChildren::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetChoiceInfo() exit (fall-back)"));
        return wxPGPropertyWithChildren::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetChoiceInfo() exit"));
}


void PyPropertyWithChildren::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::OnCustomPaint() exit (fall-back)"));
        wxPGPropertyWithChildren::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::OnCustomPaint() exit"));
}


void PyPropertyWithChildren::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::SetAttribute() exit (fall-back)"));
        wxPGPropertyWithChildren::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::SetAttribute() exit"));
}


const wxPGPropertyClassInfo* PyPropertyWithChildren::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetClassInfo() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return NULL;
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetClassInfo() exit"));
}


bool PyPropertyWithChildren::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::SetValueFromString() exit (fall-back)"));
        return wxPGPropertyWithChildren::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::SetValueFromString() exit"));
}


wxString PyPropertyWithChildren::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetValueAsString() exit (fall-back)"));
        return wxPGPropertyWithChildren::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::GetValueAsString() exit"));
}


void PyPropertyWithChildren::RefreshChildren()
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::RefreshChildren() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_RefreshChildren_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_RefreshChildren_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::RefreshChildren() exit (fall-back)"));
        wxPGPropertyWithChildren::RefreshChildren();
        return;
    }
    _CommonCallback25(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::RefreshChildren() exit"));
}


void PyPropertyWithChildren::ChildChanged(wxPGProperty* p)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::ChildChanged() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_ChildChanged_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_ChildChanged_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyWithChildren::ChildChanged() exit (fall-back)"));
        wxPGPropertyWithChildren::ChildChanged(p);
        return;
    }
    _CommonCallback24(blocked, m_scriptObject, funcobj, p);
    MySWIGOutputDebugString(wxT("PyPropertyWithChildren::ChildChanged() exit"));
}


class PyPGRootProperty : public wxPGRootPropertyClass {
public:
        PyPGRootProperty();
    virtual ~PyPGRootProperty();
    void _SetSelf(PyObject *self);
    virtual void DoSetValue( wxVariant value );
    virtual wxVariant DoGetValue() const;
    virtual bool SetValueFromInt( long value, int flags = 0 );
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual wxSize GetImageSize() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual bool SetValueFromString( const wxString& text, int flags );
    virtual wxString GetValueAsString( int argFlags = 0 ) const;
    virtual void RefreshChildren();
    virtual void ChildChanged( wxPGProperty* p );
    virtual const wxPGValueType* GetValueType() const;
    virtual wxString GetClassName() const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyPGRootProperty_pyClass = NULL;


PyPGRootProperty::PyPGRootProperty()
    : wxPGRootPropertyClass()
{
    MySWIGOutputDebugString(wxT("PyPGRootProperty::PyPGRootProperty()"));

    Init();
}

PyPGRootProperty::~PyPGRootProperty()
{
    MySWIGOutputDebugString(wxT("PyPGRootProperty::~PyPGRootProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyPGRootProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyPGRootProperty_pyClass )
    {
        gs_PyPGRootProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyPGRootProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


void PyPGRootProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::DoSetValue() exit (fall-back)"));
        wxPGRootPropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::DoSetValue() exit"));
}


wxVariant PyPGRootProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::DoGetValue() exit (fall-back)"));
        return wxPGRootPropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::DoGetValue() exit"));
}


bool PyPGRootProperty::SetValueFromInt(long value, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::SetValueFromInt() exit (fall-back)"));
        return wxPGRootPropertyClass::SetValueFromInt(value, flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, flags);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::SetValueFromInt() exit"));
}


bool PyPGRootProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::OnEvent() exit (fall-back)"));
        return wxPGRootPropertyClass::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::OnEvent() exit"));
}


wxSize PyPGRootProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::GetImageSize() exit (fall-back)"));
        return wxPGRootPropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetImageSize() exit"));
}


wxString PyPGRootProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::GetType() exit (fall-back)"));
        return wxPGRootPropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetType() exit"));
}


wxString PyPGRootProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::GetEditor() exit (fall-back)"));
        return wxPGRootPropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetEditor() exit"));
}


wxValidator* PyPGRootProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::DoGetValidator() exit (fall-back)"));
        return wxPGRootPropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::DoGetValidator() exit"));
}


int PyPGRootProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::GetChoiceInfo() exit (fall-back)"));
        return wxPGRootPropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetChoiceInfo() exit"));
}


void PyPGRootProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::OnCustomPaint() exit (fall-back)"));
        wxPGRootPropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::OnCustomPaint() exit"));
}


void PyPGRootProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::SetAttribute() exit (fall-back)"));
        wxPGRootPropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::SetAttribute() exit"));
}


bool PyPGRootProperty::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::SetValueFromString() exit (fall-back)"));
        return wxPGRootPropertyClass::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::SetValueFromString() exit"));
}


wxString PyPGRootProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::GetValueAsString() exit (fall-back)"));
        return wxPGRootPropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetValueAsString() exit"));
}


void PyPGRootProperty::RefreshChildren()
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::RefreshChildren() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_RefreshChildren_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_RefreshChildren_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::RefreshChildren() exit (fall-back)"));
        wxPGRootPropertyClass::RefreshChildren();
        return;
    }
    _CommonCallback25(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::RefreshChildren() exit"));
}


void PyPGRootProperty::ChildChanged(wxPGProperty* p)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::ChildChanged() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_ChildChanged_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_ChildChanged_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::ChildChanged() exit (fall-back)"));
        wxPGRootPropertyClass::ChildChanged(p);
        return;
    }
    _CommonCallback24(blocked, m_scriptObject, funcobj, p);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::ChildChanged() exit"));
}


const wxPGValueType* PyPGRootProperty::GetValueType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetValueType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::GetValueType() exit (fall-back)"));
        return wxPGRootPropertyClass::GetValueType();
    }
    return _CommonCallback18(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetValueType() exit"));
}


wxString PyPGRootProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::GetClassName() exit (fall-back)"));
        return wxPGRootPropertyClass::GetClassName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetClassName() exit"));
}


const wxPGPropertyClassInfo* PyPGRootProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPGRootProperty::GetClassInfo() exit (fall-back)"));
        return wxPGRootPropertyClass::GetClassInfo();
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPGRootProperty::GetClassInfo() exit"));
}


class PySystemColourProperty : public wxSystemColourPropertyClass {
public:
        PySystemColourProperty( const wxString& label, const wxString& name,
        const wxColourPropertyValue& value );
    PySystemColourProperty( const wxString& label, const wxString& name,
        const wxChar** labels, const long* values, wxPGChoices* choicesCache,
        const wxColourPropertyValue& value );
    PySystemColourProperty( const wxString& label, const wxString& name,
        const wxChar** labels, const long* values, wxPGChoices* choicesCache,
        const wxColour& value );
    virtual ~PySystemColourProperty();
    void _SetSelf(PyObject *self);
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual bool SetValueFromInt( long value, int argFlags );
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual int GetIndexForValue( int value ) const;
    virtual const wxString* GetEntry( size_t index, int* pvalue ) const;
    virtual const wxPGValueType* GetValueType() const;
    virtual wxString GetClassName() const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual void DoSetValue ( wxVariant value );
    virtual wxVariant DoGetValue () const;
    virtual bool SetValueFromString ( const wxString& text, int flags = 0 );
    virtual wxString GetValueAsString ( int argFlags = 0 ) const;
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* primary, wxEvent& event );
    virtual wxSize GetImageSize() const;
    virtual void OnCustomPaint( wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual long GetColour( int index );
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PySystemColourProperty_pyClass = NULL;


PySystemColourProperty::PySystemColourProperty(const wxString& label, const wxString& name, const wxColourPropertyValue& value)
    : wxSystemColourPropertyClass(label, name, value)
{
    MySWIGOutputDebugString(wxT("PySystemColourProperty::PySystemColourProperty()"));

    Init();
}

PySystemColourProperty::PySystemColourProperty(const wxString& label, const wxString& name, const wxChar** labels, const long* values, wxPGChoices* choicesCache, const wxColourPropertyValue& value)
    : wxSystemColourPropertyClass(label, name, labels, values, choicesCache, value)
{
    MySWIGOutputDebugString(wxT("PySystemColourProperty::PySystemColourProperty()"));

    Init();
}

PySystemColourProperty::PySystemColourProperty(const wxString& label, const wxString& name, const wxChar** labels, const long* values, wxPGChoices* choicesCache, const wxColour& value)
    : wxSystemColourPropertyClass(label, name, labels, values, choicesCache, value)
{
    MySWIGOutputDebugString(wxT("PySystemColourProperty::PySystemColourProperty()"));

    Init();
}

PySystemColourProperty::~PySystemColourProperty()
{
    MySWIGOutputDebugString(wxT("PySystemColourProperty::~PySystemColourProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PySystemColourProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PySystemColourProperty_pyClass )
    {
        gs_PySystemColourProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PySystemColourProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


wxString PySystemColourProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::GetType() exit (fall-back)"));
        return wxSystemColourPropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetType() exit"));
}


wxString PySystemColourProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::GetEditor() exit (fall-back)"));
        return wxSystemColourPropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetEditor() exit"));
}


wxValidator* PySystemColourProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::DoGetValidator() exit (fall-back)"));
        return wxSystemColourPropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::DoGetValidator() exit"));
}


bool PySystemColourProperty::SetValueFromInt(long value, int argFlags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::SetValueFromInt() exit (fall-back)"));
        return wxSystemColourPropertyClass::SetValueFromInt(value, argFlags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, argFlags);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::SetValueFromInt() exit"));
}


int PySystemColourProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::GetChoiceInfo() exit (fall-back)"));
        return wxSystemColourPropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetChoiceInfo() exit"));
}


int PySystemColourProperty::GetIndexForValue(int value) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetIndexForValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetIndexForValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetIndexForValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::GetIndexForValue() exit (fall-back)"));
        return wxSystemColourPropertyClass::GetIndexForValue(value);
    }
    return _CommonCallback26(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetIndexForValue() exit"));
}


const wxString* PySystemColourProperty::GetEntry(size_t index, int* pvalue) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetEntry() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEntry_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEntry_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::GetEntry() exit (fall-back)"));
        return wxSystemColourPropertyClass::GetEntry(index, pvalue);
    }
    return _CommonCallback27(blocked, m_scriptObject, funcobj, index, pvalue);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetEntry() exit"));
}


const wxPGValueType* PySystemColourProperty::GetValueType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetValueType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::GetValueType() exit (fall-back)"));
        return wxSystemColourPropertyClass::GetValueType();
    }
    return _CommonCallback18(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetValueType() exit"));
}


wxString PySystemColourProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::GetClassName() exit (fall-back)"));
        return wxSystemColourPropertyClass::GetClassName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetClassName() exit"));
}


const wxPGPropertyClassInfo* PySystemColourProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::GetClassInfo() exit (fall-back)"));
        return wxSystemColourPropertyClass::GetClassInfo();
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetClassInfo() exit"));
}


void PySystemColourProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::DoSetValue() exit (fall-back)"));
        wxSystemColourPropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::DoSetValue() exit"));
}


wxVariant PySystemColourProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::DoGetValue() exit (fall-back)"));
        return wxSystemColourPropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::DoGetValue() exit"));
}


bool PySystemColourProperty::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::SetValueFromString() exit (fall-back)"));
        return wxSystemColourPropertyClass::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::SetValueFromString() exit"));
}


wxString PySystemColourProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::GetValueAsString() exit (fall-back)"));
        return wxSystemColourPropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetValueAsString() exit"));
}


bool PySystemColourProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::OnEvent() exit (fall-back)"));
        return wxSystemColourPropertyClass::OnEvent(propgrid, primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, primary, event);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::OnEvent() exit"));
}


wxSize PySystemColourProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::GetImageSize() exit (fall-back)"));
        return wxSystemColourPropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetImageSize() exit"));
}


void PySystemColourProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::OnCustomPaint() exit (fall-back)"));
        wxSystemColourPropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::OnCustomPaint() exit"));
}


void PySystemColourProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::SetAttribute() exit (fall-back)"));
        wxSystemColourPropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PySystemColourProperty::SetAttribute() exit"));
}


long PySystemColourProperty::GetColour(int index)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetColour() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetColour_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetColour_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PySystemColourProperty::GetColour() exit (fall-back)"));
        return wxSystemColourPropertyClass::GetColour(index);
    }
    PyObject* res;
    PyObject* py_index;
    py_index = PyInt_FromLong((long)index);

    res = PyObject_CallFunctionObjArgs(funcobj, m_scriptObject, py_index, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_index);
    if (PyErr_Occurred()) SWIG_fail;
    {
    long retval;
    retval = (long)PyInt_AS_LONG(res);
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return 0;
    MySWIGOutputDebugString(wxT("PySystemColourProperty::GetColour() exit"));
}


class PyParentProperty : public wxParentPropertyClass {
public:
        PyParentProperty( const wxString& label, const wxString& name = wxString_wxPG_LABEL );
    virtual ~PyParentProperty();
    void _SetSelf(PyObject *self);
    virtual bool SetValueFromInt( long value, int flags = 0 );
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual wxSize GetImageSize() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual bool SetValueFromString( const wxString& text, int flags );
    virtual void RefreshChildren();
    virtual const wxPGValueType* GetValueType() const;
    virtual wxString GetClassName() const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual void DoSetValue( wxVariant value );
    virtual wxVariant DoGetValue() const;
    virtual void ChildChanged( wxPGProperty* p );
    virtual wxString GetValueAsString( int argFlags = 0 ) const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyParentProperty_pyClass = NULL;


PyParentProperty::PyParentProperty(const wxString& label, const wxString& name)
    : wxParentPropertyClass(label, name)
{
    MySWIGOutputDebugString(wxT("PyParentProperty::PyParentProperty()"));

    Init();
}

PyParentProperty::~PyParentProperty()
{
    MySWIGOutputDebugString(wxT("PyParentProperty::~PyParentProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyParentProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyParentProperty_pyClass )
    {
        gs_PyParentProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyParentProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


bool PyParentProperty::SetValueFromInt(long value, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::SetValueFromInt() exit (fall-back)"));
        return wxParentPropertyClass::SetValueFromInt(value, flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, flags);
    MySWIGOutputDebugString(wxT("PyParentProperty::SetValueFromInt() exit"));
}


bool PyParentProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::OnEvent() exit (fall-back)"));
        return wxParentPropertyClass::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyParentProperty::OnEvent() exit"));
}


wxSize PyParentProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::GetImageSize() exit (fall-back)"));
        return wxParentPropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyParentProperty::GetImageSize() exit"));
}


wxString PyParentProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::GetType() exit (fall-back)"));
        return wxParentPropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyParentProperty::GetType() exit"));
}


wxString PyParentProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::GetEditor() exit (fall-back)"));
        return wxParentPropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyParentProperty::GetEditor() exit"));
}


wxValidator* PyParentProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::DoGetValidator() exit (fall-back)"));
        return wxParentPropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyParentProperty::DoGetValidator() exit"));
}


int PyParentProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::GetChoiceInfo() exit (fall-back)"));
        return wxParentPropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyParentProperty::GetChoiceInfo() exit"));
}


void PyParentProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::OnCustomPaint() exit (fall-back)"));
        wxParentPropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyParentProperty::OnCustomPaint() exit"));
}


void PyParentProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::SetAttribute() exit (fall-back)"));
        wxParentPropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyParentProperty::SetAttribute() exit"));
}


bool PyParentProperty::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::SetValueFromString() exit (fall-back)"));
        return wxParentPropertyClass::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyParentProperty::SetValueFromString() exit"));
}


void PyParentProperty::RefreshChildren()
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::RefreshChildren() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_RefreshChildren_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_RefreshChildren_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::RefreshChildren() exit (fall-back)"));
        wxParentPropertyClass::RefreshChildren();
        return;
    }
    _CommonCallback25(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyParentProperty::RefreshChildren() exit"));
}


const wxPGValueType* PyParentProperty::GetValueType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::GetValueType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::GetValueType() exit (fall-back)"));
        return wxParentPropertyClass::GetValueType();
    }
    return _CommonCallback18(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyParentProperty::GetValueType() exit"));
}


wxString PyParentProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::GetClassName() exit (fall-back)"));
        return wxParentPropertyClass::GetClassName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyParentProperty::GetClassName() exit"));
}


const wxPGPropertyClassInfo* PyParentProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::GetClassInfo() exit (fall-back)"));
        return wxParentPropertyClass::GetClassInfo();
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyParentProperty::GetClassInfo() exit"));
}


void PyParentProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::DoSetValue() exit (fall-back)"));
        wxParentPropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyParentProperty::DoSetValue() exit"));
}


wxVariant PyParentProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::DoGetValue() exit (fall-back)"));
        return wxParentPropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyParentProperty::DoGetValue() exit"));
}


void PyParentProperty::ChildChanged(wxPGProperty* p)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::ChildChanged() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_ChildChanged_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_ChildChanged_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::ChildChanged() exit (fall-back)"));
        wxParentPropertyClass::ChildChanged(p);
        return;
    }
    _CommonCallback24(blocked, m_scriptObject, funcobj, p);
    MySWIGOutputDebugString(wxT("PyParentProperty::ChildChanged() exit"));
}


wxString PyParentProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyParentProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyParentProperty::GetValueAsString() exit (fall-back)"));
        return wxParentPropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyParentProperty::GetValueAsString() exit"));
}


class PyTextCtrlEditor : public wxPGTextCtrlEditor {
public:
        PyTextCtrlEditor();
    virtual ~PyTextCtrlEditor();
    void _SetSelf(PyObject *self);
    virtual void SetControlIntValue( wxWindow* ctrl, int value ) const;
    virtual int InsertItem( wxWindow* ctrl, const wxString& label, int index ) const;
    virtual void DeleteItem( wxWindow* ctrl, int index ) const;
    virtual bool CanContainCustomImage() const;
    virtual wxString GetName() const;
    virtual wxPGWindowPair CreateControls( wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz ) const;
    virtual void UpdateControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* primary, wxEvent& event ) const;
    virtual bool CopyValueFromControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual void SetValueToUnspecified( wxWindow* ctrl ) const;
    virtual void DrawValue( wxDC& dc, wxPGProperty* property, const wxRect& rect ) const;
    virtual void SetControlStringValue( wxWindow* ctrl, const wxString& txt ) const;
    virtual void OnFocus( wxPGProperty* property, wxWindow* wnd ) const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyTextCtrlEditor_pyClass = NULL;


PyTextCtrlEditor::PyTextCtrlEditor()
    : wxPGTextCtrlEditor()
{
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::PyTextCtrlEditor()"));

    Init();
}

PyTextCtrlEditor::~PyTextCtrlEditor()
{
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::~PyTextCtrlEditor()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyTextCtrlEditor::_SetSelf(PyObject *self)
{
    if ( !gs_PyTextCtrlEditor_pyClass )
    {
        gs_PyTextCtrlEditor_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyTextCtrlEditor_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


void PyTextCtrlEditor::SetControlIntValue(wxWindow* ctrl, int value) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::SetControlIntValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlIntValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlIntValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::SetControlIntValue() exit (fall-back)"));
        wxPGTextCtrlEditor::SetControlIntValue(ctrl, value);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, value);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::SetControlIntValue() exit"));
}


int PyTextCtrlEditor::InsertItem(wxWindow* ctrl, const wxString& label, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::InsertItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_InsertItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_InsertItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::InsertItem() exit (fall-back)"));
        return wxPGTextCtrlEditor::InsertItem(ctrl, label, index);
    }
    return _CommonCallback1(blocked, m_scriptObject, funcobj, ctrl, label, index);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::InsertItem() exit"));
}


void PyTextCtrlEditor::DeleteItem(wxWindow* ctrl, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::DeleteItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DeleteItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DeleteItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::DeleteItem() exit (fall-back)"));
        wxPGTextCtrlEditor::DeleteItem(ctrl, index);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, index);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::DeleteItem() exit"));
}


bool PyTextCtrlEditor::CanContainCustomImage() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::CanContainCustomImage() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CanContainCustomImage_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CanContainCustomImage_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::CanContainCustomImage() exit (fall-back)"));
        return wxPGTextCtrlEditor::CanContainCustomImage();
    }
    return _CommonCallback4(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::CanContainCustomImage() exit"));
}


wxString PyTextCtrlEditor::GetName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::GetName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::GetName() exit (fall-back)"));
        return wxPGTextCtrlEditor::GetName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::GetName() exit"));
}


wxPGWindowPair PyTextCtrlEditor::CreateControls(wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::CreateControls() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CreateControls_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CreateControls_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::CreateControls() exit (fall-back)"));
        return wxPGTextCtrlEditor::CreateControls(propgrid, property, pos, sz);
    }
    return _CommonCallback6(blocked, m_scriptObject, funcobj, propgrid, property, pos, sz);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::CreateControls() exit"));
}


void PyTextCtrlEditor::UpdateControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::UpdateControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_UpdateControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_UpdateControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::UpdateControl() exit (fall-back)"));
        wxPGTextCtrlEditor::UpdateControl(property, ctrl);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::UpdateControl() exit"));
}


bool PyTextCtrlEditor::OnEvent(wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* primary, wxEvent& event) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::OnEvent() exit (fall-back)"));
        return wxPGTextCtrlEditor::OnEvent(propgrid, property, primary, event);
    }
    return _CommonCallback7(blocked, m_scriptObject, funcobj, propgrid, property, primary, event);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::OnEvent() exit"));
}


bool PyTextCtrlEditor::CopyValueFromControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::CopyValueFromControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CopyValueFromControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CopyValueFromControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::CopyValueFromControl() exit (fall-back)"));
        return wxPGTextCtrlEditor::CopyValueFromControl(property, ctrl);
    }
    return _CommonCallback8(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::CopyValueFromControl() exit"));
}


void PyTextCtrlEditor::SetValueToUnspecified(wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::SetValueToUnspecified() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueToUnspecified_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueToUnspecified_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::SetValueToUnspecified() exit (fall-back)"));
        wxPGTextCtrlEditor::SetValueToUnspecified(ctrl);
        return;
    }
    _CommonCallback9(blocked, m_scriptObject, funcobj, ctrl);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::SetValueToUnspecified() exit"));
}


void PyTextCtrlEditor::DrawValue(wxDC& dc, wxPGProperty* property, const wxRect& rect) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::DrawValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DrawValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DrawValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::DrawValue() exit (fall-back)"));
        wxPGTextCtrlEditor::DrawValue(dc, property, rect);
        return;
    }
    _CommonCallback10(blocked, m_scriptObject, funcobj, dc, property, rect);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::DrawValue() exit"));
}


void PyTextCtrlEditor::SetControlStringValue(wxWindow* ctrl, const wxString& txt) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::SetControlStringValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlStringValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlStringValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::SetControlStringValue() exit (fall-back)"));
        wxPGTextCtrlEditor::SetControlStringValue(ctrl, txt);
        return;
    }
    _CommonCallback0(blocked, m_scriptObject, funcobj, ctrl, txt);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::SetControlStringValue() exit"));
}


void PyTextCtrlEditor::OnFocus(wxPGProperty* property, wxWindow* wnd) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::OnFocus() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnFocus_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnFocus_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlEditor::OnFocus() exit (fall-back)"));
        wxPGTextCtrlEditor::OnFocus(property, wnd);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, wnd);
    MySWIGOutputDebugString(wxT("PyTextCtrlEditor::OnFocus() exit"));
}


class PyCustomProperty : public wxCustomPropertyClass {
public:
        PyCustomProperty( const wxString& label, const wxString& name = wxString_wxPG_LABEL );
    virtual ~PyCustomProperty();
    void _SetSelf(PyObject *self);
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual wxString GetClassName() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual void RefreshChildren();
    virtual void ChildChanged( wxPGProperty* p );
    virtual void DoSetValue( wxVariant value );
    virtual wxVariant DoGetValue() const;
    virtual bool SetValueFromString( const wxString& text, int flags );
    virtual wxString GetValueAsString( int argFlags ) const;
    virtual wxSize GetImageSize() const;
    virtual void OnCustomPaint( wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata );
    virtual bool SetValueFromInt ( long value, int arg_flags );
    virtual int GetChoiceInfo ( wxPGChoiceInfo* choiceinfo );
    virtual void SetAttribute ( int id, wxVariant& value );
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyCustomProperty_pyClass = NULL;


PyCustomProperty::PyCustomProperty(const wxString& label, const wxString& name)
    : wxCustomPropertyClass(label, name)
{
    MySWIGOutputDebugString(wxT("PyCustomProperty::PyCustomProperty()"));

    Init();
}

PyCustomProperty::~PyCustomProperty()
{
    MySWIGOutputDebugString(wxT("PyCustomProperty::~PyCustomProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyCustomProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyCustomProperty_pyClass )
    {
        gs_PyCustomProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyCustomProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


bool PyCustomProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::OnEvent() exit (fall-back)"));
        return wxCustomPropertyClass::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyCustomProperty::OnEvent() exit"));
}


wxString PyCustomProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::GetClassName() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return wxEmptyString;
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetClassName() exit"));
}


wxString PyCustomProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::GetType() exit (fall-back)"));
        return wxCustomPropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetType() exit"));
}


wxString PyCustomProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::GetEditor() exit (fall-back)"));
        return wxCustomPropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetEditor() exit"));
}


wxValidator* PyCustomProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::DoGetValidator() exit (fall-back)"));
        return wxCustomPropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyCustomProperty::DoGetValidator() exit"));
}


const wxPGPropertyClassInfo* PyCustomProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::GetClassInfo() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return NULL;
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetClassInfo() exit"));
}


void PyCustomProperty::RefreshChildren()
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::RefreshChildren() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_RefreshChildren_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_RefreshChildren_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::RefreshChildren() exit (fall-back)"));
        wxCustomPropertyClass::RefreshChildren();
        return;
    }
    _CommonCallback25(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyCustomProperty::RefreshChildren() exit"));
}


void PyCustomProperty::ChildChanged(wxPGProperty* p)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::ChildChanged() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_ChildChanged_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_ChildChanged_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::ChildChanged() exit (fall-back)"));
        wxCustomPropertyClass::ChildChanged(p);
        return;
    }
    _CommonCallback24(blocked, m_scriptObject, funcobj, p);
    MySWIGOutputDebugString(wxT("PyCustomProperty::ChildChanged() exit"));
}


void PyCustomProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::DoSetValue() exit (fall-back)"));
        wxCustomPropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyCustomProperty::DoSetValue() exit"));
}


wxVariant PyCustomProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::DoGetValue() exit (fall-back)"));
        return wxCustomPropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyCustomProperty::DoGetValue() exit"));
}


bool PyCustomProperty::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::SetValueFromString() exit (fall-back)"));
        return wxCustomPropertyClass::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyCustomProperty::SetValueFromString() exit"));
}


wxString PyCustomProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::GetValueAsString() exit (fall-back)"));
        return wxCustomPropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetValueAsString() exit"));
}


wxSize PyCustomProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::GetImageSize() exit (fall-back)"));
        return wxCustomPropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetImageSize() exit"));
}


void PyCustomProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::OnCustomPaint() exit (fall-back)"));
        wxCustomPropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyCustomProperty::OnCustomPaint() exit"));
}


bool PyCustomProperty::SetValueFromInt(long value, int arg_flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::SetValueFromInt() exit (fall-back)"));
        return wxCustomPropertyClass::SetValueFromInt(value, arg_flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, arg_flags);
    MySWIGOutputDebugString(wxT("PyCustomProperty::SetValueFromInt() exit"));
}


int PyCustomProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::GetChoiceInfo() exit (fall-back)"));
        return wxCustomPropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyCustomProperty::GetChoiceInfo() exit"));
}


void PyCustomProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyCustomProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyCustomProperty::SetAttribute() exit (fall-back)"));
        wxCustomPropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyCustomProperty::SetAttribute() exit"));
}


class PyTextCtrlAndButtonEditor : public wxPGTextCtrlAndButtonEditor {
public:
        PyTextCtrlAndButtonEditor();
    virtual ~PyTextCtrlAndButtonEditor();
    void _SetSelf(PyObject *self);
    virtual void SetControlIntValue( wxWindow* ctrl, int value ) const;
    virtual int InsertItem( wxWindow* ctrl, const wxString& label, int index ) const;
    virtual void DeleteItem( wxWindow* ctrl, int index ) const;
    virtual bool CanContainCustomImage() const;
    virtual void UpdateControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* primary, wxEvent& event ) const;
    virtual bool CopyValueFromControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual void SetValueToUnspecified( wxWindow* ctrl ) const;
    virtual void DrawValue( wxDC& dc, wxPGProperty* property, const wxRect& rect ) const;
    virtual void SetControlStringValue( wxWindow* ctrl, const wxString& txt ) const;
    virtual void OnFocus( wxPGProperty* property, wxWindow* wnd ) const;
    virtual wxString GetName() const;
    virtual wxPGWindowPair CreateControls( wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz ) const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyTextCtrlAndButtonEditor_pyClass = NULL;


PyTextCtrlAndButtonEditor::PyTextCtrlAndButtonEditor()
    : wxPGTextCtrlAndButtonEditor()
{
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::PyTextCtrlAndButtonEditor()"));

    Init();
}

PyTextCtrlAndButtonEditor::~PyTextCtrlAndButtonEditor()
{
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::~PyTextCtrlAndButtonEditor()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyTextCtrlAndButtonEditor::_SetSelf(PyObject *self)
{
    if ( !gs_PyTextCtrlAndButtonEditor_pyClass )
    {
        gs_PyTextCtrlAndButtonEditor_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyTextCtrlAndButtonEditor_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


void PyTextCtrlAndButtonEditor::SetControlIntValue(wxWindow* ctrl, int value) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::SetControlIntValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlIntValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlIntValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::SetControlIntValue() exit (fall-back)"));
        wxPGTextCtrlAndButtonEditor::SetControlIntValue(ctrl, value);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, value);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::SetControlIntValue() exit"));
}


int PyTextCtrlAndButtonEditor::InsertItem(wxWindow* ctrl, const wxString& label, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::InsertItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_InsertItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_InsertItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::InsertItem() exit (fall-back)"));
        return wxPGTextCtrlAndButtonEditor::InsertItem(ctrl, label, index);
    }
    return _CommonCallback1(blocked, m_scriptObject, funcobj, ctrl, label, index);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::InsertItem() exit"));
}


void PyTextCtrlAndButtonEditor::DeleteItem(wxWindow* ctrl, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::DeleteItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DeleteItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DeleteItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::DeleteItem() exit (fall-back)"));
        wxPGTextCtrlAndButtonEditor::DeleteItem(ctrl, index);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, index);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::DeleteItem() exit"));
}


bool PyTextCtrlAndButtonEditor::CanContainCustomImage() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::CanContainCustomImage() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CanContainCustomImage_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CanContainCustomImage_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::CanContainCustomImage() exit (fall-back)"));
        return wxPGTextCtrlAndButtonEditor::CanContainCustomImage();
    }
    return _CommonCallback4(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::CanContainCustomImage() exit"));
}


void PyTextCtrlAndButtonEditor::UpdateControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::UpdateControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_UpdateControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_UpdateControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::UpdateControl() exit (fall-back)"));
        wxPGTextCtrlAndButtonEditor::UpdateControl(property, ctrl);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::UpdateControl() exit"));
}


bool PyTextCtrlAndButtonEditor::OnEvent(wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* primary, wxEvent& event) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::OnEvent() exit (fall-back)"));
        return wxPGTextCtrlAndButtonEditor::OnEvent(propgrid, property, primary, event);
    }
    return _CommonCallback7(blocked, m_scriptObject, funcobj, propgrid, property, primary, event);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::OnEvent() exit"));
}


bool PyTextCtrlAndButtonEditor::CopyValueFromControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::CopyValueFromControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CopyValueFromControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CopyValueFromControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::CopyValueFromControl() exit (fall-back)"));
        return wxPGTextCtrlAndButtonEditor::CopyValueFromControl(property, ctrl);
    }
    return _CommonCallback8(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::CopyValueFromControl() exit"));
}


void PyTextCtrlAndButtonEditor::SetValueToUnspecified(wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::SetValueToUnspecified() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueToUnspecified_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueToUnspecified_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::SetValueToUnspecified() exit (fall-back)"));
        wxPGTextCtrlAndButtonEditor::SetValueToUnspecified(ctrl);
        return;
    }
    _CommonCallback9(blocked, m_scriptObject, funcobj, ctrl);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::SetValueToUnspecified() exit"));
}


void PyTextCtrlAndButtonEditor::DrawValue(wxDC& dc, wxPGProperty* property, const wxRect& rect) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::DrawValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DrawValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DrawValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::DrawValue() exit (fall-back)"));
        wxPGTextCtrlAndButtonEditor::DrawValue(dc, property, rect);
        return;
    }
    _CommonCallback10(blocked, m_scriptObject, funcobj, dc, property, rect);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::DrawValue() exit"));
}


void PyTextCtrlAndButtonEditor::SetControlStringValue(wxWindow* ctrl, const wxString& txt) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::SetControlStringValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlStringValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlStringValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::SetControlStringValue() exit (fall-back)"));
        wxPGTextCtrlAndButtonEditor::SetControlStringValue(ctrl, txt);
        return;
    }
    _CommonCallback0(blocked, m_scriptObject, funcobj, ctrl, txt);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::SetControlStringValue() exit"));
}


void PyTextCtrlAndButtonEditor::OnFocus(wxPGProperty* property, wxWindow* wnd) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::OnFocus() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnFocus_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnFocus_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::OnFocus() exit (fall-back)"));
        wxPGTextCtrlAndButtonEditor::OnFocus(property, wnd);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, wnd);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::OnFocus() exit"));
}


wxString PyTextCtrlAndButtonEditor::GetName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::GetName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::GetName() exit (fall-back)"));
        return wxPGTextCtrlAndButtonEditor::GetName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::GetName() exit"));
}


wxPGWindowPair PyTextCtrlAndButtonEditor::CreateControls(wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::CreateControls() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CreateControls_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CreateControls_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::CreateControls() exit (fall-back)"));
        return wxPGTextCtrlAndButtonEditor::CreateControls(propgrid, property, pos, sz);
    }
    return _CommonCallback6(blocked, m_scriptObject, funcobj, propgrid, property, pos, sz);
    MySWIGOutputDebugString(wxT("PyTextCtrlAndButtonEditor::CreateControls() exit"));
}


class PyImageFileProperty : public wxImageFilePropertyClass {
public:
        PyImageFileProperty( const wxString& label, const wxString& name, const wxString& value );
    virtual ~PyImageFileProperty();
    void _SetSelf(PyObject *self);
    virtual bool SetValueFromInt( long value, int flags = 0 );
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual const wxPGValueType* GetValueType() const;
    virtual wxVariant DoGetValue() const;
    virtual wxString GetValueAsString( int argFlags ) const;
    virtual bool SetValueFromString( const wxString& text, int flags );
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual wxValidator* DoGetValidator() const;
    virtual wxString GetClassName() const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual void DoSetValue ( wxVariant value );
    virtual wxSize GetImageSize() const;
    virtual void OnCustomPaint( wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata );
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyImageFileProperty_pyClass = NULL;


PyImageFileProperty::PyImageFileProperty(const wxString& label, const wxString& name, const wxString& value)
    : wxImageFilePropertyClass(label, name, value)
{
    MySWIGOutputDebugString(wxT("PyImageFileProperty::PyImageFileProperty()"));

    Init();
}

PyImageFileProperty::~PyImageFileProperty()
{
    MySWIGOutputDebugString(wxT("PyImageFileProperty::~PyImageFileProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyImageFileProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyImageFileProperty_pyClass )
    {
        gs_PyImageFileProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyImageFileProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


bool PyImageFileProperty::SetValueFromInt(long value, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::SetValueFromInt() exit (fall-back)"));
        return wxImageFilePropertyClass::SetValueFromInt(value, flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, flags);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::SetValueFromInt() exit"));
}


wxString PyImageFileProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::GetType() exit (fall-back)"));
        return wxImageFilePropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetType() exit"));
}


wxString PyImageFileProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::GetEditor() exit (fall-back)"));
        return wxImageFilePropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetEditor() exit"));
}


int PyImageFileProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::GetChoiceInfo() exit (fall-back)"));
        return wxImageFilePropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetChoiceInfo() exit"));
}


const wxPGValueType* PyImageFileProperty::GetValueType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetValueType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::GetValueType() exit (fall-back)"));
        return wxImageFilePropertyClass::GetValueType();
    }
    return _CommonCallback18(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetValueType() exit"));
}


wxVariant PyImageFileProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::DoGetValue() exit (fall-back)"));
        return wxImageFilePropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::DoGetValue() exit"));
}


wxString PyImageFileProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::GetValueAsString() exit (fall-back)"));
        return wxImageFilePropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetValueAsString() exit"));
}


bool PyImageFileProperty::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::SetValueFromString() exit (fall-back)"));
        return wxImageFilePropertyClass::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::SetValueFromString() exit"));
}


bool PyImageFileProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::OnEvent() exit (fall-back)"));
        return wxImageFilePropertyClass::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::OnEvent() exit"));
}


void PyImageFileProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::SetAttribute() exit (fall-back)"));
        wxImageFilePropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::SetAttribute() exit"));
}


wxValidator* PyImageFileProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::DoGetValidator() exit (fall-back)"));
        return wxImageFilePropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::DoGetValidator() exit"));
}


wxString PyImageFileProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::GetClassName() exit (fall-back)"));
        return wxImageFilePropertyClass::GetClassName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetClassName() exit"));
}


const wxPGPropertyClassInfo* PyImageFileProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::GetClassInfo() exit (fall-back)"));
        return wxImageFilePropertyClass::GetClassInfo();
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetClassInfo() exit"));
}


void PyImageFileProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::DoSetValue() exit (fall-back)"));
        wxImageFilePropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::DoSetValue() exit"));
}


wxSize PyImageFileProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::GetImageSize() exit (fall-back)"));
        return wxImageFilePropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::GetImageSize() exit"));
}


void PyImageFileProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyImageFileProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyImageFileProperty::OnCustomPaint() exit (fall-back)"));
        wxImageFilePropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyImageFileProperty::OnCustomPaint() exit"));
}


class PyStringProperty : public wxStringPropertyClass {
public:
        PyStringProperty( const wxString& label, const wxString& name, const wxString& value );
    virtual ~PyStringProperty();
    void _SetSelf(PyObject *self);
    virtual bool SetValueFromInt( long value, int flags = 0 );
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual wxSize GetImageSize() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual const wxPGValueType* GetValueType() const;
    virtual wxString GetClassName() const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual void DoSetValue ( wxVariant value );
    virtual wxVariant DoGetValue () const;
    virtual bool SetValueFromString ( const wxString& text, int flags = 0 );
    virtual wxString GetValueAsString ( int argFlags = 0 ) const;
    virtual void SetAttribute( int id, wxVariant& value );
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyStringProperty_pyClass = NULL;


PyStringProperty::PyStringProperty(const wxString& label, const wxString& name, const wxString& value)
    : wxStringPropertyClass(label, name, value)
{
    MySWIGOutputDebugString(wxT("PyStringProperty::PyStringProperty()"));

    Init();
}

PyStringProperty::~PyStringProperty()
{
    MySWIGOutputDebugString(wxT("PyStringProperty::~PyStringProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyStringProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyStringProperty_pyClass )
    {
        gs_PyStringProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyStringProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


bool PyStringProperty::SetValueFromInt(long value, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::SetValueFromInt() exit (fall-back)"));
        return wxStringPropertyClass::SetValueFromInt(value, flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, flags);
    MySWIGOutputDebugString(wxT("PyStringProperty::SetValueFromInt() exit"));
}


bool PyStringProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::OnEvent() exit (fall-back)"));
        return wxStringPropertyClass::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyStringProperty::OnEvent() exit"));
}


wxSize PyStringProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::GetImageSize() exit (fall-back)"));
        return wxStringPropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyStringProperty::GetImageSize() exit"));
}


wxString PyStringProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::GetType() exit (fall-back)"));
        return wxStringPropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyStringProperty::GetType() exit"));
}


wxString PyStringProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::GetEditor() exit (fall-back)"));
        return wxStringPropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyStringProperty::GetEditor() exit"));
}


wxValidator* PyStringProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::DoGetValidator() exit (fall-back)"));
        return wxStringPropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyStringProperty::DoGetValidator() exit"));
}


int PyStringProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::GetChoiceInfo() exit (fall-back)"));
        return wxStringPropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyStringProperty::GetChoiceInfo() exit"));
}


void PyStringProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::OnCustomPaint() exit (fall-back)"));
        wxStringPropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyStringProperty::OnCustomPaint() exit"));
}


const wxPGValueType* PyStringProperty::GetValueType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::GetValueType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::GetValueType() exit (fall-back)"));
        return wxStringPropertyClass::GetValueType();
    }
    return _CommonCallback18(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyStringProperty::GetValueType() exit"));
}


wxString PyStringProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::GetClassName() exit (fall-back)"));
        return wxStringPropertyClass::GetClassName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyStringProperty::GetClassName() exit"));
}


const wxPGPropertyClassInfo* PyStringProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::GetClassInfo() exit (fall-back)"));
        return wxStringPropertyClass::GetClassInfo();
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyStringProperty::GetClassInfo() exit"));
}


void PyStringProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::DoSetValue() exit (fall-back)"));
        wxStringPropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyStringProperty::DoSetValue() exit"));
}


wxVariant PyStringProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::DoGetValue() exit (fall-back)"));
        return wxStringPropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyStringProperty::DoGetValue() exit"));
}


bool PyStringProperty::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::SetValueFromString() exit (fall-back)"));
        return wxStringPropertyClass::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyStringProperty::SetValueFromString() exit"));
}


wxString PyStringProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::GetValueAsString() exit (fall-back)"));
        return wxStringPropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyStringProperty::GetValueAsString() exit"));
}


void PyStringProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyStringProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyStringProperty::SetAttribute() exit (fall-back)"));
        wxStringPropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyStringProperty::SetAttribute() exit"));
}


class PyEditor : public wxPGEditor {
public:
        PyEditor();
    virtual ~PyEditor();
    void _SetSelf(PyObject *self);
    virtual wxString GetName() const;
    virtual wxPGWindowPair CreateControls( wxPropertyGrid* propgrid, wxPGProperty* property,
        const wxPoint& pos, const wxSize& sz ) const;
    virtual void UpdateControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual void DrawValue( wxDC& dc, wxPGProperty* property, const wxRect& rect ) const;
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxPGProperty* property,
        wxWindow* wnd_primary, wxEvent& event ) const;
    virtual bool CopyValueFromControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual void SetValueToUnspecified( wxWindow* ctrl ) const;
    virtual void SetControlStringValue( wxWindow* ctrl, const wxString& txt ) const;
    virtual void SetControlIntValue( wxWindow* ctrl, int value ) const;
    virtual int InsertItem( wxWindow* ctrl, const wxString& label, int index ) const;
    virtual void DeleteItem( wxWindow* ctrl, int index ) const;
    virtual void OnFocus( wxPGProperty* property, wxWindow* wnd ) const;
    virtual bool CanContainCustomImage() const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyEditor_pyClass = NULL;


PyEditor::PyEditor()
    : wxPGEditor()
{
    MySWIGOutputDebugString(wxT("PyEditor::PyEditor()"));

    Init();
}

PyEditor::~PyEditor()
{
    MySWIGOutputDebugString(wxT("PyEditor::~PyEditor()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyEditor::_SetSelf(PyObject *self)
{
    if ( !gs_PyEditor_pyClass )
    {
        gs_PyEditor_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyEditor_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


wxString PyEditor::GetName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::GetName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::GetName() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return wxEmptyString;
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyEditor::GetName() exit"));
}


wxPGWindowPair PyEditor::CreateControls(wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::CreateControls() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CreateControls_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CreateControls_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::CreateControls() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return wxPGWindowPair();
    }
    return _CommonCallback6(blocked, m_scriptObject, funcobj, propgrid, property, pos, sz);
    MySWIGOutputDebugString(wxT("PyEditor::CreateControls() exit"));
}


void PyEditor::UpdateControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::UpdateControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_UpdateControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_UpdateControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::UpdateControl() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyEditor::UpdateControl() exit"));
}


void PyEditor::DrawValue(wxDC& dc, wxPGProperty* property, const wxRect& rect) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::DrawValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DrawValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DrawValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::DrawValue() exit (fall-back)"));
        wxPGEditor::DrawValue(dc, property, rect);
        return;
    }
    _CommonCallback10(blocked, m_scriptObject, funcobj, dc, property, rect);
    MySWIGOutputDebugString(wxT("PyEditor::DrawValue() exit"));
}


bool PyEditor::OnEvent(wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* wnd_primary, wxEvent& event) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::OnEvent() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return false;
    }
    return _CommonCallback7(blocked, m_scriptObject, funcobj, propgrid, property, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyEditor::OnEvent() exit"));
}


bool PyEditor::CopyValueFromControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::CopyValueFromControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CopyValueFromControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CopyValueFromControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::CopyValueFromControl() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return false;
    }
    return _CommonCallback8(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyEditor::CopyValueFromControl() exit"));
}


void PyEditor::SetValueToUnspecified(wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::SetValueToUnspecified() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueToUnspecified_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueToUnspecified_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::SetValueToUnspecified() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return;
    }
    _CommonCallback9(blocked, m_scriptObject, funcobj, ctrl);
    MySWIGOutputDebugString(wxT("PyEditor::SetValueToUnspecified() exit"));
}


void PyEditor::SetControlStringValue(wxWindow* ctrl, const wxString& txt) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::SetControlStringValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlStringValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlStringValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::SetControlStringValue() exit (fall-back)"));
        wxPGEditor::SetControlStringValue(ctrl, txt);
        return;
    }
    _CommonCallback0(blocked, m_scriptObject, funcobj, ctrl, txt);
    MySWIGOutputDebugString(wxT("PyEditor::SetControlStringValue() exit"));
}


void PyEditor::SetControlIntValue(wxWindow* ctrl, int value) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::SetControlIntValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlIntValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlIntValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::SetControlIntValue() exit (fall-back)"));
        wxPGEditor::SetControlIntValue(ctrl, value);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, value);
    MySWIGOutputDebugString(wxT("PyEditor::SetControlIntValue() exit"));
}


int PyEditor::InsertItem(wxWindow* ctrl, const wxString& label, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::InsertItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_InsertItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_InsertItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::InsertItem() exit (fall-back)"));
        return wxPGEditor::InsertItem(ctrl, label, index);
    }
    return _CommonCallback1(blocked, m_scriptObject, funcobj, ctrl, label, index);
    MySWIGOutputDebugString(wxT("PyEditor::InsertItem() exit"));
}


void PyEditor::DeleteItem(wxWindow* ctrl, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::DeleteItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DeleteItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DeleteItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::DeleteItem() exit (fall-back)"));
        wxPGEditor::DeleteItem(ctrl, index);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, index);
    MySWIGOutputDebugString(wxT("PyEditor::DeleteItem() exit"));
}


void PyEditor::OnFocus(wxPGProperty* property, wxWindow* wnd) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::OnFocus() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnFocus_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnFocus_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::OnFocus() exit (fall-back)"));
        wxPGEditor::OnFocus(property, wnd);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, wnd);
    MySWIGOutputDebugString(wxT("PyEditor::OnFocus() exit"));
}


bool PyEditor::CanContainCustomImage() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEditor::CanContainCustomImage() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CanContainCustomImage_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CanContainCustomImage_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEditor::CanContainCustomImage() exit (fall-back)"));
        return wxPGEditor::CanContainCustomImage();
    }
    return _CommonCallback4(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyEditor::CanContainCustomImage() exit"));
}


class PyChoiceEditor : public wxPGChoiceEditor {
public:
        PyChoiceEditor();
    virtual ~PyChoiceEditor();
    void _SetSelf(PyObject *self);
    virtual void DrawValue( wxDC& dc, wxPGProperty* property, const wxRect& rect ) const;
    virtual void OnFocus( wxPGProperty* property, wxWindow* wnd ) const;
    virtual wxString GetName() const;
    virtual wxPGWindowPair CreateControls( wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz ) const;
    virtual void UpdateControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* primary, wxEvent& event ) const;
    virtual bool CopyValueFromControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual void SetValueToUnspecified( wxWindow* ctrl ) const;
    virtual void SetControlIntValue( wxWindow* ctrl, int value ) const;
    virtual void SetControlStringValue( wxWindow* ctrl, const wxString& txt ) const;
    virtual int InsertItem( wxWindow* ctrl, const wxString& label, int index ) const;
    virtual void DeleteItem( wxWindow* ctrl, int index ) const;
    virtual bool CanContainCustomImage() const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyChoiceEditor_pyClass = NULL;


PyChoiceEditor::PyChoiceEditor()
    : wxPGChoiceEditor()
{
    MySWIGOutputDebugString(wxT("PyChoiceEditor::PyChoiceEditor()"));

    Init();
}

PyChoiceEditor::~PyChoiceEditor()
{
    MySWIGOutputDebugString(wxT("PyChoiceEditor::~PyChoiceEditor()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyChoiceEditor::_SetSelf(PyObject *self)
{
    if ( !gs_PyChoiceEditor_pyClass )
    {
        gs_PyChoiceEditor_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyChoiceEditor_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


void PyChoiceEditor::DrawValue(wxDC& dc, wxPGProperty* property, const wxRect& rect) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::DrawValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DrawValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DrawValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::DrawValue() exit (fall-back)"));
        wxPGChoiceEditor::DrawValue(dc, property, rect);
        return;
    }
    _CommonCallback10(blocked, m_scriptObject, funcobj, dc, property, rect);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::DrawValue() exit"));
}


void PyChoiceEditor::OnFocus(wxPGProperty* property, wxWindow* wnd) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::OnFocus() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnFocus_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnFocus_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::OnFocus() exit (fall-back)"));
        wxPGChoiceEditor::OnFocus(property, wnd);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, wnd);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::OnFocus() exit"));
}


wxString PyChoiceEditor::GetName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::GetName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::GetName() exit (fall-back)"));
        return wxPGChoiceEditor::GetName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::GetName() exit"));
}


wxPGWindowPair PyChoiceEditor::CreateControls(wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::CreateControls() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CreateControls_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CreateControls_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::CreateControls() exit (fall-back)"));
        return wxPGChoiceEditor::CreateControls(propgrid, property, pos, sz);
    }
    return _CommonCallback6(blocked, m_scriptObject, funcobj, propgrid, property, pos, sz);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::CreateControls() exit"));
}


void PyChoiceEditor::UpdateControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::UpdateControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_UpdateControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_UpdateControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::UpdateControl() exit (fall-back)"));
        wxPGChoiceEditor::UpdateControl(property, ctrl);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::UpdateControl() exit"));
}


bool PyChoiceEditor::OnEvent(wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* primary, wxEvent& event) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::OnEvent() exit (fall-back)"));
        return wxPGChoiceEditor::OnEvent(propgrid, property, primary, event);
    }
    return _CommonCallback7(blocked, m_scriptObject, funcobj, propgrid, property, primary, event);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::OnEvent() exit"));
}


bool PyChoiceEditor::CopyValueFromControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::CopyValueFromControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CopyValueFromControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CopyValueFromControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::CopyValueFromControl() exit (fall-back)"));
        return wxPGChoiceEditor::CopyValueFromControl(property, ctrl);
    }
    return _CommonCallback8(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::CopyValueFromControl() exit"));
}


void PyChoiceEditor::SetValueToUnspecified(wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::SetValueToUnspecified() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueToUnspecified_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueToUnspecified_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::SetValueToUnspecified() exit (fall-back)"));
        wxPGChoiceEditor::SetValueToUnspecified(ctrl);
        return;
    }
    _CommonCallback9(blocked, m_scriptObject, funcobj, ctrl);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::SetValueToUnspecified() exit"));
}


void PyChoiceEditor::SetControlIntValue(wxWindow* ctrl, int value) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::SetControlIntValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlIntValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlIntValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::SetControlIntValue() exit (fall-back)"));
        wxPGChoiceEditor::SetControlIntValue(ctrl, value);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, value);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::SetControlIntValue() exit"));
}


void PyChoiceEditor::SetControlStringValue(wxWindow* ctrl, const wxString& txt) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::SetControlStringValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlStringValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlStringValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::SetControlStringValue() exit (fall-back)"));
        wxPGChoiceEditor::SetControlStringValue(ctrl, txt);
        return;
    }
    _CommonCallback0(blocked, m_scriptObject, funcobj, ctrl, txt);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::SetControlStringValue() exit"));
}


int PyChoiceEditor::InsertItem(wxWindow* ctrl, const wxString& label, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::InsertItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_InsertItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_InsertItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::InsertItem() exit (fall-back)"));
        return wxPGChoiceEditor::InsertItem(ctrl, label, index);
    }
    return _CommonCallback1(blocked, m_scriptObject, funcobj, ctrl, label, index);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::InsertItem() exit"));
}


void PyChoiceEditor::DeleteItem(wxWindow* ctrl, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::DeleteItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DeleteItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DeleteItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::DeleteItem() exit (fall-back)"));
        wxPGChoiceEditor::DeleteItem(ctrl, index);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, index);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::DeleteItem() exit"));
}


bool PyChoiceEditor::CanContainCustomImage() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceEditor::CanContainCustomImage() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CanContainCustomImage_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CanContainCustomImage_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceEditor::CanContainCustomImage() exit (fall-back)"));
        return wxPGChoiceEditor::CanContainCustomImage();
    }
    return _CommonCallback4(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyChoiceEditor::CanContainCustomImage() exit"));
}


class PyChoiceAndButtonEditor : public wxPGChoiceAndButtonEditor {
public:
        PyChoiceAndButtonEditor();
    virtual ~PyChoiceAndButtonEditor();
    void _SetSelf(PyObject *self);
    virtual void DrawValue( wxDC& dc, wxPGProperty* property, const wxRect& rect ) const;
    virtual void OnFocus( wxPGProperty* property, wxWindow* wnd ) const;
    virtual void UpdateControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* primary, wxEvent& event ) const;
    virtual bool CopyValueFromControl( wxPGProperty* property, wxWindow* ctrl ) const;
    virtual void SetValueToUnspecified( wxWindow* ctrl ) const;
    virtual void SetControlIntValue( wxWindow* ctrl, int value ) const;
    virtual void SetControlStringValue( wxWindow* ctrl, const wxString& txt ) const;
    virtual int InsertItem( wxWindow* ctrl, const wxString& label, int index ) const;
    virtual void DeleteItem( wxWindow* ctrl, int index ) const;
    virtual bool CanContainCustomImage() const;
    virtual wxString GetName() const;
    virtual wxPGWindowPair CreateControls( wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz ) const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyChoiceAndButtonEditor_pyClass = NULL;


PyChoiceAndButtonEditor::PyChoiceAndButtonEditor()
    : wxPGChoiceAndButtonEditor()
{
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::PyChoiceAndButtonEditor()"));

    Init();
}

PyChoiceAndButtonEditor::~PyChoiceAndButtonEditor()
{
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::~PyChoiceAndButtonEditor()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyChoiceAndButtonEditor::_SetSelf(PyObject *self)
{
    if ( !gs_PyChoiceAndButtonEditor_pyClass )
    {
        gs_PyChoiceAndButtonEditor_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyChoiceAndButtonEditor_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


void PyChoiceAndButtonEditor::DrawValue(wxDC& dc, wxPGProperty* property, const wxRect& rect) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::DrawValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DrawValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DrawValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::DrawValue() exit (fall-back)"));
        wxPGChoiceAndButtonEditor::DrawValue(dc, property, rect);
        return;
    }
    _CommonCallback10(blocked, m_scriptObject, funcobj, dc, property, rect);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::DrawValue() exit"));
}


void PyChoiceAndButtonEditor::OnFocus(wxPGProperty* property, wxWindow* wnd) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::OnFocus() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnFocus_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnFocus_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::OnFocus() exit (fall-back)"));
        wxPGChoiceAndButtonEditor::OnFocus(property, wnd);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, wnd);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::OnFocus() exit"));
}


void PyChoiceAndButtonEditor::UpdateControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::UpdateControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_UpdateControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_UpdateControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::UpdateControl() exit (fall-back)"));
        wxPGChoiceAndButtonEditor::UpdateControl(property, ctrl);
        return;
    }
    _CommonCallback3(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::UpdateControl() exit"));
}


bool PyChoiceAndButtonEditor::OnEvent(wxPropertyGrid* propgrid, wxPGProperty* property, wxWindow* primary, wxEvent& event) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::OnEvent() exit (fall-back)"));
        return wxPGChoiceAndButtonEditor::OnEvent(propgrid, property, primary, event);
    }
    return _CommonCallback7(blocked, m_scriptObject, funcobj, propgrid, property, primary, event);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::OnEvent() exit"));
}


bool PyChoiceAndButtonEditor::CopyValueFromControl(wxPGProperty* property, wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::CopyValueFromControl() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CopyValueFromControl_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CopyValueFromControl_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::CopyValueFromControl() exit (fall-back)"));
        return wxPGChoiceAndButtonEditor::CopyValueFromControl(property, ctrl);
    }
    return _CommonCallback8(blocked, m_scriptObject, funcobj, property, ctrl);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::CopyValueFromControl() exit"));
}


void PyChoiceAndButtonEditor::SetValueToUnspecified(wxWindow* ctrl) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::SetValueToUnspecified() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueToUnspecified_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueToUnspecified_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::SetValueToUnspecified() exit (fall-back)"));
        wxPGChoiceAndButtonEditor::SetValueToUnspecified(ctrl);
        return;
    }
    _CommonCallback9(blocked, m_scriptObject, funcobj, ctrl);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::SetValueToUnspecified() exit"));
}


void PyChoiceAndButtonEditor::SetControlIntValue(wxWindow* ctrl, int value) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::SetControlIntValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlIntValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlIntValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::SetControlIntValue() exit (fall-back)"));
        wxPGChoiceAndButtonEditor::SetControlIntValue(ctrl, value);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, value);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::SetControlIntValue() exit"));
}


void PyChoiceAndButtonEditor::SetControlStringValue(wxWindow* ctrl, const wxString& txt) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::SetControlStringValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetControlStringValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetControlStringValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::SetControlStringValue() exit (fall-back)"));
        wxPGChoiceAndButtonEditor::SetControlStringValue(ctrl, txt);
        return;
    }
    _CommonCallback0(blocked, m_scriptObject, funcobj, ctrl, txt);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::SetControlStringValue() exit"));
}


int PyChoiceAndButtonEditor::InsertItem(wxWindow* ctrl, const wxString& label, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::InsertItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_InsertItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_InsertItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::InsertItem() exit (fall-back)"));
        return wxPGChoiceAndButtonEditor::InsertItem(ctrl, label, index);
    }
    return _CommonCallback1(blocked, m_scriptObject, funcobj, ctrl, label, index);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::InsertItem() exit"));
}


void PyChoiceAndButtonEditor::DeleteItem(wxWindow* ctrl, int index) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::DeleteItem() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DeleteItem_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DeleteItem_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::DeleteItem() exit (fall-back)"));
        wxPGChoiceAndButtonEditor::DeleteItem(ctrl, index);
        return;
    }
    _CommonCallback2(blocked, m_scriptObject, funcobj, ctrl, index);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::DeleteItem() exit"));
}


bool PyChoiceAndButtonEditor::CanContainCustomImage() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::CanContainCustomImage() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CanContainCustomImage_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CanContainCustomImage_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::CanContainCustomImage() exit (fall-back)"));
        return wxPGChoiceAndButtonEditor::CanContainCustomImage();
    }
    return _CommonCallback4(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::CanContainCustomImage() exit"));
}


wxString PyChoiceAndButtonEditor::GetName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::GetName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::GetName() exit (fall-back)"));
        return wxPGChoiceAndButtonEditor::GetName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::GetName() exit"));
}


wxPGWindowPair PyChoiceAndButtonEditor::CreateControls(wxPropertyGrid* propgrid, wxPGProperty* property, const wxPoint& pos, const wxSize& sz) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::CreateControls() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CreateControls_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CreateControls_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::CreateControls() exit (fall-back)"));
        return wxPGChoiceAndButtonEditor::CreateControls(propgrid, property, pos, sz);
    }
    return _CommonCallback6(blocked, m_scriptObject, funcobj, propgrid, property, pos, sz);
    MySWIGOutputDebugString(wxT("PyChoiceAndButtonEditor::CreateControls() exit"));
}


class PyProperty : public wxPGProperty {
public:
        PyProperty( const wxString& label, const wxString& name );
    virtual ~PyProperty();
    void _SetSelf(PyObject *self);
    virtual void DoSetValue( wxVariant value );
    virtual wxVariant DoGetValue() const;
    virtual bool SetValueFromString( const wxString& text, int flags = 0 );
    virtual wxString GetValueAsString( int argFlags = 0 ) const;
    virtual bool SetValueFromInt( long value, int flags = 0 );
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual wxSize GetImageSize() const;
    virtual wxString GetClassName() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyProperty_pyClass = NULL;


PyProperty::PyProperty(const wxString& label, const wxString& name)
    : wxPGProperty(label, name)
{
    MySWIGOutputDebugString(wxT("PyProperty::PyProperty()"));

    Init();
}

PyProperty::~PyProperty()
{
    MySWIGOutputDebugString(wxT("PyProperty::~PyProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyProperty_pyClass )
    {
        gs_PyProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


void PyProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::DoSetValue() exit (fall-back)"));
        wxPGProperty::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyProperty::DoSetValue() exit"));
}


wxVariant PyProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::DoGetValue() exit (fall-back)"));
        return wxPGProperty::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyProperty::DoGetValue() exit"));
}


bool PyProperty::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::SetValueFromString() exit (fall-back)"));
        return wxPGProperty::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyProperty::SetValueFromString() exit"));
}


wxString PyProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::GetValueAsString() exit (fall-back)"));
        return wxPGProperty::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyProperty::GetValueAsString() exit"));
}


bool PyProperty::SetValueFromInt(long value, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::SetValueFromInt() exit (fall-back)"));
        return wxPGProperty::SetValueFromInt(value, flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, flags);
    MySWIGOutputDebugString(wxT("PyProperty::SetValueFromInt() exit"));
}


bool PyProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::OnEvent() exit (fall-back)"));
        return wxPGProperty::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyProperty::OnEvent() exit"));
}


wxSize PyProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::GetImageSize() exit (fall-back)"));
        return wxPGProperty::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyProperty::GetImageSize() exit"));
}


wxString PyProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::GetClassName() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return wxEmptyString;
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyProperty::GetClassName() exit"));
}


wxString PyProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::GetType() exit (fall-back)"));
        return wxPGProperty::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyProperty::GetType() exit"));
}


wxString PyProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::GetEditor() exit (fall-back)"));
        return wxPGProperty::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyProperty::GetEditor() exit"));
}


wxValidator* PyProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::DoGetValidator() exit (fall-back)"));
        return wxPGProperty::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyProperty::DoGetValidator() exit"));
}


int PyProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::GetChoiceInfo() exit (fall-back)"));
        return wxPGProperty::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyProperty::GetChoiceInfo() exit"));
}


void PyProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::OnCustomPaint() exit (fall-back)"));
        wxPGProperty::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyProperty::OnCustomPaint() exit"));
}


void PyProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::SetAttribute() exit (fall-back)"));
        wxPGProperty::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyProperty::SetAttribute() exit"));
}


const wxPGPropertyClassInfo* PyProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyProperty::GetClassInfo() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return NULL;
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyProperty::GetClassInfo() exit"));
}


class PyEnumProperty : public wxEnumPropertyClass {
public:
        PyEnumProperty( const wxString& label, const wxString& name,
        const wxArrayString& labels, const wxArrayInt& values = wxArrayInt(), int value = 0 );
    virtual ~PyEnumProperty();
    void _SetSelf(PyObject *self);
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual wxSize GetImageSize() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual void DoSetValue( wxVariant value );
    virtual wxVariant DoGetValue() const;
    virtual wxString GetValueAsString( int argFlags ) const;
    virtual bool SetValueFromString( const wxString& text, int argFlags );
    virtual bool SetValueFromInt( long value, int argFlags );
    virtual const wxPGValueType* GetValueType() const;
    virtual wxString GetClassName() const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual int GetIndexForValue( int value ) const;
    virtual const wxString* GetEntry( size_t index, int* pvalue ) const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyEnumProperty_pyClass = NULL;


PyEnumProperty::PyEnumProperty(const wxString& label, const wxString& name, const wxArrayString& labels, const wxArrayInt& values, int value)
    : wxEnumPropertyClass(label, name, labels, values, value)
{
    MySWIGOutputDebugString(wxT("PyEnumProperty::PyEnumProperty()"));

    Init();
}

PyEnumProperty::~PyEnumProperty()
{
    MySWIGOutputDebugString(wxT("PyEnumProperty::~PyEnumProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyEnumProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyEnumProperty_pyClass )
    {
        gs_PyEnumProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyEnumProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


bool PyEnumProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::OnEvent() exit (fall-back)"));
        return wxEnumPropertyClass::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyEnumProperty::OnEvent() exit"));
}


wxSize PyEnumProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::GetImageSize() exit (fall-back)"));
        return wxEnumPropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetImageSize() exit"));
}


wxString PyEnumProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::GetType() exit (fall-back)"));
        return wxEnumPropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetType() exit"));
}


wxString PyEnumProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::GetEditor() exit (fall-back)"));
        return wxEnumPropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetEditor() exit"));
}


wxValidator* PyEnumProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::DoGetValidator() exit (fall-back)"));
        return wxEnumPropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyEnumProperty::DoGetValidator() exit"));
}


void PyEnumProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::OnCustomPaint() exit (fall-back)"));
        wxEnumPropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyEnumProperty::OnCustomPaint() exit"));
}


void PyEnumProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::SetAttribute() exit (fall-back)"));
        wxEnumPropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyEnumProperty::SetAttribute() exit"));
}


void PyEnumProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::DoSetValue() exit (fall-back)"));
        wxEnumPropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyEnumProperty::DoSetValue() exit"));
}


wxVariant PyEnumProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::DoGetValue() exit (fall-back)"));
        return wxEnumPropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyEnumProperty::DoGetValue() exit"));
}


wxString PyEnumProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::GetValueAsString() exit (fall-back)"));
        return wxEnumPropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetValueAsString() exit"));
}


bool PyEnumProperty::SetValueFromString(const wxString& text, int argFlags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::SetValueFromString() exit (fall-back)"));
        return wxEnumPropertyClass::SetValueFromString(text, argFlags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, argFlags);
    MySWIGOutputDebugString(wxT("PyEnumProperty::SetValueFromString() exit"));
}


bool PyEnumProperty::SetValueFromInt(long value, int argFlags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::SetValueFromInt() exit (fall-back)"));
        return wxEnumPropertyClass::SetValueFromInt(value, argFlags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, argFlags);
    MySWIGOutputDebugString(wxT("PyEnumProperty::SetValueFromInt() exit"));
}


const wxPGValueType* PyEnumProperty::GetValueType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetValueType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::GetValueType() exit (fall-back)"));
        return wxEnumPropertyClass::GetValueType();
    }
    return _CommonCallback18(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetValueType() exit"));
}


wxString PyEnumProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::GetClassName() exit (fall-back)"));
        return wxEnumPropertyClass::GetClassName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetClassName() exit"));
}


const wxPGPropertyClassInfo* PyEnumProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::GetClassInfo() exit (fall-back)"));
        return wxEnumPropertyClass::GetClassInfo();
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetClassInfo() exit"));
}


int PyEnumProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::GetChoiceInfo() exit (fall-back)"));
        return wxEnumPropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetChoiceInfo() exit"));
}


int PyEnumProperty::GetIndexForValue(int value) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetIndexForValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetIndexForValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetIndexForValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::GetIndexForValue() exit (fall-back)"));
        return wxEnumPropertyClass::GetIndexForValue(value);
    }
    return _CommonCallback26(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetIndexForValue() exit"));
}


const wxString* PyEnumProperty::GetEntry(size_t index, int* pvalue) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetEntry() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEntry_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEntry_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyEnumProperty::GetEntry() exit (fall-back)"));
        return wxEnumPropertyClass::GetEntry(index, pvalue);
    }
    return _CommonCallback27(blocked, m_scriptObject, funcobj, index, pvalue);
    MySWIGOutputDebugString(wxT("PyEnumProperty::GetEntry() exit"));
}


class PyBaseEnumProperty : public wxBaseEnumPropertyClass {
public:
        PyBaseEnumProperty( const wxString& label, const wxString& name );
    virtual ~PyBaseEnumProperty();
    void _SetSelf(PyObject *self);
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual wxSize GetImageSize() const;
    virtual wxString GetClassName() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual void DoSetValue( wxVariant value );
    virtual wxVariant DoGetValue() const;
    virtual wxString GetValueAsString( int argFlags ) const;
    virtual bool SetValueFromString( const wxString& text, int argFlags );
    virtual bool SetValueFromInt( long value, int argFlags );
    virtual int GetIndexForValue( int value ) const;
    virtual const wxString* GetEntry( size_t index, int* pvalue ) const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyBaseEnumProperty_pyClass = NULL;


PyBaseEnumProperty::PyBaseEnumProperty(const wxString& label, const wxString& name)
    : wxBaseEnumPropertyClass(label, name)
{
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::PyBaseEnumProperty()"));

    Init();
}

PyBaseEnumProperty::~PyBaseEnumProperty()
{
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::~PyBaseEnumProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyBaseEnumProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyBaseEnumProperty_pyClass )
    {
        gs_PyBaseEnumProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyBaseEnumProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


bool PyBaseEnumProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::OnEvent() exit (fall-back)"));
        return wxBaseEnumPropertyClass::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::OnEvent() exit"));
}


wxSize PyBaseEnumProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetImageSize() exit (fall-back)"));
        return wxBaseEnumPropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetImageSize() exit"));
}


wxString PyBaseEnumProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetClassName() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return wxEmptyString;
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetClassName() exit"));
}


wxString PyBaseEnumProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetType() exit (fall-back)"));
        return wxBaseEnumPropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetType() exit"));
}


wxString PyBaseEnumProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetEditor() exit (fall-back)"));
        return wxBaseEnumPropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetEditor() exit"));
}


wxValidator* PyBaseEnumProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::DoGetValidator() exit (fall-back)"));
        return wxBaseEnumPropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::DoGetValidator() exit"));
}


int PyBaseEnumProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetChoiceInfo() exit (fall-back)"));
        return wxBaseEnumPropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetChoiceInfo() exit"));
}


void PyBaseEnumProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::OnCustomPaint() exit (fall-back)"));
        wxBaseEnumPropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::OnCustomPaint() exit"));
}


void PyBaseEnumProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::SetAttribute() exit (fall-back)"));
        wxBaseEnumPropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::SetAttribute() exit"));
}


const wxPGPropertyClassInfo* PyBaseEnumProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetClassInfo() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return NULL;
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetClassInfo() exit"));
}


void PyBaseEnumProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::DoSetValue() exit (fall-back)"));
        wxBaseEnumPropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::DoSetValue() exit"));
}


wxVariant PyBaseEnumProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::DoGetValue() exit (fall-back)"));
        return wxBaseEnumPropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::DoGetValue() exit"));
}


wxString PyBaseEnumProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetValueAsString() exit (fall-back)"));
        return wxBaseEnumPropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetValueAsString() exit"));
}


bool PyBaseEnumProperty::SetValueFromString(const wxString& text, int argFlags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::SetValueFromString() exit (fall-back)"));
        return wxBaseEnumPropertyClass::SetValueFromString(text, argFlags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, argFlags);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::SetValueFromString() exit"));
}


bool PyBaseEnumProperty::SetValueFromInt(long value, int argFlags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::SetValueFromInt() exit (fall-back)"));
        return wxBaseEnumPropertyClass::SetValueFromInt(value, argFlags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, argFlags);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::SetValueFromInt() exit"));
}


int PyBaseEnumProperty::GetIndexForValue(int value) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetIndexForValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetIndexForValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetIndexForValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetIndexForValue() exit (fall-back)"));
        return wxBaseEnumPropertyClass::GetIndexForValue(value);
    }
    return _CommonCallback26(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetIndexForValue() exit"));
}


const wxString* PyBaseEnumProperty::GetEntry(size_t index, int* pvalue) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetEntry() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEntry_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEntry_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetEntry() exit (not implemented!!!)"));
        PyErr_SetString(PyExc_TypeError,"this method must be implemented");
        return NULL;
    }
    return _CommonCallback27(blocked, m_scriptObject, funcobj, index, pvalue);
    MySWIGOutputDebugString(wxT("PyBaseEnumProperty::GetEntry() exit"));
}


class PyArrayStringProperty : public wxArrayStringPropertyClass {
public:
        PyArrayStringProperty( const wxString& label,
                                const wxString& name,
                                const wxArrayString& value );
    virtual ~PyArrayStringProperty();
    void _SetSelf(PyObject *self);
    virtual bool SetValueFromInt( long value, int flags = 0 );
    virtual wxSize GetImageSize() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual const wxPGValueType* GetValueType() const;
    virtual wxString GetClassName() const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual void DoSetValue ( wxVariant value );
    virtual wxVariant DoGetValue () const;
    virtual bool SetValueFromString ( const wxString& text, int flags = 0 );
    virtual wxString GetValueAsString ( int argFlags = 0 ) const;
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* primary, wxEvent& event );
    virtual void GenerateValueAsString();
    virtual bool OnCustomStringEdit( wxWindow* parent, wxString& value );
    virtual bool OnButtonClick( wxPropertyGrid* propgrid,
                                wxWindow* primary,
                                const wxChar* cbt );
    virtual wxArrayEditorDialog* CreateEditorDialog();
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyArrayStringProperty_pyClass = NULL;


PyArrayStringProperty::PyArrayStringProperty(const wxString& label, const wxString& name, const wxArrayString& value)
    : wxArrayStringPropertyClass(label, name, value)
{
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::PyArrayStringProperty()"));

    Init();
}

PyArrayStringProperty::~PyArrayStringProperty()
{
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::~PyArrayStringProperty()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyArrayStringProperty::_SetSelf(PyObject *self)
{
    if ( !gs_PyArrayStringProperty_pyClass )
    {
        gs_PyArrayStringProperty_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyArrayStringProperty_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


bool PyArrayStringProperty::SetValueFromInt(long value, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::SetValueFromInt() exit (fall-back)"));
        return wxArrayStringPropertyClass::SetValueFromInt(value, flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, flags);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::SetValueFromInt() exit"));
}


wxSize PyArrayStringProperty::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetImageSize() exit (fall-back)"));
        return wxArrayStringPropertyClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetImageSize() exit"));
}


wxString PyArrayStringProperty::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetType() exit (fall-back)"));
        return wxArrayStringPropertyClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetType() exit"));
}


wxString PyArrayStringProperty::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetEditor() exit (fall-back)"));
        return wxArrayStringPropertyClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetEditor() exit"));
}


wxValidator* PyArrayStringProperty::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::DoGetValidator() exit (fall-back)"));
        return wxArrayStringPropertyClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::DoGetValidator() exit"));
}


int PyArrayStringProperty::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetChoiceInfo() exit (fall-back)"));
        return wxArrayStringPropertyClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetChoiceInfo() exit"));
}


void PyArrayStringProperty::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnCustomPaint() exit (fall-back)"));
        wxArrayStringPropertyClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnCustomPaint() exit"));
}


void PyArrayStringProperty::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::SetAttribute() exit (fall-back)"));
        wxArrayStringPropertyClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::SetAttribute() exit"));
}


const wxPGValueType* PyArrayStringProperty::GetValueType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetValueType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetValueType() exit (fall-back)"));
        return wxArrayStringPropertyClass::GetValueType();
    }
    return _CommonCallback18(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetValueType() exit"));
}


wxString PyArrayStringProperty::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetClassName() exit (fall-back)"));
        return wxArrayStringPropertyClass::GetClassName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetClassName() exit"));
}


const wxPGPropertyClassInfo* PyArrayStringProperty::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetClassInfo() exit (fall-back)"));
        return wxArrayStringPropertyClass::GetClassInfo();
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetClassInfo() exit"));
}


void PyArrayStringProperty::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::DoSetValue() exit (fall-back)"));
        wxArrayStringPropertyClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::DoSetValue() exit"));
}


wxVariant PyArrayStringProperty::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::DoGetValue() exit (fall-back)"));
        return wxArrayStringPropertyClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::DoGetValue() exit"));
}


bool PyArrayStringProperty::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::SetValueFromString() exit (fall-back)"));
        return wxArrayStringPropertyClass::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::SetValueFromString() exit"));
}


wxString PyArrayStringProperty::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetValueAsString() exit (fall-back)"));
        return wxArrayStringPropertyClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GetValueAsString() exit"));
}


bool PyArrayStringProperty::OnEvent(wxPropertyGrid* propgrid, wxWindow* primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnEvent() exit (fall-back)"));
        return wxArrayStringPropertyClass::OnEvent(propgrid, primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, primary, event);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnEvent() exit"));
}


void PyArrayStringProperty::GenerateValueAsString()
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GenerateValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GenerateValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GenerateValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::GenerateValueAsString() exit (fall-back)"));
        wxArrayStringPropertyClass::GenerateValueAsString();
        return;
    }
    _CommonCallback25(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::GenerateValueAsString() exit"));
}


bool PyArrayStringProperty::OnCustomStringEdit(wxWindow* parent, wxString& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnCustomStringEdit() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomStringEdit_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomStringEdit_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnCustomStringEdit() exit (fall-back)"));
        return wxArrayStringPropertyClass::OnCustomStringEdit(parent, value);
    }
    PyObject* res;
    PyObject* py_parent;
    py_parent = wxPyMake_wxObject(parent, (bool)0);

    PyObject* py_value;
    #if wxUSE_UNICODE
        py_value = PyUnicode_FromWideChar((&value)->c_str(), (&value)->Len());
    #else
        py_value = PyString_FromStringAndSize((&value)->c_str(), (&value)->Len());
    #endif

    res = PyObject_CallFunctionObjArgs(funcobj, m_scriptObject, py_parent, py_value, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_value);
    Py_DECREF(py_parent);
    if (PyErr_Occurred()) SWIG_fail;
    {
    bool retval;
        if ( !SWIG_IsOK(SWIG_AsVal_bool(res, &retval)) ) {
        PyErr_SetString(PyExc_TypeError,"expected bool");
        SWIG_fail;
    }
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return false;
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnCustomStringEdit() exit"));
}


bool PyArrayStringProperty::OnButtonClick(wxPropertyGrid* propgrid, wxWindow* primary, const wxChar* cbt)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnButtonClick() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnButtonClick_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnButtonClick_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnButtonClick() exit (fall-back)"));
        return wxArrayStringPropertyClass::OnButtonClick(propgrid, primary, cbt);
    }
    PyObject* res;
    PyObject* py_propgrid;
    py_propgrid = SWIG_NewPointerObj((void*)propgrid, SWIGTYPE_p_wxPropertyGrid, 0);
    PyObject* py_primary;
    py_primary = wxPyMake_wxObject(primary, (bool)0);

    PyObject* py_cbt;
    #if wxUSE_UNICODE
        py_cbt = PyUnicode_FromWideChar(cbt, wxStrlen(cbt));
    #else
        py_cbt = PyString_FromStringAndSize(cbt, wxStrlen(cbt));
    #endif

    res = PyObject_CallFunctionObjArgs(funcobj, m_scriptObject, py_propgrid, py_primary, py_cbt, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_cbt);
    Py_DECREF(py_primary);
    Py_DECREF(py_propgrid);
    if (PyErr_Occurred()) SWIG_fail;
    {
    bool retval;
        if ( !SWIG_IsOK(SWIG_AsVal_bool(res, &retval)) ) {
        PyErr_SetString(PyExc_TypeError,"expected bool");
        SWIG_fail;
    }
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return false;
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::OnButtonClick() exit"));
}


wxArrayEditorDialog* PyArrayStringProperty::CreateEditorDialog()
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::CreateEditorDialog() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_CreateEditorDialog_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_CreateEditorDialog_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyArrayStringProperty::CreateEditorDialog() exit (fall-back)"));
        return wxArrayStringPropertyClass::CreateEditorDialog();
    }
    PyObject* res;
    res = PyObject_CallFunctionObjArgs(funcobj, m_scriptObject, NULL);
    Py_DECREF(funcobj);
    if (PyErr_Occurred()) SWIG_fail;
    {
    wxArrayEditorDialog* retval;
    if ( !SWIG_IsOK(SWIG_ConvertPtr(res, (void**)&(retval), SWIGTYPE_p_wxArrayEditorDialog, 0)) ) {
        PyErr_SetString(PyExc_TypeError,"expected wxArrayEditorDialog");
        SWIG_fail;
    }
    PyObject_SetAttrString(res, "thisown", Py_False);
    Py_DECREF(res);
    wxPyEndBlockThreads(blocked);
    return retval;
    }
  fail:
    if ( PyErr_Occurred() ) PyErr_Print();
    wxPyEndBlockThreads(blocked);
    return NULL;
    MySWIGOutputDebugString(wxT("PyArrayStringProperty::CreateEditorDialog() exit"));
}


class PyPropertyCategory : public wxPropertyCategoryClass {
public:
        PyPropertyCategory();
    PyPropertyCategory( const wxString& label, const wxString& name = wxString_wxPG_LABEL );
    virtual ~PyPropertyCategory();
    void _SetSelf(PyObject *self);
    virtual void DoSetValue( wxVariant value );
    virtual wxVariant DoGetValue() const;
    virtual bool SetValueFromInt( long value, int flags = 0 );
    virtual bool OnEvent( wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event );
    virtual wxSize GetImageSize() const;
    virtual wxString GetType() const;
    virtual wxString GetEditor() const;
    virtual wxValidator* DoGetValidator () const;
    virtual int GetChoiceInfo( wxPGChoiceInfo* choiceinfo );
    virtual void OnCustomPaint( wxDC& dc,
        const wxRect& rect, wxPGPaintData& paintdata );
    virtual void SetAttribute( int id, wxVariant& value );
    virtual bool SetValueFromString( const wxString& text, int flags );
    virtual void RefreshChildren();
    virtual void ChildChanged( wxPGProperty* p );
    virtual const wxPGValueType* GetValueType() const;
    virtual wxString GetClassName() const;
    virtual const wxPGPropertyClassInfo* GetClassInfo() const;
    virtual wxString GetValueAsString( int argFlags ) const;
private:
    void Init() { if ( !gs_funcNamesInitialized ) _InitFuncNames(); }
};

static PyObject* gs_PyPropertyCategory_pyClass = NULL;


PyPropertyCategory::PyPropertyCategory()
    : wxPropertyCategoryClass()
{
    MySWIGOutputDebugString(wxT("PyPropertyCategory::PyPropertyCategory()"));

    Init();
}

PyPropertyCategory::PyPropertyCategory(const wxString& label, const wxString& name)
    : wxPropertyCategoryClass(label, name)
{
    MySWIGOutputDebugString(wxT("PyPropertyCategory::PyPropertyCategory()"));

    Init();
}

PyPropertyCategory::~PyPropertyCategory()
{
    MySWIGOutputDebugString(wxT("PyPropertyCategory::~PyPropertyCategory()"));
    if (m_scriptObject) { _deleteOwningObject(m_scriptObject); m_scriptObject = NULL; }
}

void PyPropertyCategory::_SetSelf(PyObject *self)
{
    if ( !gs_PyPropertyCategory_pyClass )
    {
        gs_PyPropertyCategory_pyClass = PyObject_GetAttr(self, gs___class___Name);
        Py_DECREF(gs_PyPropertyCategory_pyClass);
    }
    if ( !m_scriptObject ) {
        m_scriptObject = self;
        Py_INCREF(self);
    }
}


void PyPropertyCategory::DoSetValue(wxVariant value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::DoSetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoSetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoSetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::DoSetValue() exit (fall-back)"));
        wxPropertyCategoryClass::DoSetValue(value);
        return;
    }
    _CommonCallback20(blocked, m_scriptObject, funcobj, value);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::DoSetValue() exit"));
}


wxVariant PyPropertyCategory::DoGetValue() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::DoGetValue() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValue_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValue_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::DoGetValue() exit (fall-back)"));
        return wxPropertyCategoryClass::DoGetValue();
    }
    return _CommonCallback21(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::DoGetValue() exit"));
}


bool PyPropertyCategory::SetValueFromInt(long value, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::SetValueFromInt() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromInt_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromInt_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::SetValueFromInt() exit (fall-back)"));
        return wxPropertyCategoryClass::SetValueFromInt(value, flags);
    }
    return _CommonCallback11(blocked, m_scriptObject, funcobj, value, flags);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::SetValueFromInt() exit"));
}


bool PyPropertyCategory::OnEvent(wxPropertyGrid* propgrid, wxWindow* wnd_primary, wxEvent& event)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::OnEvent() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnEvent_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnEvent_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::OnEvent() exit (fall-back)"));
        return wxPropertyCategoryClass::OnEvent(propgrid, wnd_primary, event);
    }
    return _CommonCallback22(blocked, m_scriptObject, funcobj, propgrid, wnd_primary, event);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::OnEvent() exit"));
}


wxSize PyPropertyCategory::GetImageSize() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetImageSize() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetImageSize_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetImageSize_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::GetImageSize() exit (fall-back)"));
        return wxPropertyCategoryClass::GetImageSize();
    }
    return _CommonCallback12(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetImageSize() exit"));
}


wxString PyPropertyCategory::GetType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::GetType() exit (fall-back)"));
        return wxPropertyCategoryClass::GetType();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetType() exit"));
}


wxString PyPropertyCategory::GetEditor() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetEditor() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetEditor_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetEditor_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::GetEditor() exit (fall-back)"));
        return wxPropertyCategoryClass::GetEditor();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetEditor() exit"));
}


wxValidator* PyPropertyCategory::DoGetValidator() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::DoGetValidator() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_DoGetValidator_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_DoGetValidator_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::DoGetValidator() exit (fall-back)"));
        return wxPropertyCategoryClass::DoGetValidator();
    }
    return _CommonCallback13(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::DoGetValidator() exit"));
}


int PyPropertyCategory::GetChoiceInfo(wxPGChoiceInfo* choiceinfo)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetChoiceInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetChoiceInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetChoiceInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::GetChoiceInfo() exit (fall-back)"));
        return wxPropertyCategoryClass::GetChoiceInfo(choiceinfo);
    }
    return _CommonCallback14(blocked, m_scriptObject, funcobj, choiceinfo);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetChoiceInfo() exit"));
}


void PyPropertyCategory::OnCustomPaint(wxDC& dc, const wxRect& rect, wxPGPaintData& paintdata)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::OnCustomPaint() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_OnCustomPaint_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_OnCustomPaint_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::OnCustomPaint() exit (fall-back)"));
        wxPropertyCategoryClass::OnCustomPaint(dc, rect, paintdata);
        return;
    }
    _CommonCallback15(blocked, m_scriptObject, funcobj, dc, rect, paintdata);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::OnCustomPaint() exit"));
}


void PyPropertyCategory::SetAttribute(int id, wxVariant& value)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::SetAttribute() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetAttribute_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetAttribute_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::SetAttribute() exit (fall-back)"));
        wxPropertyCategoryClass::SetAttribute(id, value);
        return;
    }
    _CommonCallback16(blocked, m_scriptObject, funcobj, id, value);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::SetAttribute() exit"));
}


bool PyPropertyCategory::SetValueFromString(const wxString& text, int flags)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::SetValueFromString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_SetValueFromString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_SetValueFromString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::SetValueFromString() exit (fall-back)"));
        return wxPropertyCategoryClass::SetValueFromString(text, flags);
    }
    return _CommonCallback17(blocked, m_scriptObject, funcobj, text, flags);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::SetValueFromString() exit"));
}


void PyPropertyCategory::RefreshChildren()
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::RefreshChildren() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_RefreshChildren_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_RefreshChildren_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::RefreshChildren() exit (fall-back)"));
        wxPropertyCategoryClass::RefreshChildren();
        return;
    }
    _CommonCallback25(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::RefreshChildren() exit"));
}


void PyPropertyCategory::ChildChanged(wxPGProperty* p)
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::ChildChanged() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_ChildChanged_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_ChildChanged_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::ChildChanged() exit (fall-back)"));
        wxPropertyCategoryClass::ChildChanged(p);
        return;
    }
    PyObject* res;
    PyObject* py_p;
        py_p = NULL;
    if ( p->m_scriptObject ) py_p = p->m_scriptObject;
    if ( py_p ) Py_INCREF(py_p);
    else py_p = SWIG_NewPointerObj((void*)p, SWIGTYPE_p_wxPGProperty, 0);

    res = PyObject_CallFunctionObjArgs(funcobj, m_scriptObject, py_p, NULL);
    Py_DECREF(funcobj);
    Py_DECREF(py_p);
    if (PyErr_Occurred()) SWIG_fail;
    {
    Py_DECREF(res);
    }
  fail:
    wxPyEndBlockThreads(blocked);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::ChildChanged() exit"));
}


const wxPGValueType* PyPropertyCategory::GetValueType() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetValueType() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueType_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueType_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::GetValueType() exit (fall-back)"));
        return wxPropertyCategoryClass::GetValueType();
    }
    return _CommonCallback18(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetValueType() exit"));
}


wxString PyPropertyCategory::GetClassName() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetClassName() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassName_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassName_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::GetClassName() exit (fall-back)"));
        return wxPropertyCategoryClass::GetClassName();
    }
    return _CommonCallback5(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetClassName() exit"));
}


const wxPGPropertyClassInfo* PyPropertyCategory::GetClassInfo() const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetClassInfo() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetClassInfo_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetClassInfo_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::GetClassInfo() exit (fall-back)"));
        return wxPropertyCategoryClass::GetClassInfo();
    }
    return _CommonCallback19(blocked, m_scriptObject, funcobj);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetClassInfo() exit"));
}


wxString PyPropertyCategory::GetValueAsString(int argFlags) const
{
    wxPyBlock_t blocked = wxPyBeginBlockThreads();
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetValueAsString() entry"));

    PyObject* cls_ = PyObject_GetAttr(m_scriptObject, gs___class___Name);
    PyObject* funcobj = NULL;
    if ( PyObject_HasAttr(cls_, gs_GetValueAsString_Name) == 1 ) funcobj = PyObject_GetAttr(cls_, gs_GetValueAsString_Name);
    Py_DECREF(cls_);
    if ( !funcobj || PyObject_HasAttr(m_scriptObject, gs__super_call_Name) == 1 )
    {
        wxPyEndBlockThreads(blocked);
        MySWIGOutputDebugString(wxT("PyPropertyCategory::GetValueAsString() exit (fall-back)"));
        return wxPropertyCategoryClass::GetValueAsString(argFlags);
    }
    return _CommonCallback23(blocked, m_scriptObject, funcobj, argFlags);
    MySWIGOutputDebugString(wxT("PyPropertyCategory::GetValueAsString() exit"));
}


%}
