#
# We'll use Python as main language in our little install script
#

import sys, os, os.path

def main():
    args = sys.argv

    s_merge_only = None
    python_exe = None
    s_rest_of_args = ''

    if len(args) < 2 or args[1] == '--help':
        print 'This script tries to automatically configure and install'
        print 'wxPropertyGrid for wxPython. As a requirement, you need'
        print 'to have built wxPython from sources.'
        print ''
        print 'Accepted arguments:'
        print '  WXDIR=...         Set wxWidgets build directory (if'
        print '                    just source dir is specified, then'
        print '                    MERGE_ONLY=1 is automatically used.'
        print '  MERGE_ONLY=1      Just merge sources in wxWidgets source tree.'
        print '  PYTHON=...        Path to python executable to use.'
        print '  SWIG=...          Location of swig executable.'
        print '  SETUP_PY_OPTS="..."  Additional paramters when calling'
        print '                       wxPython setup.py.'
        return

    if len(args) > 1:
        rest_of_args = []

        for s in args[1:]:
            if s.find('=') > 0:
                s0,s1 = s.split('=',1)
                s0 = s0.lower()
                if s0 == 'merge_only':
                    if s1 == '1' or s1.lower() == 'yes':
                        s_merge_only = 'MERGE_ONLY=1'
                    else:
                        s_merge_only = ''
                elif s0 == 'python':
                    python_exe = s1
                else:
                    rest_of_args.append(s)
            rest_of_args.append(s)

        s_rest_of_args = ' '.join(rest_of_args)

    if s_merge_only is None:
        print "Do you want to try automatically build and install shared libraries and wrappers? [y]"
        auto_build = raw_input().lower()
        if auto_build == '':
            auto_build = 'y'

        if auto_build == 'y':
            s_merge_only=''
        else:
            s_merge_only="MERGE_ONLY=1"

    if s_merge_only == '' or s_merge_only.lower() == 'merge_only=0':
        if python_exe is None:
            if auto_build == 'y':
                print "Which python interpreter to use? [python]"
                python_exe = raw_input()
                if not python_exe:
                  python_exe = "python"
            else:
                python_exe="python"

    print "Running build_for_wxpy.py..."

    os.system('%s wxPython/build_for_wxpy.py propgrid %s %s'%(python_exe,s_merge_only,s_rest_of_args))

main()
