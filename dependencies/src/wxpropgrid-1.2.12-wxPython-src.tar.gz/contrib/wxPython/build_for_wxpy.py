#
# build_for_wxpy.py
#
# Script for building wxPython bindings for a wxWidgets component.
# Mainly for use with wxPropertyGrid.
#
# By Jaakko Salli
#


usage = """\

USAGE:
  build_for_wxpy.py PROJECT [options]

  PROJECT is project name (such as stc or propgrid, according to
    text used as directory names etc).

Available options (override those specified in wxcdist_config.py or spec.py):

  WXDIR=XXX      Your wxWidgets/wxPython distribution root.
  UNICODE=X      1 or 0, determining whether unicode libs are built or not.
                 Default is determined by scanning your Python library dir,
                 with favour on unicode incase both are found.
  SWIG=XXX       Override location of SWIG executable.
  SETUP_PY_OPTS=XXX Override parameters when calling wxPython setup.py.
  REDIST=X       Create redistributable package instead of install.
                 Default is 0.
  PYDEBUG=X      1 to enable additional debug prints. Default is 1,
                 unless REDIST==1.
  HYBRID=X       1 to do hybrid build. This is default.
  RELEASE=X      1 to do release build. 0 to do debug build.
  VC_OPTS=X      Options passed to nmake. Default is what official wxPython
                 build uses.
"""

import sys, os, os.path, re, shutil

import distutils.sysconfig as sysconfig



try:
    import build_for_wxpy_config
    my_config = build_for_wxpy_config.__dict__
except ImportError:
    my_config = {}


use_unicode         = 1
orig_wx_dir         = None

makefile_opts_vc_release = """DEBUG_FLAG=1 CXXFLAGS="/D__WXPYTHON__ /D__NO_VC_CRTDBG__ /I%(python_include_dir)s" WXDEBUGFLAG=%(wx_debug_flag)s BUILD=release"""
makefile_opts_vc_debug = """CXXFLAGS="/D__WXPYTHON__ /I%(python_include_dir)s" BUILD=debug"""

# As defined in the wxPython build instructions
makefile_opts_vc_wx26 = """OFFICIAL_BUILD=1 SHARED=1 MONOLITHIC=1 USE_OPENGL=1 LDFLAGS="/LIBPATH:%(python_lib_dir)s" %(build_opts)s"""
makefile_opts_vc_wx28 = """OFFICIAL_BUILD=1 SHARED=1 MONOLITHIC=0 USE_OPENGL=1 USE_GDIPLUS=1 LDFLAGS="/LIBPATH:%(python_lib_dir)s" %(build_opts)s"""


# build_options.py template
build_options_template = """\
# build_options.py as written by build_for_wxpy.py
UNICODE=%i
UNDEF_NDEBUG=1
INSTALL_MULTIVERSION=1
FLAVOUR=""
EP_ADD_OPTS=1
WX_CONFIG="%s"
WXPORT="%s"
MONOLITHIC=%i
FINAL=%i
HYBRID=%i
WXPY_SRC="%s"
"""


# This code will be placed into wxPython/setup.py
setup_py_template = """



#----------------------------------------------------------------------
# Define the %(projU)s extension module
#----------------------------------------------------------------------

try:
    _temp_%(proj)s_ = BUILD_%(projU)s
except NameError:
    BUILD_%(projU)s = 1

if BUILD_%(projU)s:
    msg('Preparing %(projU)s...')
    location = 'contrib/propgrid'
    #if os.name == 'nt':
    %(projU)s_H = opj(WXDIR, 'contrib', 'include/wx/%(proj)s')

    _use_swig_args = swig_args
    swig_args_rem = %(swig_args_rem)s

    for s_ in swig_args_rem:
        _use_swig_args.remove(s_)

    swig_sources = run_swig(['%(proj)s.i'], location, GENDIR, PKGDIR,
                            USE_SWIG, swig_force,
                            _use_swig_args + %(swig_args)s + ['-I'+%(projU)s_H, '-I'+location],
                            [opj(%(projU)s_H, '%(proj)s.h'),
                             ] + swig_deps)

    ext = Extension('_%(proj)s',
                    swig_sources,

                    include_dirs = includes + CONTRIBS_INC,
                    define_macros = defines,

                    library_dirs = libdirs,
                    libraries = libs + makeLibName('%(proj)s'),

                    extra_compile_args = cflags,
                    extra_link_args = lflags,
                    )

    wxpExtensions.append(ext)"""


define_wxpython_injection = "// Temporary define -- REMOVE IF PERSISTS --\n#undef __WXPYTHON__\n#define __WXPYTHON__\n\n"

define_debug_i_injection  = "// Temporary define -- REMOVE IF PERSISTS --\n#undef WX_PG_PYTHON_DEBUGn#define WX_PG_PYTHON_DEBUG\n\n"

sys.path.append('distscript')

import libwxcdist


class wxpy_build_app(libwxcdist.distrib_app):
    def __init__(self):
        libwxcdist.distrib_app.__init__(self,ask_wxdir_msg="Enter wxWidgets build directory:")

    def finalize(self):
        libwxcdist.distrib_app.finalize(self)


def main():

    global app
    app = None

    global spec
    spec = None

    environ = os.environ
    argv = sys.argv
    copyfile = shutil.copyfile
    copytree = shutil.copytree
    rmtree = libwxcdist.rmtree
    system = os.system
    opj = os.path.join

    if len(argv) < 2:
        print usage
        return

    if os.getcwd().endswith('wxPython'):
        os.chdir('..')

    app = wxpy_build_app()

    py_ver_str = '%i%i'%(sys.version_info[0],sys.version_info[1])

    print '. Python version %i.%i.%i'%(sys.version_info[0],sys.version_info[1],sys.version_info[2])

    projname = None
    spec = app.spec
    opts = {}
    opts.update(spec.__dict__)

    if app.config and hasattr(app.config,'wxpython_dirs'):
        for k,v in app.config.wxpython_dirs.iteritems():
            opts['wxdir'] = v
            break

    opts.update(app.opts)
    
    projname = app.projname

    do_pyd = True
    do_iface = True
    do_dll = True
    final_copy = True

    windows = sys.platform == 'win32'

    if 'posix' in opts:
        # POSIX=1 must defined on command-line for MingW+MSys or Cygwin builds
        posix = int(opts.get('posix'))
    else:
        if windows:
            posix = 0
        else:
            posix = 1

    # TODO:: For cygwin/mingw, define windows = True, posix = True, and use_vc = False
    if windows and not posix:
        print '. doing Windows Visual C++ build'
        debuginfo_file_ext = 'pdb'
        use_vc = True
    else:
        if windows:
            print '. doing Windows Cygwin or MingW+MSys build'
        else:
            print '. doing POSIX/GCC build'
        use_vc = False
        debuginfo_file_ext = None

    cwd = os.getcwd()
    script_dir = os.path.split(argv[0])[0]

    in_contrib = cwd.find('contrib') >= 0

    do_redist = int(opts.get('redist','0'))

    # Determine desired build (basicly only applies to VC++)
    do_hybrid = int(opts.get('hybrid','-1'))
    if do_hybrid == -1:
        do_hybrid = None
    do_release = int(opts.get('release','-1'))
    if do_release == -1:
        do_release = None

    # Hybrid and release are not compatible
    if not (do_hybrid is None) and not (do_release is None):
        print 'ERROR: options HYBRID and RELEASE are mutually exclusive'
        return

    if do_hybrid is None:
        if do_release is None:
            # do_hybrid = 1 is default
            do_hybrid = 1

    if not (do_hybrid is None) and do_hybrid == 1:
        build = 'HYBRID'
    if do_hybrid is None and do_release == 0:
        build = 'DEBUG'
    if do_hybrid is None and do_release == 1:
        build = 'RELEASE'

    if 'wxdir' in opts:
        wx_dir = opts['wxdir']
    else:
        wx_dir = ""
    """
    else:
        if not posix:
            wx_dir = "..\\"
        else:
            wx_dir = "../"
    """

    if wx_dir:
        wx_dir = os.path.abspath(wx_dir)
    
    if not os.path.isfile(opj(wx_dir,'include','wx','wx.h')):
        # Try app.default_wx_dir
        wx_dir_orig = wx_dir
        wx_dir = app.default_wx_dir
        if not os.path.isfile(opj(wx_dir,'include','wx','wx.h')):
            print "ERROR: '%s' is not valid wxWidgets source or build dir. Please specify WXDIR on command-line."%wx_dir_orig
            return

    if wx_dir:
        wx_dir = os.path.abspath(wx_dir)

    print '. wxWidgets sources are at \'%s\''%wx_dir

    merge_only = int(opts.get("merge_only",0))

    if windows:
        wxport = 'msw'
        platform_name = 'win32'  # Used in redist filename
        pyd_ext = 'pyd'
        SWIG_location = None
        swig_executable = 'swig.exe'
    else:
        if sys.platform == 'mac' or sys.platform == 'osx':
            wxport = 'mac'
            platform_name = 'osx'
        else:
            wxport = 'gtk2'
            platform_name = 'gtk2'

        pyd_ext = 'so'
        SWIG_location = None
        swig_executable = 'swig'

        # At this time, we can only compile, and only if configure was found
        if app.configure_was_run:
            do_dll = True
            do_iface = True
            do_pyd = True
            final_copy = False
        else:
            print '. configure was not run in (assumed) build dir... merging only'
            merge_only = 1

    if not merge_only:
        if opts.has_key('swig'):
            SWIG_location = opts['swig']
        elif app.config and hasattr(app.config,'swig_path'):
            SWIG_location = app.config.swig_path

        if not SWIG_location:
            print '. SWIG location not specified, assuming it is in the PATH'

    else:
        do_dll = do_pyd = final_copy = False

    if opts.has_key('bakefile'):
        app.config.bakefile_path = opts['bakefile']

    global orig_wx_dir
    try:
        orig_wx_dir = os.environ['WXWIN']
    except KeyError:
        orig_wx_dir = None
    os.environ['WXWIN'] = wx_dir

    # Are the contrib sources in the same dir as well?
    if app.mode == 'contrib':
        if in_contrib:
            wx_dir_contrib = cwd
        else:
            wx_dir_contrib = opj(wx_dir,"contrib")

        wx_dir_contrib = os.path.abspath(wx_dir_contrib)
        proj_wxpy_files_dir = opj(wx_dir_contrib,'wxPython',projname)
    else:
        wx_dir_contrib = None
        proj_wxpy_files_dir = app.get_comp_dir('wxpython')

    if not os.path.isfile(opj(proj_wxpy_files_dir, '%s.i'%projname)):
        print "ERROR: No wxPython-related files for project '%s'\n    (should be in '%s')"%(projname, proj_wxpy_files_dir)
        return

    target_contrib = opj(wx_dir, 'contrib')
    target_wxpython = opj(wx_dir, 'wxPython')

    # Get custom property build settings
    sys.path.append(proj_wxpy_files_dir)

    projtitle = spec.longprojname
    verstr = spec.version

    # Prepare spec globals
    if spec:
        spec.opj = opj
        spec.copyfile = copyfile
        spec.copytree = copytree
        spec.wx_dir = wx_dir
        spec.wx_dir_contrib = wx_dir_contrib
        spec.projname = projname
        spec.target_contrib = target_contrib
        spec.windows = windows
        spec.posix = posix

    src_path = app.get_comp_dir('src')
    if not os.path.isdir(src_path):
            print 'ERROR: Source dir (%s) not found'%src_path
            return

    #
    # Add contrib instructions to config.py and setup.py (if not already done)
    #
    projnameU = projname.upper()
    config_py_fn = opj(target_wxpython,'config.py')
    setup_py_fn = opj(target_wxpython,'setup.py')
    try:
        content = file(config_py_fn,'rt').read()
    except:
        print 'ERROR: %s not found (are you sure wxPython source distribution is there?)'%config_py_fn
        return

    if content.find("'BUILD_%s'"%projnameU) < 0:
        # Add 'BUILD_XXX' entry
        print '. modifying config.py and setup.py'
        content = content.replace("'BUILD_STC'","'BUILD_STC', 'BUILD_%s'"%projnameU)

        file(config_py_fn,'wt').write(content)

        content = file(setup_py_fn,'rt').read()
        i1 = content.find('if BUILD_STC:')
        if i1 < 0:
            print 'ERROR: STC instructions not found in setup.py'
            return

        fs2 = 'wxpExtensions.append(ext)'
        i2 = content.find(fs2,i1)
        if i2 < 0:
            print 'ERROR: STC instructions (part 2) not found in setup.py'
            return

        i2 += len(fs2)

        # Get extra SWIG arguments
        if hasattr(spec,'wxpy_get_extra_swig_args'):
            swig_args = spec.wxpy_get_extra_swig_args()
        else:
            swig_args = []

        # Get swig args that needs to be removed
        if hasattr(spec,'wxpy_get_culled_swig_args'):
            swig_args_rem = spec.wxpy_get_culled_swig_args()
        else:
            swig_args_rem = []

        td = {'proj':projname,'projU':projnameU,'swig_args':repr(swig_args),'swig_args_rem':repr(swig_args_rem)}

        content = content[:i2] + setup_py_template%td + content[i2:]

        file(setup_py_fn,'wt').write(content)

    python_include_dir = opj(sys.prefix,'include')
    if not os.path.isfile(opj(python_include_dir,'Python.h')):
        python_include_dir = opj(python_include_dir,'python')
        if not os.path.isfile(opj(python_include_dir,'Python.h')):
            app.warning('Python.h could not be located in any candidate directory')
    python_lib_dir = opj(sys.prefix,'libs')

    # Determine wxWidgets version
    f = file(opj(wx_dir,'include','wx','version.h'))
    s = f.read()
    f.close()
    VER_SUBREL = None
    m = re.compile('wxMAJOR_VERSION\s+([0-9]+)').search(s)
    if m:
        VER_MAJOR = int(m.group(1))
        m = re.compile('wxMINOR_VERSION\s+([0-9]+)').search(s)
        if m:
            VER_MINOR = int(m.group(1))
            m = re.compile('wxRELEASE_NUMBER\s+([0-9]+)').search(s)
            if m:
                VER_RELEASE = int(m.group(1))
                m = re.compile('wxSUBRELEASE_NUMBER\s+([0-9]+)').search(s)
                if m:
                    VER_SUBREL = int(m.group(1))

    if use_vc:
        if build == 'RELEASE':
            print '. doing RELEASE build'
            wx_debug_flag = ''
            arg_do_final = 1
            arg_do_hybrid = 0
        elif build == 'DEBUG':
            print '. doing DEBUG build'
            wx_debug_flag = 'd'
            arg_do_final = 0
            arg_do_hybrid = 0
        elif build == 'HYBRID':
            print '. doing HYBRID build'
            wx_debug_flag = 'h'
            arg_do_final = 0
            arg_do_hybrid = 1
    else:
        # TODO: Determine using wx-config ('d' is default, however) .
        wx_debug_flag = 'd'
        arg_do_final = 0
        arg_do_hybrid = 0

    # Determine some variables based on version
    if not (VER_SUBREL is None):
        if (VER_MINOR & 1) == 1:
            is_devel = True
        else:
            is_devel = False

        makefile_ver_str    = '.%i.%i.%i'%(VER_MAJOR,VER_MINOR,VER_RELEASE)
        wx_version_string   = '%i.%i.%i'%(VER_MAJOR,VER_MINOR,VER_RELEASE)

        # wx_version_build is used in DLLs and site-package dirs
        if is_devel:
            wx_version_build    = '%i.%i.%i'%(VER_MAJOR,VER_MINOR,VER_RELEASE)
        else:
            wx_version_build    = '%i.%i'%(VER_MAJOR,VER_MINOR)

        wx_version_build_nodot = wx_version_build.replace('.','')

        wx_py_ver_str       = '%i.%i.%i.%i'%(VER_MAJOR,VER_MINOR,VER_RELEASE,VER_SUBREL)

        makefile_opts_dict = {
            'python_include_dir':python_include_dir,
            'python_lib_dir':python_lib_dir,
            'wx_debug_flag':wx_debug_flag,
        }

        if build == 'DEBUG':
            build_opts = makefile_opts_vc_debug % makefile_opts_dict
        else:
            build_opts = makefile_opts_vc_release % makefile_opts_dict

        makefile_opts_dict['build_opts'] = build_opts

        if VER_MINOR == 6:
            if use_vc:
                makefile_opts_vc = makefile_opts_vc_wx26%makefile_opts_dict
            use_monolithic = 1
        elif VER_MINOR == 7 or VER_MINOR == 8:
            if use_vc:
                makefile_opts_vc = makefile_opts_vc_wx28%makefile_opts_dict
            use_monolithic = 0
        else:
            print 'Unsupported wxWidgets version'
            return

        # Override nmake command-line arguments?
        if use_vc and 'vc_opts' in opts:
            makefile_opts_vc = opts['vc_opts']

        print '. wxPython version is %i.%i.%i.%i'%(VER_MAJOR,VER_MINOR,VER_RELEASE,VER_SUBREL)

    else:
        app.warning('Could not determine wxWidgets version')

    wx_build_dir = app.wx_build_dir
    configure_was_run = app.configure_was_run
    install_prefix = getattr(app,'wx_install_prefix',None)
    bo_wxconfig = "None"

    if configure_was_run and posix:
        print ". configure was run in '%s'"%wx_build_dir
        if install_prefix:
            bo_wxconfig = '%s/bin/wx-config'%bo_wxconfig

    if do_dll or do_pyd:
        use_unicode = 1
        sys.path.append(target_wxpython)

        def write_build_options(_unicode,_use_monolithic,_do_final,_do_hybrid):
            bopfn = opj(target_wxpython,'build_options.py')
            #print '  (%s)'%bopfn
            try:
                os.remove(bopfn)
            except:
                pass
            try:
                os.remove(bopfn+'c')
            except:
                pass
            f = file(bopfn,'wt')
            s = build_options_template%(_unicode,bo_wxconfig,wxport,_use_monolithic,_do_final,_do_hybrid,target_wxpython)
            f.write(s)
            f.close()

        # Get initial use_unicode
        use_unicode = 1

        if 'unicode' in opts:
            use_unicode = int(opts.get('unicode','1'))

        initial_use_unicode = use_unicode
        print ". creating build_options.py"
        write_build_options(initial_use_unicode,0,arg_do_final,arg_do_hybrid)

        site_packages_subdir_ansi = "wx-%s-%s-ansi"%(wx_version_build,wxport)
        site_packages_subdir_unicode = "wx-%s-%s-unicode"%(wx_version_build,wxport)
        wxpython_runtime_dir_ansi = opj(sysconfig.get_python_lib(),site_packages_subdir_ansi,"wx")
        wxpython_runtime_dir_unicode = opj(sysconfig.get_python_lib(),site_packages_subdir_unicode,"wx")

        use_unicode = 1

        #import config

        if do_redist:
            # If doing a redist, trust the command line variable
            pass
        elif os.path.isdir(wxpython_runtime_dir_ansi):
            print '. wxPython %s ANSI runtime found...'%wx_version_build
            if os.path.isdir(wxpython_runtime_dir_unicode):
                print '. wxPython %s Unicode runtime found...'%wx_version_build
            else:
                use_unicode = 0
        else:
            if os.path.isdir(wxpython_runtime_dir_unicode):
                print '. wxPython %s Unicode runtime found...'%wx_version_build
                use_unicode = 1
            elif not do_redist:
                if not posix:
                    # Currently, we can't build for existing runtime without sources on POSIX systems
                    print('NOTE: wxPython runtime not detected')
                final_copy = False

        if 'unicode' in opts:
            use_unicode = int(opts.get('unicode','1'))

        if use_unicode:
            print '. using Unicode'
            #config.UNICODE = 1
            str_type = 'unicode'
            wxpython_runtime_dir = wxpython_runtime_dir_unicode
            site_packages_subdir = site_packages_subdir_unicode
        else:
            print '. using ANSI'

            str_type = 'ansi'
            wxpython_runtime_dir = wxpython_runtime_dir_ansi
            site_packages_subdir = site_packages_subdir_ansi


        wxpython_runtime_dir_orig = wxpython_runtime_dir

        if not posix:
            if use_unicode:
                wxpy_dll_prefix     = "wx%s%su%s"%(wxport,wx_version_build_nodot,wx_debug_flag)
            else:
                wxpy_dll_prefix     = "wx%s%s%s"%(wxport,wx_version_build_nodot,wx_debug_flag)
        else:
            if use_unicode:
                wxpy_dll_prefix     = "libwx_%su%s_%s-%s"%(wxport,wx_debug_flag,projname,wx_version_build_nodot)
            else:
                # TODO: Is this correct? I have not confirmed...
                wxpy_dll_prefix     = "libwx_%sa%s_%s-%s"%(wxport,wx_debug_flag,projname,wx_version_build_nodot)

        if use_unicode:
            wxpython_runtime_dir = opj(sysconfig.get_python_lib(),"wx-%s-%s-unicode"%(wx_version_build,wxport),"wx")
        else:
            wxpython_runtime_dir = opj(sysconfig.get_python_lib(),"wx-%s-%s-ansi"%(wx_version_build,wxport),"wx")


        if spec:
            spec.VER_MAJOR = VER_MAJOR
            spec.VER_MINOR = VER_MINOR
            spec.VER_RELEASE = VER_RELEASE
            spec.VER_SUBREL = VER_SUBREL
            if app.wx_use_unicode is None:
                spec.wx_use_unicode = use_unicode
                if posix and app.wx_use_unicode != use_unicode:
                    print 'ERROR: Conflict between wxUSE_UNICODE found configure log and one defined otherwise'
                    return

            spec.wxpython_runtime_dir = wxpython_runtime_dir


        # Build-specific subdir (configure setups only)
        wx_build_subdir = ''

        if use_vc:
            wxpython_runtime_lib_dir = wxpython_runtime_dir
            #implib_fn = "%s.lib"%wxpy_dll_prefix

            wx_lib_dir = opj(wx_dir,'lib','vc_dll')

            com_fn = "%s_%s_vc"%(wxpy_dll_prefix,projname)
            com_dll_fn = "%s_%s_vc.dll"%(wxpy_dll_prefix,projname)
            com_dll_fn_di = "%s_%s_vc.%s"%(wxpy_dll_prefix,projname,debuginfo_file_ext)

        else:
            wxpython_runtime_lib_dir = '/usr/lib/wxPython/lib'

            wx_lib_dir = opj(wx_dir,wx_build_subdir,'lib')

            com_fn = wxpy_dll_prefix
            if not windows:
                com_dll_fn = "%s.so"%(wxpy_dll_prefix)
            else:
                com_dll_fn = "%s.dll"%(wxpy_dll_prefix)


    #
    # Copy contrib tree to place of compilation (if necessary)
    if app.mode == 'contrib':
        dc1 = wx_dir_contrib.replace('\\','').replace('/','')
        dc2 = target_contrib.replace('\\','').replace('/','')
        source_dir_is_install_dir = (dc1 == dc2)
    else:
        source_dir_is_install_dir = False

    if not source_dir_is_install_dir:
        # TODO: Add overwrwite query
        print ". deleting old temporary sources"
        rmtree( opj(target_contrib,'src',projname), ignore_errors=True )
        rmtree( opj(target_contrib,'include','wx',projname), ignore_errors=True )
        rmtree( opj(target_contrib,'build',projname), ignore_errors=True )
        tree_path = opj(target_wxpython,'contrib',projname)
        rmtree( tree_path, ignore_errors=True )

        print ". copying temporary sources"
        if app.mode == 'contrib':
            copytree( opj(wx_dir_contrib,'src',projname), opj(target_contrib,'src',projname) )
            copytree( opj(wx_dir_contrib,'include','wx',projname), opj(target_contrib,'include','wx',projname) )
            copytree( opj(wx_dir_contrib,'build',projname), opj(target_contrib,'build',projname) )
            copytree( opj(wx_dir_contrib,'wxPython',projname), tree_path )
        else:
            _d = 'src'

            sd = app.get_comp_dir(_d)
            try:
                os.makedirs( opj(target_contrib, _d, projname) )
            except:
                pass
            for fn in os.listdir(sd):
                s = opj(sd, fn)
                if os.path.isfile(s):
                    copyfile(s, opj(target_contrib, _d, projname, fn))

            _d = 'include/wx/%s'%projname

            sd = app.get_comp_dir(_d)
            try:
                os.makedirs( opj(target_contrib, _d) )
            except:
                pass
            for fn in os.listdir(sd):
                s = opj(sd, fn)
                if os.path.isfile(s):
                    copyfile(s, opj(target_contrib, _d, fn))

            _d = 'wxpython'

            sd = app.get_comp_dir(_d)
            try:
                os.makedirs( opj(target_contrib, 'build', projname) )
            except:
                pass
            copyfile(opj(sd, '%s_contrib.bkl'%projname), opj(target_contrib, 'build', projname, '%s.bkl'%projname))

            _d = 'wxpython'

            sd = app.get_comp_dir(_d)
            try:
                os.makedirs( tree_path )
            except:
                pass
            for fn in os.listdir(sd):
                s = opj(sd, fn)
                if os.path.isfile(s):
                    copyfile(s, opj(tree_path, fn))

    #
    # Inject #define __WXPYTHON__
    print ". injecting '#define __WXPYTHON__'"
    app.text_injection(opj(target_contrib,'include','wx',projname,projname+'.h'),
                       '#include',
                       define_wxpython_injection,
                       revert=False)

    #
    # Inject #define WX_PG_PYTHON_DEBUG?

    enable_pydebug = opts.get('pydebug', -1)

    if enable_pydebug == -1:
        if do_redist:
            enable_pydebug = 0
        else:
            enable_pydebug = 1

    if enable_pydebug:
        print ". injecting '#define WX_PG_PYTHON_DEBUG'"
        app.text_injection(opj(target_wxpython,'contrib',projname,projname+'.i'),
                           '#include',
                           define_debug_i_injection,
                           revert=False)

    spec.app = app

    if hasattr(spec,'wxpy_before_build'):
        spec.wxpy_before_build()

    # Try to run bakefile for merge-only
    if merge_only:
        print '. will try to run bakefile even when merging only'

    if do_dll:

        if use_vc:
            if use_unicode:
                makefile_opts_vc += ' UNICODE=1'
                if VER_MAJOR >= 3 or VER_MINOR >= 7:
                    makefile_opts_vc += ' MSLU=1'

    if do_dll or merge_only:
        # First just try to copy makefile of appropriate version
        copied_makefile = False

        if app.mode == 'contrib':
            if posix:
                try:
                    shutil.copyfile( opj(wx_dir_contrib,'src',projname,'Makefile.%i.%i.%i.in'%(VER_MAJOR,VER_MINOR,VER_RELEASE)), opj(target_contrib,'src',projname,'Makefile.in') )
                    copied_makefile = True
                except:
                    pass

        # Create bakefiles - this is important since in-between wxWidgets-release-version
        # wxPython releases (ie. 2.7.1.3 instead of 2.7.1 or 2.7.2) may have slight
        # differences.
        if copied_makefile:
            print '. running bakefile_gen (probably doesn\'t matter if fails)'
        else:
            print '. running bakefile_gen'
        proj_build_dir = opj(target_contrib,'build',projname)

        # The file *needs* to be removed. Bakefile may fail to update it otherwise.
        makefile_fn = 'makefile.vc'
        try:
            os.remove( opj(proj_build_dir,makefile_fn) )
        except:
            pass

        os.chdir( opj(wx_dir,'build','bakefiles') )

        bkl_list = '-b../../contrib/build/%s/%s.bkl,../../contrib/samples/%s/%s%s.bkl' % (projname,projname,projname,projname,'sample')
        #print bkl_list

        path_bakefile_gen = app.get_bakefile_gen_path(wx_version_string, is_wxcode=False)
        os.system('%s --desc Bakefiles.bkgen %s'%(path_bakefile_gen,bkl_list))

    # Adjust makefiles
    if posix:
        makefile_in_path = opj(target_contrib,'src',projname,'Makefile.in')
        repl_count = 0
        full_repl_count = 2
        try:
            f = file(makefile_in_path, 'rt')
        except:
            f = None
        if f:
            s = f.read()
            f.close()

            stf = "CPPFLAGS = "
            if s.find(stf) >= 0:
                sr = '%s -D__WXPYTHON__ -I%s '%(stf,python_include_dir)
                if s.find(sr) < 0:
                    s = s.replace(stf, sr.replace('\\','/'))
                    repl_count += 1

            stf = 'LDFLAGS = '
            if s.find(stf) >= 0:
                sr = '%s -L%s -lpython%i.%i '%(stf,python_lib_dir,sys.version_info[0],sys.version_info[1])
                if s.find(sr) < 0:
                    s = s.replace(stf, sr.replace('\\','/'))
                    repl_count += 1

            if repl_count:
                f = file(makefile_in_path, 'wt')
                f.write(s)
                f.close()

        print '. performed %i/%i replaces to Makefile.in'%(repl_count,full_repl_count)

    if do_dll:
        if use_vc:
            os.chdir( proj_build_dir )
            print '. building component DLL (using %s)'%makefile_fn
            #err = system('nmake -f %s clean %s'%(makefile_fn,makefile_opts_vc))
            #if err > 0:
            #    return

            #nmake -f makefile.vc OFFICIAL_BUILD=1 SHARED=1 MONOLITHIC=1 USE_OPENGL=1 DEBUG_FLAG=1 CXXFLAGS="/D__WXPYTHON__ /D__NO_VC_CRTDBG__" WXDEBUGFLAG=h BUILD=release
            make_cmdline = 'nmake -f %s %s'%(makefile_fn,makefile_opts_vc)
            print 'Make command-line:\n%s'%make_cmdline
            err = system(make_cmdline)
            if err > 0:
                return
        else:
            #if not (app.wx_use_unicode is None):
            #    use_unicode = app.wx_use_unicode

            if use_unicode:
                print '. using Unicode'
            else:
                print '. using ANSI'

            #
            #  Try to regenerate makefiles
            print '. regenerating makefiles'
            if app.mode == 'contrib':
                os.chdir(wx_build_dir)
                # Don't do it for sample, we don't care about it here
                cmdline = '%s/regen contrib/src/%s/Makefile'%(wx_dir,projname)
                os.system(cmdline)
            else:
                pass

            print '. compiling and installing shared libraries (NOTE: sudo may ask for password)'
            if app.mode == 'contrib':
                os.chdir(wx_build_dir)
                err = os.system("make -C contrib/src/%s"%projname)
                if err > 0:
                    return
                cmdline = "sudo make install -C contrib/src/%s"%projname
                print 'Running \'%s\''%cmdline
                err = os.system(cmdline)
                if err > 0:
                    return
            else:
                pass


    os.chdir(cwd)


    if SWIG_location:
        SWIG_exe_location = os.path.join(SWIG_location,swig_executable)
    else:
        SWIG_exe_location = swig_executable

    #
    # Build the Interface DLL
    #
    if do_pyd:

        os.chdir( opj(wx_dir,'wxPython') )
        try: os.remove('build_options.pyc')
        except: pass

        if use_unicode == 1:
            unicode_cf = "UNICODE=1"
        else:
            unicode_cf = "UNICODE=0"

        if windows:
            if SWIG_location and not os.path.isfile(SWIG_exe_location):
                print "ERROR: '%s' is not valid SWIG executable"%SWIG_exe_location
                return

        prefix_cf = ''

        if posix:
            if install_prefix:
                prefix_cf = 'WX_CONFIG=%s/bin/wx-config'%install_prefix

        if do_iface:
            if SWIG_location:
                swig_cf = "USE_SWIG=1 SWIG=%s"%SWIG_exe_location
            else:
                swig_cf = "USE_SWIG=1"
        else:
            swig_cf = ""

        try: os.remove('build_options.py')
        except: pass

        setup_py_opts = opts.get('setup_py_opts',None)

        if setup_py_opts:
            setup_py_cmdline = "%s setup.py %s"%(sys.executable,setup_py_opts)
        else:
            if build == 'DEBUG':
                setup_py_debug_arg = ' --debug'
            else:
                setup_py_debug_arg = ''

            setup_py_cmdline = "%s setup.py build_ext --inplace%s MONOLITHIC=%i BUILD_%s=1 %s %s %s"%(sys.executable, \
                setup_py_debug_arg,use_monolithic,projnameU,swig_cf,unicode_cf,prefix_cf)

        print setup_py_cmdline
        err = system(setup_py_cmdline)
        if err > 0:
            return
    else:
        print ''
        print 'NOTE: This script has only copied and altered files so that %s'%projnameU
        print '      is now part of wxPython distribution at'
        print ''
        print '          \'%s\''%wx_dir
        print ''
        print '      Now you will need to actually re-configure and re-build'
        print '      wxPython (including portions that require SWIG).'
        return

    # Back to starting dir
    os.chdir(cwd)

    if final_copy:

        if do_redist:
            if not use_vc:
                print '. ERROR: Currently can only generate redist for Visual C++ builds'
                return

            # Because in component mode, scripts are usually run in wxpython subdir,
            # make sure we are in src root now
            #if app.mode == 'component':
            #    os.chdir(opj(app.component_dir,app.projname_and_branch))

            redist_name = 'wx%s-%s-wxpython-%s-%s-%s-py%s'%(projname,verstr,wx_py_ver_str,platform_name,str_type,py_ver_str)
            wxpython_runtime_dir = opj(app.redist_dir,redist_name,'Lib','site-packages',site_packages_subdir,'wx')
            wxpython_runtime_lib_dir = wxpython_runtime_dir

        try:
            os.makedirs(wxpython_runtime_dir)
        except:
            pass

        print '. copying final files to %s'%wxpython_runtime_dir

        if do_redist:
        
            PY_WX_LIB = opj('Lib','site-packages',site_packages_subdir,'wx')

            # Copy extra files
            if hasattr(spec,'wxpy_get_extra_redist_files'):
            
                if app.mode == 'component':
                    base_extra_dir = opj(app.component_dir, app.projname_and_branch)
                else:
                    base_extra_dir = wx_dir_contrib

                for fpth in spec.wxpy_get_extra_redist_files():
                    if isinstance(fpth,tuple):
                        fn1 = opj(base_extra_dir,fpth[0])
                        fn2 = opj(app.redist_dir,redist_name,fpth[1])
                        fpth = fpth[0]
                    else:
                        fn1 = opj(base_extra_dir,fpth)
                        fn2 = opj(app.redist_dir,redist_name,os.path.split(fpth)[1])

                    print 'Adding extra file \'%s\''%fpth

                    fn2 = fn2.replace('PY_WX_LIB',PY_WX_LIB)

                    # Destination dir must exist
                    s2 = os.path.split(fn2)
                    try:
                        os.makedirs(s2[0])
                    except:
                        pass

                    copyfile(fn1,fn2)


        if do_dll:
            if wxpython_runtime_lib_dir != wxpython_runtime_dir:
                print '. except dynlib to %s'%wxpython_runtime_lib_dir
            copyfile(opj(wx_lib_dir,com_dll_fn),opj(wxpython_runtime_lib_dir,com_dll_fn))
            if build == 'DEBUG' and debuginfo_file_ext:
                copyfile(opj(wx_lib_dir,com_dll_fn_di),opj(wxpython_runtime_lib_dir,com_dll_fn_di))
        if do_pyd:
            if build == 'DEBUG':
                pyd_prename = "_%s_d"%(projname)
            else:
                pyd_prename = "_%s"%(projname)
            pyd_filename = '%s.%s'%(pyd_prename,pyd_ext)
            copyfile(opj(wx_dir,"wxPython","wx",pyd_filename),opj(wxpython_runtime_dir,pyd_filename))
            if build == 'DEBUG' and debuginfo_file_ext:
                pdb_filename = '%s.%s'%(pyd_prename,debuginfo_file_ext)
                copyfile(opj(wx_dir,"wxPython","wx",pdb_filename),opj(wxpython_runtime_dir,pdb_filename))
        if do_iface:
            copyfile(opj(wx_dir,"wxPython","wx","%s.py"%projname),opj(wxpython_runtime_dir,"%s.py"%projname))

        if do_redist:

            from distutils.core import setup

            if windows:
                setup_arg = 'bdist_wininst'
            else:
                setup_arg = 'bdist_rpm'

            sys.argv = [sys.argv[0],setup_arg]

            #
            # Translate directory layout to setup data_files
            file_lists = []

            def _add_files(src_dir,dst_dir):

                ls = []

                for fn in os.listdir(src_dir):
                    fpth = opj(src_dir,fn)
                    if os.path.isdir(fpth):
                        if dst_dir and dst_dir[-1] != '/':
                            dst_dir += '/'
                        _add_files(fpth,dst_dir+fn+'/')
                    else:
                        if not ls:
                            if dst_dir and dst_dir[-1] == '/':
                                dst_dir = dst_dir[:-1]
                            file_lists.append( (dst_dir,ls) )

                        ls.append(fpth)

            _add_files(opj(app.redist_dir,redist_name),"")


            finish_text = '%s for wxPython has been succesfully installed.'%projtitle

            setup_verstr = '%s for wxPython %s (%s)'%(verstr,wx_py_ver_str,str_type)

            dst_zip = '%s.zip'%redist_name

            import zipfile

            # Special for Python >= 2.5
            if sys.version_info[1] < 5:
                setup_script_args = None

                s_ = """\
from distutils.core import setup

def main():
    setup(name='%s',
          version='%s',
          description='None',
          author='%s',
          author_email='%s',
          url='None',
          data_files = %s
         )

main()
"""%(projtitle,setup_verstr,spec.author,spec.author_email,file_lists)
                #f = file('%s_setup.py'%projname,'wt')
                #f.write(s_)
                #f.close()

                setup(name=projtitle,
                      version=setup_verstr,
                      description='%s bindings for wxPython %s (%s)'%(projtitle,wx_py_ver_str,str_type),
                      author=spec.author,
                      author_email=spec.author_email,
                      url=spec.homepage,
                      data_files = file_lists,
                      script_args = setup_script_args,
                     )

                dst_exe = '%s.exe'%redist_name
                copyfile(opj('dist','%s-%s.%s.exe'%(projtitle,setup_verstr,platform_name)),dst_exe)

                zf = zipfile.ZipFile(dst_zip,'w',zipfile.ZIP_DEFLATED)
                # Put setup exe
                zf.write(dst_exe)
                # Put readme files
                os.chdir(opj(app.redist_dir,redist_name))
                for fn in os.listdir(os.getcwd()):
                    if fn.lower().startswith('readme'):
                        zf.write(fn)
                os.chdir(cwd)
                zf.close()

                # Move to redist dir
                shutil.move(dst_exe,opj(app.redist_dir,dst_exe))

            else:
                # For Python 2.5+, the above doesn't work quite right,
                # so we'll just put everything into a Zip-file
                zf = zipfile.ZipFile(dst_zip,'w',zipfile.ZIP_DEFLATED)
                #os.chdir(opj(app.redist_dir,redist_name))
                for d, ls in file_lists:
                    for fn in ls:
                        arcname = opj(d,os.path.split(fn)[1])
                        zf.write(fn, arcname)
                #os.chdir(cwd)
                zf.close()

            # Move to redist dir
            shutil.move(dst_zip,opj(app.redist_dir,dst_zip))


orig_cwd = os.getcwd()

try:
    main()
except:
    import traceback
    traceback.print_exc()

if orig_wx_dir:
    os.environ['WXWIN'] = orig_wx_dir
os.chdir(orig_cwd)
if spec and hasattr(spec,'wxpy_after_build'):
    spec.wxpy_after_build()

if app:
    app.finalize()
