// stdafx.cpp

#include "stdafx.h"

#if _ATL_VER >= 0x0200
# include <atlconv.cpp>
#endif
